import requests
body = {"um": "liuchunlin920",
                "password": "Pa888888qazWSX",
                "is_debug": False,
                "app":21}
zh_name, token, permissions = "", "", ""
SSO_URL="http://30.94.4.5:8000/passport"
res = requests.post("%s/account/api_login.json"%SSO_URL, body).json()
print res
token = res.get("data")
if token:
    params = {"token": token,
                      "secret": "fsv4tq8ba0xwh1no",
                      "app": 21}
    user_info = requests.post("%s/account/user_info.json"%SSO_URL, params).json()
    zh_name = user_info.get("data", {}).get('name', '')
    permissions = user_info.get("data", {}).get('permissions', [])
    print permissions

