#coding:utf-8
import elasticsearch
import traceback

import time
import sys
sys.path.append('..')



es = elasticsearch.Elasticsearch([{'host': 'es.local', 'port': 9200},{'host': 'es1.local', 'port': 9200},{'host': 'es2.local', 'port': 9200}])

def search(q=None, doc_type=None, from_=0, size=9999, source=True, index=''):
    """
    查询索引
    """
    result = {}
    total = 0
    try:
        result = es.search(
            body=q,
            index=index,
            doc_type=doc_type,
            _source=source,
            from_=from_,
            size=size
        )
        total = result.get('hits').get('total')
    except:
        print traceback.format_exc()
    resp = list()
    if result and source:
        for e in result.get('hits', {}).get('hits', {}):
            resp.append(e["_source"])
    return total, resp


if __name__ == "__main__":
    #from ipdb import set_trace; set_trace()
    cur_time = time.time()*1000
    cur_time_start = cur_time-100000
    #query_str = '{"query":{"range":{"timestamp":{"gte":%f, "lt":%f}}}}'%(cur_time_start, cur_time)
    query_str = '{"query":{"range":{"timestamp":{"gt":%d}}}}'%(cur_time_start)
    total, resp = search(q=query_str, source=["province", "bodyBytesSent","timeLocal", "timestamp"], index='accesslog_2019_09_25')
    print resp
    print cur_time_start
    print total
    print query_str
    
