# -*- coding: utf-8 -*-
import requests
import json
# Fill in your details here to be posted to the login form.
payload = {
    'user': 'pub_ljsitsm',
    'password': '123QWEasd?',
    'email':''
}

payload2 = {'search_type':'query_then_fetch','ignore_unavailable':True,'index':['accesslog_2019_10_17']}
payload3 = {'size':0,'query':{'bool':{'filter':[{'range':{'@timestamp':{'gte':'1571311944906','lte':'1571312244906','format':'epoch_millis'}}},{'query_string':{'analyze_wildcard':True,'query':'url: * AND (isAcc: True) AND ( isLegal: True) AND (idc: "WGQ" OR idc: "BX") AND(country: "中国") NOT (province: "中国")'}}]}},'aggs':{'3':{'terms':{'field':'province','size':36,'order':{'1':'desc'},'min_doc_count':1},'aggs':{'1':{'sum':{'field':'bodyBytesSent'}},'2':{'date_histogram':{'interval':'2m','field':'@timestamp','min_doc_count':0,'extended_bounds':{'min':'1571311944906','max':'1571312244906'},'format':'epoch_millis'},'aggs':{'1':{'sum':{'field':'bodyBytesSent'}}}}}}}}
# Use 'with' to ensure the session context is closed after use.
with requests.Session() as s:
    p = s.post('http://grafana5.op.lufax.tool/grafana5/login', data=json.dumps(payload), headers={'Content-type':'application/json'})
    print p.text
    p = s.post('http://grafana5.op.lufax.tool/grafana5/api/datasources/proxy/55/_msearch', data=json.dumps(payload2)+'\n'+json.dumps(payload3)+'\n', headers={'Content-Type':'application/json'})
    #from ipdb import set_trace; set_trace()
    print p
    print p.text

