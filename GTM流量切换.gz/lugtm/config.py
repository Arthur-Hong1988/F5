#-*-coding:utf-8-*-
#auth: ZJW
#Date: 2016-07-19


#web
webport        = "8007"
webhost        = "172.28.30.6"

#log
logmangers     = []
logcount       = 30

#ver
version        = "0.0.0.1"
