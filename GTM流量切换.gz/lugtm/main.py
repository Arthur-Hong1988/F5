#!usr/bin/env python 
#-*-coding:utf-8-*-
#auth: ZJW
#Date: 2016-07-19

import os
from config import webport,webhost

RUNSERVER = "runserver"


def run():
    #TODO
    while 1:
        pass


if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "lugtm.settings")

    from django.core.management import execute_from_command_line
    from lugtm.management.tasks.gtm_data_task import data_main_start
    data_main_start()
    #[local file path, command, host:port]
    argvs = [os.path.abspath(__file__), RUNSERVER, "%s:%s"%(webhost, webport)]
    
    execute_from_command_line(argvs)

