# -*- coding: utf8 -*-
from __future__ import division


from elasticsearch import Elasticsearch

province_info = {
            "Beijing": "北京",
            "Guizhou": "贵州",
            "Henan": "河南",
            "Shandong": "山东",
            "Sichuan": "四川",
            "Jiangsu": "江苏",
            "Qinghai": "青海",
            "Xinjiang Uyghur Autonomous Region": "新疆",
            "Fujian": "福建",
            "Zhejiang": "浙江",
            "Hubei": "湖北",
            "Tianjin": "天津",
            "Jiangxi": "江西",
            "Hainan": "海南",
            "Heilongjiang": "黑龙江",
            "Guangdong": "广东",
            "Yunnan": "云南",
            "Guangxi": "广西",
            "Shaanxi": "陕西",
            "Gansu": "甘肃",
            "Hebei": "河北",
            "Jilin": "吉林",
            "Chongqing": "重庆",
            "Ningxia Hui Autonomous Region": "宁夏",
            "Hunan": "湖南",
            "Inner Mongolia Autonomous Region": "内蒙古",
            "Shanghai": "上海",
            "Shanxi": "山西",
            "Tibet": "西藏",
            "Liaoning": "辽宁",
            "Anhui": "安徽",
            "Hongkong": "香港",
            "Macao": "澳门",
            "Taibet city": "台湾",
            #"other": "Other"
        }


class Es(object):

    def __init__(self, eshost='30.68.0.95', esport=9200, esuser='elastic', espasswd='brysj^hhrhl666'):
        self.es = Elasticsearch(["http://%s:%s"%(eshost, esport)], http_auth=(esuser, espasswd))

    def index_exist(self, index):
        return self.es.indices.exists(index=index)

    def count(self, index, body):
        count = self.es.count(index=index, body=body).get("count", None)
        return count

    def search(self, index, body):
        res = self.es.search(index=index, body=body)
        return res


def get_es_province_info(es):
    body = {"query": {"match_all": {}}}
    res = es.search(index=index, body=body)
    provinces = []
    region_codes = []
    for item in res:
        geoip = item.get("_source", {}).get("geoip", {})
        region_name = geoip.get("region_name")
        region_code = geoip.get("region_code")
        if region_name not in provinces:
            provinces.append(region_name)
        if region_code not in region_codes:
            region_codes.append(region_code)
    print(provinces)
    print(region_codes)


def get_es_province_count(es):
    body = {
        "query": {
            "match_all": {}
        },
        "size": 0,
        "aggs": {
            "RN": {
                "terms": {
                    "field": "geoip.region_name.keyword",
                    "size": 1000
                }
            }
        }
    }
    search_res = es.search(index=index, body=body)
    res = search_res.get("aggregations").get("RN").get("buckets")
    total = search_res.get("hits").get("total")
    return res, total


if __name__ == "__main__":
    index = "nginxlog-lufax-accessctl-2021-11-11"
    es = Es()
    count_info = {}
    other = 0
    another = 0
    province_infos, total = get_es_province_count(es)
    mcat_count = es.count(index, {"query": {"match": {"host": "mcat.lu.com"}}})
    count = total - mcat_count
    print("total", total)
    print("count", count)
    province_count = 0
    for province in province_infos:
        name = province.get("key")
        doc_count = province.get("doc_count")
        if name in province_info.keys():
            count_info[name] = round(doc_count/count, 4)
            province_count += doc_count
    count_info['other'] = round((count-province_count)/count, 4)
    for i, v in count_info.items():
        print(i, v)
    for k in province_info:
        if k not in count_info.keys():
            print(k,k)

