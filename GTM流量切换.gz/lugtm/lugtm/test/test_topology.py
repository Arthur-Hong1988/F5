import sys
sys.path.append('/opt/project/gtm/lugtm/')
from lugtm.management.gtm.service.topology import get_all_topology


print get_all_topology()
