# -*- coding: utf-8 -*-
from collections import OrderedDict

YGQ = u'WGQ'


def get_des_order_dc_v1(result_dcs, source_idc, des_idc):
    """
    根据idc 排定对应result_dcs的最新顺序
    :param result_dcs: 按weight降序的topology [{'dc_name': /Common/SH_YP_CTC, 'weight': 3090L,"order":355}, {'dc_name': /Common/SH_YP_CNC, 'weight': 3085L,"order":356}]
    :param source_idc: idc Model
    :param des_idc: idc Model
    :return:
    '''
    """
    result_dcs = [{'dc_name': "SH_WGQ_CTC", 'weight': 3090L, "order": 355},
                  {'dc_name': "SH_BX_CTC", 'weight': 3090L, "order": 355},
                  {'dc_name': "SH_WGQ_CNC", 'weight': 3090L, "order": 355},
                  {'dc_name': "SH_BX_CNC", 'weight': 3090L, "order": 355}]
    import copy
    all_result = copy.deepcopy(result_dcs)
    change_result = [None for i in range(len(result_dcs))]
    update_result = list()

    result_indexs = {}

    print('@@@NEW_IDC_CHANGE result_indexs is %s' % (result_indexs))
    for op, in_v in result_indexs.iteritems():
        s = in_v["start"]
        e = in_v["end"]
        if s == e:
            dc = result_dcs[s]["dc_name"]
            change_result[s] = dc
        else:
            e = s + 1
            if des_idc.code.upper() == YGQ:
                dcn = result_dcs[e]["dc_name"]
                dcs = result_dcs[s]["dc_name"]
                if des_idc.code.upper() in dcs:
                    continue
                change_result[s] = dcn
                for i in range(s, e):
                    dcn = result_dcs[i]["dc_name"]
                    change_result[i + 1] = dcn
            elif source_idc.code.upper() == YGQ:
                u"""
                bx > wgq > if
                
                wgq > bx > elif
                source wgq
                dcn sh bx ctc
                des_idc bx
                """
                dcn = result_dcs[s]["dc_name"]
                if des_idc.code.upper() in dcn:
                    continue
                change_result[e] = dcn
                for i in range(s + 1, e + 1):
                    dcn = result_dcs[i]["dc_name"]
                    change_result[i - 1] = dcn
    for j in range(len(all_result)):
        dc1 = all_result[j]["dc_name"]
        dc2 = change_result[j]
        if dc2 is None or dc1 == dc2:
            continue
        all_result[j]["dc_name"] = dc2
        update_result.append(all_result[j])
        #
        #     change_result.append(result_dcs[i])
        # all_result.append(result_dcs[i])
    if update_result:
        print('\n\n\n@@@V1   all_resultis %s, \nupdate_result is %s\n\n\n' % (all_result, update_result))
        return all_result, update_result
    return [], []
OrderedDict()

if __name__ == '__main__':
    print(get_des_order_dc_v1("", "BX", "WGQ"))