#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/3/29

from apscheduler.schedulers.background import BackgroundScheduler
import lugtm.base_sys.client_factory as clientFactory
import datetime
import logging
from apscheduler.events import EVENT_JOB_ERROR, EVENT_JOB_MISSED
scheduler = BackgroundScheduler()
logger = logging.getLogger("lugtm.task")

bigip = clientFactory.sbigip()


def err_listener(ev):
    if ev.exception:
        logger.exception('%s error.', str(ev.job))
    else:
        logger.info('%s miss', str(ev.job))

scheduler.add_listener(err_listener, EVENT_JOB_ERROR | EVENT_JOB_MISSED)


def syn_data_task():
    logger.info("--Start dc task--")
    from lugtm.management.gtm.service.datacenter import get_all_status
    from lugtm.datamodel.models import IDC,Operator,DataCenterModel
    idcs = IDC.objects.all()

    def get_idc(dc):
        result = None
        for idc in idcs:
            if idc.code in dc.name and idc.location in dc.name:
                result = idc
        return result
    ops = Operator.objects.all()

    def get_operator(dc):
        result = None
        for op in ops:
            if op.code in dc.name:
               result = op
        return result

    dc_list = get_all_status(bigip=bigip)
    # list_to_insert = list()
    for dc in dc_list:
        des_idc = get_idc(dc)
        des_ops = get_operator(dc)
        if des_idc and des_ops:
            code = dc.name[dc.name.rindex('/')+1:]
            des_list = DataCenterModel.objects.filter(code=code)
            if not des_list:
                dm = DataCenterModel()
                dm.code = code
                dm.status = dc.status
                dm.name = des_idc.name+des_ops.name
                dm.idc = des_idc
                dm.operator = des_ops
                dm.save()
            else:
                des_dm = des_list[0]
                des_dm.status = dc.status
                des_dm.name = des_idc.name+des_ops.name
                des_dm.idc = des_idc
                des_dm.operator = des_ops
                des_dm.save()
    logger.info("--End dc task--")


def syn_topology_task():
    logger.info("--Start topology task--")
    from lugtm.management.platform.service.topology_db_service import load_gtm_topology_to_db
    load_gtm_topology_to_db()
    logger.info("--End topology task--")


def syn_grafana_task():
    logger.info("--Start grafana task--")
    from lugtm.datamodel.models import IdcPercentageModel,Province,ProvinceTrafficPercentageModel,ProvinceTrafficPercentageHistoryModel
    from lugtm.management.platform.service.grafana_service import grafana_idc_data,grafana_province_data
    ###获取idc占比数据
    #idc_data = grafana_idc_data()
    #for k,v in idc_data.iteritems():
    #    des_list = IdcPercentageModel.objects.filter(code = k)
    #    if not des_list:
    #        idc = IdcPercentageModel()
    #        idc.code = k
    #        idc.gtm_code = k
    #        idc.percentage = v
    #        idc.save()
    #    else:
    #        des_idc = des_list[0]
    #        des_idc.percentage = v
    #        des_idc.save()

    ###获取省份占比数据
    province_data = grafana_province_data()
    history_list = list()
    for k,v in province_data.iteritems():
        p = Province.objects.filter(name = k)
        if not p:
            continue
        des_list = ProvinceTrafficPercentageModel.objects.filter(province = p[0])
        if not des_list:
            p_p = ProvinceTrafficPercentageModel()
            p_p.province = p[0]
            p_p.percentage = v
            p_p.save()
        else:
            des_p = des_list[0]
            des_p.percentage = v
            des_p.save()
        ###存入历史
        p_history = ProvinceTrafficPercentageHistoryModel()
        p_history.province = p[0]
        p_history.percentage = v
        history_list.append(p_history)
    if history_list:
        ProvinceTrafficPercentageHistoryModel.objects.bulk_create(history_list)
    logger.info("--End grafana task--")

ymdhms = '%Y-%m-%d %H:%M:%S'


def get_province_avg_task(period_day):
    logger.info("--Start province avg task--")
    from lugtm.datamodel.models import Province,ProvinceAvgPercentageModel
    from lugtm.management.platform.service.base_data import query_province_avg_value
    from lugtm.management.platform.service.grafana_service import grafana_province_data_history

    now_time = datetime.datetime.now()
    start_time = now_time-datetime.timedelta(days=period_day)
    start_str = start_time.strftime(ymdhms)
    end_str = now_time.strftime(ymdhms)
    #province_avg_dict = query_province_avg_value(start_str,end_str)
    province_avg_dict = grafana_province_data_history()
    for k,v in province_avg_dict.iteritems():
        p = Province.objects.filter(name = k)
        if not p:
            continue
        des_list = ProvinceAvgPercentageModel.objects.filter(province=p[0])
        if not des_list:
            p_p = ProvinceAvgPercentageModel()
            p_p.province = p[0]
            p_p.percentage_avg = v
            p_p.save()
        else:
            des_p = des_list[0]
            des_p.percentage_avg = v
            des_p.save()
    logger.info("--End province avg task--")

def syn_solar_task():
    logger.info("--Start solar task--")
    from lugtm.datamodel.models import IdcPercentageModel
    from lugtm.management.platform.service.solar_service import get_solar_db
    ###获取idc占比数据
    idc_data = get_solar_db()
    for k,v in idc_data.iteritems():
        des_list = IdcPercentageModel.objects.filter(code = k)
        if not des_list:
            idc = IdcPercentageModel()
            idc.code = k
            idc.gtm_code = k
            idc.percentage = v
            idc.save()
        else:
            des_idc = des_list[0]
            des_idc.percentage = v
            des_idc.save()

    logger.info("--End solar task--")


def data_main_start():
    scheduler.add_job(func=syn_data_task,trigger='interval',id='cron_syn_dc',
                            next_run_time=datetime.datetime.now(),seconds=3600)

    #####解析同步topology
    scheduler.add_job(func=syn_topology_task,trigger='interval',id='cron_syn_tp',
                            next_run_time=datetime.datetime.now(),seconds=1800)
    ######计算流量占比
    scheduler.add_job(func=syn_grafana_task,trigger='interval',id='cron_syn_grafana',
                            next_run_time=datetime.datetime.now(),seconds=60)
    #####解析同步solarwinds
    scheduler.add_job(func=syn_solar_task,trigger='interval',id='cron_syn_solar',
                            next_run_time=datetime.datetime.now(),seconds=60)
    from lugtm.settings import DATA_PERIOD
    args = (DATA_PERIOD,)
    scheduler.add_job(func=get_province_avg_task,trigger='interval',id='cron_syn_avg',
                            next_run_time=datetime.datetime.now(),seconds=300,args=args)
    scheduler.start()
    print "Scheduler start."
