#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/3/29
from __future__ import division
from elasticsearch import Elasticsearch
from apscheduler.schedulers.background import BackgroundScheduler
import lugtm.base_sys.client_factory as clientFactory
import datetime
import logging,time
from apscheduler.events import EVENT_JOB_ERROR, EVENT_JOB_MISSED
from datetime import date, timedelta
scheduler = BackgroundScheduler()
logger = logging.getLogger("lugtm.task")

bigip = clientFactory.sbigip()


province_info = {
            "Beijing": "北京",
            "Guizhou": "贵州",
            "Henan": "河南",
            "Shandong": "山东",
            "Sichuan": "四川",
            "Jiangsu": "江苏",
            "Qinghai": "青海",
            "Xinjiang Uyghur Autonomous Region": "新疆",
            "Fujian": "福建",
            "Zhejiang": "浙江",
            "Hubei": "湖北",
            "Tianjin": "天津",
            "Jiangxi": "江西",
            "Hainan": "海南",
            "Heilongjiang": "黑龙江",
            "Guangdong": "广东",
            "Yunnan": "云南",
            "Guangxi": "广西",
            "Shaanxi": "陕西",
            "Gansu": "甘肃",
            "Hebei": "河北",
            "Jilin": "吉林",
            "Chongqing": "重庆",
            "Ningxia Hui Autonomous Region": "宁夏",
            "Hunan": "湖南",
            "Inner Mongolia Autonomous Region": "内蒙古",
            "Shanghai": "上海",
            "Shanxi": "山西",
            "Tibet": "西藏",
            "Liaoning": "辽宁",
            "Anhui": "安徽",
            "Hongkong": "香港",
            "Macao": "澳门",
            "Taibet city": "台湾",
            #"other": "Other"
        }

class Es(object):

    def __init__(self, eshost='30.68.0.95', esport=9200, esuser='elastic', espasswd='brysj^hhrhl666'):
        self.es = Elasticsearch(["http://%s:%s"%(eshost, esport)], http_auth=(esuser, espasswd))

    def index_exist(self, index):
        return self.es.indices.exists(index=index)

    def count(self, index, body):
        count = self.es.count(index=index, body=body).get("count", None)
        return count

    def search(self, index, body):
        res = self.es.search(index=index, body=body)
        return res

def err_listener(ev):
    if ev.exception:
        logger.exception('%s error.', str(ev.job))
    else:
        logger.info('%s miss', str(ev.job))


scheduler.add_listener(err_listener, EVENT_JOB_ERROR | EVENT_JOB_MISSED)


def syn_data_task():
    logger.info("--Start dc task--")
    from lugtm.management.gtm.service.datacenter import get_all_status
    from lugtm.datamodel.models import IDC,Operator,DataCenterModel
    idcs = IDC.objects.all()

    def get_idc(dc):
        result = None
        for idc in idcs:
            if idc.code in dc.name and idc.location in dc.name:
                result = idc
        return result
    ops = Operator.objects.all()

    def get_operator(dc):
        result = None
        for op in ops:
            if op.code in dc.name:
               result = op
        return result

    dc_list = get_all_status(bigip=bigip)
    # list_to_insert = list()
    for dc in dc_list:
        des_idc = get_idc(dc)
        des_ops = get_operator(dc)
        if des_idc and des_ops:
            code = dc.name[dc.name.rindex('/')+1:]
            des_list = DataCenterModel.objects.filter(code=code)
            if not des_list:
                dm = DataCenterModel()
                dm.code = code
                dm.status = dc.status
                dm.name = des_idc.name+des_ops.name
                dm.idc = des_idc
                dm.operator = des_ops
                dm.save()
            else:
                des_dm = des_list[0]
                des_dm.status = dc.status
                des_dm.name = des_idc.name+des_ops.name
                des_dm.idc = des_idc
                des_dm.operator = des_ops
                des_dm.save()
    logger.info("--End dc task--")


def syn_topology_task():
    logger.info("--Start topology task--")
    time.sleep(10)
    from lugtm.management.platform.service.topology_db_service import load_gtm_topology_to_db
    load_gtm_topology_to_db()
    logger.info("--End topology task--")


def syn_grafana_task():
    logger.info("--Start grafana task--")
    from lugtm.datamodel.models import IdcPercentageModel,Province,ProvinceTrafficPercentageModel,ProvinceTrafficPercentageHistoryModel
    from lugtm.management.platform.service.grafana_service import grafana_idc_data,grafana_province_data
    ###获取idc占比数据
    idc_data = grafana_idc_data()
    for k,v in idc_data.iteritems():
        des_list = IdcPercentageModel.objects.filter(code = k)
        if not des_list:
            idc = IdcPercentageModel()
            idc.code = k
            idc.gtm_code = k
            idc.percentage = v
            idc.save()
        else:
            des_idc = des_list[0]
            des_idc.percentage = v
            des_idc.save()
    grafana_idc_data
    ###获取省份占比数据
    province_data = grafana_province_data()
    history_list = []
    for k,v in province_data.iteritems():
        p = Province.objects.filter(name = k)
        if not p:
            continue
        des_list = ProvinceTrafficPercentageModel.objects.filter(province = p[0])
        if not des_list:
            p_p = ProvinceTrafficPercentageModel()
            p_p.province = p[0]
            p_p.percentage = v
            p_p.save()
        else:
            des_p = des_list[0]
            des_p.percentage = v
            des_p.save()
        ###存入历史
        p_history = ProvinceTrafficPercentageHistoryModel()
        p_history.province = p[0]
        p_history.percentage = v
        history_list.append(p_history)
    if history_list:
        ProvinceTrafficPercentageHistoryModel.objects.bulk_create(history_list)
    logger.info("--End grafana task--")


def get_es_province_count(index, es):
    body = {
        "query": {
            "match_all": {}
        },
        "size": 0,
        "aggs": {
            "RN": {
                "terms": {
                    "field": "geoip.region_name.keyword",
                    "size": 1000
                }
            }
        }
    }
    search_res = es.search(index=index, body=body)
    res = search_res.get("aggregations").get("RN").get("buckets")
    total = search_res.get("hits").get("total")
    return res, total


def get_es_data():
    res = {}
    for _, province in province_info.items():
        res[province] = 1
    es = Es()
    index_list = []
    for i in range(-2, 1):
        day = (date.today() + timedelta(days=i)).strftime("%Y-%m-%d")
        index_list.append("nginxlog-lufax-accessctl-"+day)
    count = len(province_info)
    for index in index_list:
        if es.index_exist(index):
            province_res, total = get_es_province_count(index, es)
            count += total
            for province in province_res:
                name = province.get("key")
                doc_count = province.get("doc_count")
                if name in province_info.keys():
                    res[province_info.get(name)] += doc_count
            mcat_count = es.count(index, {"query": {"match": {"host": "mcat.lu.com"}}})
            count = count - mcat_count
    province_all_count = 1
    for province, num in res.items():
        res[province] = round(float(num/count), 4)
        province_all_count += num
    res["Other"] = round(float((count-province_all_count)/count), 4)
    for _, province in province_info.items():
        if province not in res.keys():
            res[province] = 0
    return res


def syn_es_data():
    from lugtm.datamodel.models import Province, ProvinceTrafficPercentageModel, ProvinceTrafficPercentageHistoryModel
    # provinces = Province.objects.all()
    # for p in provinces:
    #     name = p.name
    #     province_list.append(name)
    history_list = []
    es_data = get_es_data()
    logger.info("es_data111:" + str(es_data))
    for k, v in es_data.iteritems():
        p = Province.objects.filter(name=k)
        if not p:
            continue
        des_list = ProvinceTrafficPercentageModel.objects.filter(province=p[0])
        if not des_list:
            p_p = ProvinceTrafficPercentageModel()
            p_p.province = p[0]
            p_p.percentage = v
            p_p.save()
        else:
            des_p = des_list[0]
            des_p.percentage = v
            des_p.save()
        ###存入历史
        p_history = ProvinceTrafficPercentageHistoryModel()
        p_history.province = p[0]
        p_history.percentage = v
        history_list.append(p_history)
    if history_list:
        ProvinceTrafficPercentageHistoryModel.objects.bulk_create(history_list)
    logger.info("--End grafana task--")


ymdhms = '%Y-%m-%d %H:%M:%S'


def get_province_avg_task(period_day):
    logger.info("--Start province avg task--")
    from lugtm.datamodel.models import Province, ProvinceAvgPercentageModel
    from lugtm.management.platform.service.base_data import query_province_avg_value
    from lugtm.management.platform.service.grafana_service import grafana_province_data_history

    now_time = datetime.datetime.now()
    start_time = now_time-datetime.timedelta(days=period_day)
    start_str = start_time.strftime(ymdhms)
    end_str = now_time.strftime(ymdhms)
    # province_avg_dict = query_province_avg_value(start_str,end_str)
    province_avg_dict = grafana_province_data_history()
    for k,v in province_avg_dict.iteritems():
        p = Province.objects.filter(name = k)
        if not p:
            continue
        des_list = ProvinceAvgPercentageModel.objects.filter(province=p[0])
        if not des_list:
            p_p = ProvinceAvgPercentageModel()
            p_p.province = p[0]
            p_p.percentage_avg = v
            p_p.save()
        else:
            des_p = des_list[0]
            des_p.percentage_avg = v
            des_p.save()
    logger.info("--End province avg task--")


def syn_solar_task():
    logger.info("--Start solar task--")
    from lugtm.datamodel.models import IdcPercentageModel
    from lugtm.management.platform.service.solar_service import get_solar_db
    ###获取idc占比数据
    idc_data = get_solar_db()
    for k,v in idc_data.iteritems():
        des_list = IdcPercentageModel.objects.filter(code = k)
        if not des_list:
            idc = IdcPercentageModel()
            idc.code = k
            idc.gtm_code = k
            idc.percentage = v
            idc.save()
        else:
            des_idc = des_list[0]
            des_idc.percentage = v
            des_idc.save()

    logger.info("--End solar task--")


def data_main_start():
    scheduler.add_job(func=syn_data_task,trigger='interval',id='cron_syn_dc',
                            next_run_time=datetime.datetime.now(),seconds=1800)

    #####解析同步topology
    scheduler.add_job(func=syn_topology_task,trigger='interval',id='cron_syn_tp',
                            next_run_time=datetime.datetime.now(),seconds=900)
    ######计算流量占比
    #scheduler.add_job(func=syn_grafana_task,trigger='interval',id='cron_syn_grafana',
    #                         next_run_time=datetime.datetime.now(),seconds=60)
    scheduler.add_job(func=syn_es_data, trigger='interval',id='syn_es_data',
                            next_run_time=datetime.datetime.now(), seconds=60)
    #####解析同步solarwinds
    # scheduler.add_job(func=syn_solar_task,trigger='interval',id='cron_syn_solar',
    #                         next_run_time=datetime.datetime.now(),seconds=60)
    # from lugtm.settings import DATA_PERIOD
    # args = (DATA_PERIOD,)
    # scheduler.add_job(func=get_province_avg_task,trigger='interval',id='cron_syn_avg',
    #                         next_run_time=datetime.datetime.now(),seconds=120,args=args)
    scheduler.start()

