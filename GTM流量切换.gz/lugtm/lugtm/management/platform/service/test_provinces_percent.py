# -*- coding: utf-8 -*-
import datetime
import requests
import elasticsearch
import traceback
import time
import json


def update_provinces_percent_from_es_v2():
    cur_time = int(time.time()-60*60*8)
    # 5 minites
    cur_time_start_str = str(cur_time - 300)
    cur_time_end_str = str(cur_time)

    start_str = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(int(cur_time_start_str)))
    end_str = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(int(cur_time_end_str)))

    cur_readable_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur_index = 'nginxlog-lufax-accessweb-%s' % (datetime.datetime.now().strftime("%Y-%m-%d"))

    payload = {
        'user': 'pub_ljsitsm',
        'password': '123QWEasd?',
        'email': ''
    }

    payload = {
        'user': 'shishimin340',
        'password': 'such@r995gance',
        'email': ''
    }

    payload2 = {'search_type': 'query_then_fetch', 'ignore_unavailable': True, 'index': [cur_index]}
    payload3 = {'size': 0,
       'query': {
           'bool': {
               'filter': [
                   {'range': {
                       '@timestamp': {
                           'gte': start_str, 'lte': end_str,
                           # 'format': 'epoch_millis'
                       }
                   }},
                   {'query_string': {
                       'analyze_wildcard': True,
                       'query': 'request_uri: * AND (idc: "WGQ" OR idc: "BX")'
                   }}
               ]
           }
       },
       'aggs': {'3': {'terms': {'field': 'geoip.region_name.keyword', 'size': 84,
                                'order': {'1': 'desc'},
                                'min_doc_count': 1},
                      'aggs': {
                          '1': {'sum': {'field': 'body_bytes_sent'}},
                          '2': {'date_histogram': {'interval': '2m', 'field': '@timestamp', 'min_doc_count': 0,
                                                   'extended_bounds': {'min': start_str, 'max': end_str}},
                                'aggs': {'1': {'sum': {'field': 'body_bytes_sent'}}}}}
                      }
                }
       }
    print(json.dumps(payload3))
    # Use 'with' to ensure the session context is closed after use.
    with requests.Session() as s:
        my_p = s.post('http://grafana5.op.lufax.tool/grafana5/login', data=json.dumps(payload),
                      headers={'Content-type': 'application/json'})
        if my_p.status_code != 200:
            print('Auth failed!!! content is %s, time is %s' % (my_p.content, cur_readable_time))
            return False

        # print my_p.text
        my_p = s.post('http://grafana5.op.lufax.tool/grafana5/api/datasources/proxy/55/_msearch',
                      data=json.dumps(payload2) + '\n' + json.dumps(payload3) + '\n',
                      headers={'Content-Type': 'application/json'})
        if my_p.status_code != 200:
            print('grafana failed!!! content is %s, time is %s' % (my_p.content, cur_readable_time))
            return False

    cur_result = my_p.json()['responses'][0]['aggregations']['3']['buckets']
    # from ipdb import set_trace; set_trace()
    print(my_p.json())
    print('payload3 is %s, cur_result is %s' % (payload3, cur_result))
    if cur_result:
        initial_pecent_list = [{'province_id': x, 'data_time': cur_readable_time, 'percentage': 0.0} for x in
                               range(1, 36)]

        # get province dict
        # provinces_id_name_dict = {}
        provinces_name_id_dict = {}
        # provinces = Province.objects.all()
        provinces_bytes_dict = {}

        PROVINCE = [
            "BeiJing",
            "GuiZhou",
            "HeNan",
            "ShanDong",
            "SiChuan",
            "JiangSu",
            "QingHai",
            "XinJiang",
            "FuJian",
            "ZheJiang",
            "HuBei",
            "TianJin",
            "JiangXi",
            "HaiNan",
            "HeiLongJiang",
            "GuangDong",
            "YunNan",
            "GuangXi",
            "ShanXi_XA",
            "GanSu",
            "HeBei",
            "JiLin",
            "ChongQing",
            "NingXia",
            "HuNan",
            "NeiMengGu",
            "ShangHai",
            "ShanXi_TY",
            "XiZang",
            "LiaoNing",
            "AnHui",
        ]

        for index, p in enumerate(PROVINCE):
            # provinces_id_name_dict[p.id] = p.name
            provinces_name_id_dict[p.lower()] = index+1
            provinces_bytes_dict[index+1] = 0

        exception_province_dict = {}
        provinces_bytes_dict[35] = 0
        total_bytes = 0.0
        # exception_bytes = 0.0
        exception_list = []
        print('cur_result is %s, len is %s' % (cur_result, len(cur_result)))
        # from ipdb import set_trace; set_trace()
        for item in cur_result:
            cur_province_val = item['1']['value'] / len(item['2']['buckets'])
            tmp_province_id = provinces_name_id_dict.get(item['key'].lower(), '')
            total_bytes += cur_province_val
            if tmp_province_id in provinces_bytes_dict.keys():
                provinces_bytes_dict[tmp_province_id] = cur_province_val
            else:
                provinces_bytes_dict[35] += cur_province_val
                exception_province_dict[item['key'].lower()] = cur_province_val

        for cur_key, _ in provinces_bytes_dict.items():
            provinces_bytes_dict[cur_key] = round(provinces_bytes_dict[cur_key] / total_bytes, 5)

        # from ipdb import set_trace; set_trace()
        print('provinces_bytes_dict is %s, , total_bytes is %s cur_time is %s' % (
            provinces_bytes_dict, total_bytes, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        print('exception_province_dict is %s' % exception_province_dict)
        # logger.error('exception_bytes is %s, %s'%(exception_bytes, exception_bytes/total_bytes))

        # save it to DB
        # for item in initial_pecent_list:
        #     ProvinceTrafficPercentageModel.objects.filter(province_id=item['province_id']).update(
        #         percentage=provinces_bytes_dict[item['province_id']], data_time=item['data_time'])

    return True


update_provinces_percent_from_es_v2()
