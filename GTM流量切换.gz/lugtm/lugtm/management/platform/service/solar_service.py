#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/4/6

import pymssql
from lugtm.settings import SolarWinds_Db,SolarWinds_Host,SolarWinds_Port,SolarWinds_User,SolarWinds_Pwd

from lugtm.datamodel.models import SolarWindsInternetInfoModel
from lugtm.tools.logger import servicelogger


def _get_connect():
    conn = pymssql.connect(SolarWinds_Host, SolarWinds_User, SolarWinds_Pwd, SolarWinds_Db)
    return conn
    curs = conn.cursor()
    if not curs:
        raise(NameError,"连接数据库失败")
    else:
        return curs


def get_solar_db():
    '''
    解析为占比数据({"YP":percent})
    '''
    interfaces_info = SolarWindsInternetInfoModel.objects.all()
    if not interfaces_info:
        return None
    data_dict = dict()
    total = 0
    db_conn = _get_connect()
    curs = db_conn.cursor()
    for interface_info in interfaces_info:
        idc = interface_info.idc_code
        query = 'select %s from [SolarWindsOrion].[dbo].[Interfaces] where NodeID=%s and InterfaceID=%s'%(interface_info.calculate_column,interface_info.node_id,interface_info.interface_id)
        curs.execute(query)
        resList = curs.fetchall()
        print resList[0][0]
        value = long(resList[0][0])
        total = total + value
        if data_dict.has_key(idc):
            data_dict[idc] = data_dict.get(idc) + value
        else:
            data_dict[idc] = value
    #查询完毕后必须关闭连接
    curs = None
    db_conn.close()
    if total == 0:
        return None
    result = dict()
    for k,v in data_dict.iteritems():
        result[k] = round(float(v)/total,4)
    return result


if __name__ == '__main__':
    print "test"
