#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/4/6

import json
import requests
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE","lugtm.settings")

from lugtm.settings import GRAFANA_URL,GRAFANA_KEY,GRAFANA_PERIOD

headers = {'Content-Type': 'application/json',
           'Authorization':'Bearer %s' % GRAFANA_KEY}

params = { "db":"flow",
        "epoch":"ms" }


def parse_json_resp(json_resp,key):
    '''
    解析为占比数据
    :param json_resp:
    :param key:
    :return:{"key1":0.01,"key2":0.02}
    '''
    result_data = dict()
    total = 0
    data = json_resp['results'][0]['series']
    for d in data:
        index = d["columns"].index("sum")
        tag = d["tags"][key]
        value = d["values"][0][index]
        result_data[tag] = value
        total = total + value
    for k, v in result_data.iteritems():
        if total != 0:
            result_data[k] = round(float(v)/total,4)
        else:
            result_data[k] = 0
    return result_data


def grafana_idc_data():
    '''
    获取idc占比
    :return:{"BX":0.12,"YP":0.88}
    '''
    q = "SELECT sum(total_bytes) FROM idc_domain_statuscode_bytes WHERE domain != 'default' AND time > now() - %s GROUP BY idc" \
        % GRAFANA_PERIOD
    params["q"] = q
    res = requests.get(GRAFANA_URL, params=params, headers=headers)
#### Parse the Response sent in JSON format  ###
    resp = json.loads(res.text)
    return parse_json_resp(resp, "idc")


def grafana_province_data():

    ###省份统计  idc = 'YP' AND
    q = "SELECT sum(total_bytes) FROM province_domain_operator_bytes WHERE count = '中国' AND province != '中国' " \
        "AND time > now() - %s GROUP BY province" % GRAFANA_PERIOD
    params["q"] = q
    res = requests.get(GRAFANA_URL, params=params, headers=headers)
#### Parse the Response sent in JSON format  ###
    resp = json.loads(res.text)
    return parse_json_resp(resp, "province")

if __name__ == '__main__':
    #import os
    #os.environ.setdefault("DJANGO_SETTINGS_MODULE","lugtm.settings")
    grafana_idc_data()
