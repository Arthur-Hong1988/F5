#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/18

from lugtm.datamodel.models import Province,Operator,ProvinceTrafficPercentageModel,\
    OperatorTrafficPercentageModel,IDC,OperatorUser

from lugtm.tools.logger import servicelogger

from lugtm.settings import UNDER_LINE,DATA_PERIOD,BUSINESS_RANGE_START,BUSINESS_RANGE_END
from lugtm.settings import CMDBV3_URL, CMDBV3_HEADERS, CMDBV3_SEARCH_URL
import datetime
import requests
import elasticsearch
import traceback
import time
import json


ymdhms = '%Y-%m-%d %H:%M:%S'
import logging
logger = logging.getLogger("lugtm.service")

##策略中Region为Other
Region_Other = "Other"

es = elasticsearch.Elasticsearch([{'host': 'es.local', 'port': 9200},{'host': 'es1.local', 'port': 9200},{'host': 'es2.local', 'port': 9200}])

def es_search(q=None, doc_type=None, from_=0, size=9999, source=True, index='', max_size = 20000):
    """
    查询索引
    """
    result = {}
    total = 0
    try:
        result = es.search(
            body=q,
            index=index,
            doc_type=doc_type,
            _source=source,
            from_=from_,
            size=size
        )
        total = result.get('hits').get('total')
    except:
        print traceback.format_exc()
    resp = list()
    if result and source:
        for e in result.get('hits', {}).get('hits', {}):
            resp.append(e["_source"])
    return total, resp

def update_provinces_percent_from_es():
    update_provinces_percent_from_es_v2()

def update_provinces_percent_from_es_v2():
    cur_time = int(time.time()-60*60*8)
    # 5 minites
    cur_time_start_str = str(cur_time - 300)
    cur_time_end_str = str(cur_time)

    start_str = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(int(cur_time_start_str)))
    end_str = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(int(cur_time_end_str)))

    cur_readable_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur_index = 'nginxlog-lufax-accessweb-%s' % (datetime.datetime.now().strftime("%Y-%m-%d"))

    payload = {
        'user': 'pub_ljsitsm',
        'password': '234IOPkla?',
        'email':''
    }

    payload2 = {'search_type':'query_then_fetch','ignore_unavailable':True,'index':[cur_index]}
    payload3 = {'size': 0,
                'query': {
                    'bool': {
                        'filter': [
                            {'range': {
                                '@timestamp': {
                                    'gte': start_str, 'lte': end_str,
                                    # 'format': 'epoch_millis'
                                }
                            }},
                            {'query_string': {
                                'analyze_wildcard': True,
                                'query': 'request_uri: * AND (idc: "WGQ" OR idc: "BX") AND (geoip.country_name: "China")'
                            }}
                        ]
                    }
                },
                'aggs': {'3': {'terms': {'field': 'geoip.region_name.keyword', 'size': 84,
                                         'order': {'1': 'desc'},
                                         'min_doc_count': 1},
                               'aggs': {
                                   '1': {'sum': {'field': 'body_bytes_sent'}},
                                   '2': {'date_histogram': {'interval': '2m', 'field': '@timestamp', 'min_doc_count': 0,
                                                            'extended_bounds': {'min': start_str, 'max': end_str}},
                                         'aggs': {'1': {'sum': {'field': 'body_bytes_sent'}}}}}
                               }
                         }
                }
    # payload3 = {'size':0,'query':{'bool':{'filter':[{'range':{'@timestamp':{'gte':cur_time_start_str,'lte':cur_time_end_str,'format':'epoch_millis'}}},{'query_string':{'analyze_wildcard':True,'query':'url: * AND (isAcc: True) AND ( isLegal: True) AND (idc: "WGQ" OR idc: "BX") AND(country: "中国") NOT (province: "中国")'}}]}},'aggs':{'3':{'terms':{'field':'province','size':42,'order':{'1':'desc'},'min_doc_count':1},'aggs':{'1':{'sum':{'field':'bodyBytesSent'}},'2':{'date_histogram':{'interval':'2m','field':'@timestamp','min_doc_count':0,'extended_bounds':{'min':cur_time_start_str,'max':cur_time_end_str},'format':'epoch_millis'},'aggs':{'1':{'sum':{'field':'bodyBytesSent'}}}}}}}}
    # Use 'with' to ensure the session context is closed after use.
    with requests.Session() as s:
        my_p = s.post('http://grafana5.op.lufax.tool/grafana5/login', data=json.dumps(payload), headers={'Content-type':'application/json'})
        if my_p.status_code != 200:
            logger.info('Auth failed!!! content is %s, time is %s'%(my_p.content, cur_readable_time))
            return False

        # print my_p.text
        my_p = s.post('http://grafana5.op.lufax.tool/grafana5/api/datasources/proxy/55/_msearch', data=json.dumps(payload2)+'\n'+json.dumps(payload3)+'\n', headers={'Content-Type':'application/json'})
        if my_p.status_code != 200:
            logger.info('grafana failed!!! content is %s, time is %s'%(my_p.content, cur_readable_time))
            return False

    cur_result = my_p.json()['responses'][0]['aggregations']['3']['buckets']
    #from ipdb import set_trace; set_trace()
    logger.info('payload3 is %s, cur_result is %s'%(payload3, cur_result))
    if cur_result:
        initial_pecent_list = [{'province_id':x, 'data_time':cur_readable_time, 'percentage':0.0} for x in range(1,36)]

        # get province dict
        # provinces_id_name_dict = {}
        provinces_name_id_dict = {}
        provinces = Province.objects.all()
        provinces_bytes_dict = {35: 0}
        for p in provinces:
            # provinces_id_name_dict[p.id] = p.name
            code = p.code.lower()
            if code == "shanxi_ty":
                code = "shanxi"
            elif code == "shanxi_xa":
                code = "shaanxi"
            elif code == "ningxia":
                code = "ningxia hui autonomous region"
            elif code == "xizang":
                code = "tibet"
            elif code == "neimenggu":
                code = "inner mongolia autonomous region"
            provinces_name_id_dict[code] = p.id
            provinces_bytes_dict[p.id] = 0

        exception_province_dict = {}

        total_bytes = 0.0
        # exception_bytes = 0.0
        exception_list = []

        logger.info('cur_result is %s, len is %s'% (cur_result, len(cur_result)))
        #from ipdb import set_trace; set_trace()
        for item in cur_result:
            cur_province_val = item['1']['value']/len(item['2']['buckets'])
            tmp_province_id = provinces_name_id_dict.get(item['key'].lower(), '')
            total_bytes += cur_province_val
            if tmp_province_id in provinces_bytes_dict.keys():
                provinces_bytes_dict[tmp_province_id] = cur_province_val
            else:
                provinces_bytes_dict[35] += cur_province_val
                exception_province_dict[item['key'].lower()] = cur_province_val

        for cur_key, _ in provinces_bytes_dict.items():
            provinces_bytes_dict[cur_key] = round(provinces_bytes_dict[cur_key]/total_bytes, 5)

        #from ipdb import set_trace; set_trace()
        logger.info('provinces_bytes_dict is %s, , total_bytes is %s cur_time is %s'%(provinces_bytes_dict, total_bytes, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        logger.info('exception_province_dict is %s'% exception_province_dict)
        # logger.error('exception_bytes is %s, %s'%(exception_bytes, exception_bytes/total_bytes))

        # save it to DB
        for item in initial_pecent_list:
            ProvinceTrafficPercentageModel.objects.filter(province_id=item['province_id']).update(percentage=provinces_bytes_dict[item['province_id']], data_time = item['data_time'])


    return True


def update_provinces_percent_from_es_v1():
    cur_time = time.time()*1000
    cur_time_start = cur_time-100000
    cur_readable_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur_index = 'accesslog_%s'%(datetime.datetime.now().strftime("%Y_%m_%d"))
    #query_str = '{"query":{"range":{"timestamp":{"gte":%f, "lt":%f}}}}'%(cur_time_start, cur_time)
    query_str = '{"query":{"range":{"timestamp":{"gt":%d}}}}'%(cur_time_start)
    # from ipdb import set_trace; set_trace()
    total, resp = es_search(q=query_str, source=["province", "bodyBytesSent"], index=cur_index, size = 9999)

    logger.info('query_str is %s, total is %s, cur_readable_time is %s'%(query_str, total, cur_readable_time))

    if total > 10000:
        initial_pecent_list = [{'province_id':x, 'data_time':cur_readable_time, 'percentage':0.0} for x in range(1,35)]

        # get province dict
        provinces_id_name_dict = {}
        provinces = Province.objects.all()
        provinces_bytes_dict = {}
        for p in provinces:
            provinces_id_name_dict[p.id] = p.name
            provinces_bytes_dict[p.name] = 0

        total_bytes = 0.0
        exception_bytes = 0.0
        exception_list = []
        for item in resp:
            if item['province'] in provinces_bytes_dict.keys():
                provinces_bytes_dict[item['province']] += item['bodyBytesSent']
                total_bytes += item['bodyBytesSent']
            else:
                exception_bytes += item['bodyBytesSent']
                exception_list.append(item)

        for cur_key, _ in provinces_bytes_dict.items():
            provinces_bytes_dict[cur_key] = round(provinces_bytes_dict[cur_key]/total_bytes, 5)

        logger.info('provinces_bytes_dict is %s, , total_bytes is %s cur_time is %s'%(provinces_bytes_dict, total_bytes, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        logger.error('exception_list is %s'%exception_list)
        logger.error('exception_bytes is %s, %s'%(exception_bytes, exception_bytes/total_bytes))

        # save it to DB
        for item in initial_pecent_list:
            ProvinceTrafficPercentageModel.objects.filter(province_id=item['province_id']).update(percentage=provinces_bytes_dict[provinces_id_name_dict[item['province_id']]], data_time = item['data_time'])


    return total




#@servicelogger
def get_all_provinces_percentage():
    '''
    获取省份比例数据
    :return:
    '''
    logger.info('ENTER ++++++++++')
    result = []
    from lugtm.management.gtm.service.idc_service import get_topology_summary_dict_load
    topology_summary_dict = get_topology_summary_dict_load()

    def get_des_dc(province):
        idc_name1 = None
        if province.code == "Other":
            other_topology = topology_summary_dict.get(Region_Other)
            first_dc = None
            for t in other_topology:
                if 'SH' in t.get("dc_name"):
                    first_dc = t.get("dc_name")
                    break
            if first_dc:
                idc_code = first_dc.split(UNDER_LINE)[1]
                idc = IDC.objects.filter(code=idc_code)
                idc_name1 = idc[0].name if idc else ""
        else:
            for k,v in topology_summary_dict.iteritems():
                if province.code in k and u"CMCC" not in k:
                    dc = v[0].get("dc_name")
                    # XiangGang 优先访问新加坡 ["SG_KJ_Singtel", "SG_KJ_PCCW", "SG_SG3_Equinix", "SG_SG3_Singtel", "SH_WGQ_CTC", "SH_BX_CTC",
                    #             "SH_WGQ_CNC", "SH_BX_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"],
                    if p.code == 'XiangGang':
                        dc = v[4].get("dc_name")
                    idc_code = dc.split(UNDER_LINE)[1]
                    idc = IDC.objects.filter(code=idc_code)
                    if idc:
                        idc_name1 = idc[0].name
                        break
        return idc_name1
    # now_time = datetime.datetime.now()
    # start_time = now_time-datetime.timedelta(days=DATA_PERIOD)
    # start_str = start_time.strftime(ymdhms)
    # end_str = now_time.strftime(ymdhms)

    ###处理默认策略(Region为Other的)
    # other_topology = topology_summary_dict.get(Region_Other)
    # first_dc = None
    # for t in other_topology:
    #     if 'SH' in t.get("dc_name"):
    #         first_dc = t.get("dc_name")
    #         break
    # idc_name = ""
    # if first_dc:
    #     idc_code = first_dc.split(UNDER_LINE)[1]
    #     idc = IDC.objects.filter(code=idc_code)
    #     idc_name = idc[0].name if idc else ""
    # dict_other = dict()
    # dict_other["province"] = Region_Other
    # dict_other["to_idc"] = idc_name
    # dict_other["percentage"] = 0
    # dict_other["avg_percentage"] = 0
    # dict_other["operator"] = list()
    # result.append(dict_other)

    province_avg_dict = query_province_avg_value_by_task()
    provinces = Province.objects.all()
    for p in provinces: 
        p_dict = dict()
        p_dict["province"] = p.name
        idc_name = get_des_dc(p)
        if idc_name:
            p_dict["to_idc"] = idc_name
        provinces_percent = ProvinceTrafficPercentageModel.objects.filter(province=p)
        if provinces_percent:
            p_dict["percentage"] = provinces_percent[0].percentage
            p_dict["data_time"] = provinces_percent[0].data_time
        if p.name in province_avg_dict:
            p_dict["avg_percentage"] = province_avg_dict.get(p.name)
        operators_percent = OperatorTrafficPercentageModel.objects.filter(province_id=p.id)
        o_list = list()
        for o in operators_percent:
            o_dict = {k:v for k,v in o.__dict__.iteritems() if not k.startswith('_')}
            o_dict["name"] = o.operator_user.name
            o_list.append(o_dict)
        p_dict["operator"] = o_list
        result.append(p_dict)
    return result


def query_all_provinces_percentage_order():
    return ProvinceTrafficPercentageModel.objects.all().order_by('-percentage')


def query_raw_sql_avg_value(start_time,end_time):
    '''
    获取省份平均sql的result
    :param start_time:
    :param end_time:
    :return:[(avg_value,province_name,province_code),(avg_value,province_name,province_code)]
    '''
    sql = "SELECT ROUND(avg(a.percentage),4) as avg_value,b.name as province_name,b.code as code from tb_province_traffic_percentage_history a, tb_province b WHERE a.province_id = b.id and a.data_time>='"\
          +start_time+"' and a.data_time<='"+end_time+"' and DATE_FORMAT(a.data_time,'%H:%i:%s')<='"\
          +BUSINESS_RANGE_END+"' and DATE_FORMAT(a.data_time,'%H:%i:%s')>='"+BUSINESS_RANGE_START+"' GROUP BY b.name"
    from django.db import connection,transaction
    cursor = connection.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    connection.close()
    return rows
    # for row in rows:
    #     print row[0],row[1],row[2]


def query_province_avg_value(start_time,end_time):
    '''
    获取省份平均sql的result
    :param start_time:
    :param end_time:
    :return:{"北京":avg_value}
    '''
    result = dict()
    sql = "SELECT ROUND(avg(a.percentage),4) as avg_value,b.name as province_name,b.code as code from tb_province_traffic_percentage_history a, tb_province b WHERE a.province_id = b.id and a.data_time>='"\
          +start_time+"' and a.data_time<='"+end_time+"' and DATE_FORMAT(a.data_time,'%H:%i:%s')<='"\
          +BUSINESS_RANGE_END+"' and DATE_FORMAT(a.data_time,'%H:%i:%s')>='"+BUSINESS_RANGE_START+"' GROUP BY b.name"
    from django.db import connection
    cursor = connection.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    connection.close()
    for row in rows:
        result[row[1]] = row[0]
    return result


def query_province_avg_value_by_task():
    result = dict()
    from lugtm.datamodel.models import ProvinceAvgPercentageModel
    alls = ProvinceAvgPercentageModel.objects.all()
    for a in alls:
        result[a.province.name] = a.percentage_avg
    return result


@servicelogger
def get_all_provinces_avg_percentage(start_time=datetime.datetime.now()-datetime.timedelta(days=DATA_PERIOD),end_time=datetime.datetime.now()):
    '''
    获取省份比例数据
    :return:
    '''
    result = []
    from lugtm.management.gtm.service.idc_service import get_topology_summary_dict_load
    topology_summary_dict = get_topology_summary_dict_load()

    def get_des_dc(province_code):
        idc_name1 = None
        for k,v in topology_summary_dict.iteritems():
            if province_code in k:
                dc = v[0].get("dc_name")
                # XiangGang 优先访问新加坡 ["SG_KJ_Singtel", "SG_KJ_PCCW", "SG_SG3_Equinix", "SG_SG3_Singtel", "SH_WGQ_CTC", "SH_BX_CTC",
                #             "SH_WGQ_CNC", "SH_BX_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"],
                if p.code == 'XiangGang':
                    dc = v[4].get("dc_name")
                idc_code = dc.split(UNDER_LINE)[1]
                idc = IDC.objects.filter(code=idc_code)
                if idc:
                    idc_name1 = idc[0].name
                    break
        return idc_name1
    # from django.db.models import Avg
    # historys_model = ProvinceTrafficPercentageHistoryModel.objects.filter(data_time__gte=start_time,
    #                                                                       data_time__lte=end_time)
    # business_start_hour,business_start_minute,\
    # business_end_hour,business_end_minute = get_business_range_time()
    # print start_time.time()
    # print end_time.time()
    # avg_value = Province.objects.filter(provincetrafficpercentagehistorymodel__data_time__gte=start_time,
    #                                     provincetrafficpercentagehistorymodel__data_time__lte=end_time,
    #                                     provincetrafficpercentagehistorymodel__data_time__hour__gte=business_start_hour,
    #                                     provincetrafficpercentagehistorymodel__data_time__hour__lte=business_end_hour
    #                                     ).annotate(avg_r = Avg('provincetrafficpercentagehistorymodel__percentage'))
    start_str = start_time.strftime(ymdhms)
    end_str = end_time.strftime(ymdhms)
    provinces = query_raw_sql_avg_value(start_str,end_str)
    for p in provinces:
        p_dict = dict()
        p_dict["province"] = p[1]
        idc_name = get_des_dc(p[2])
        if idc_name:
            p_dict["to_idc"] = idc_name
        p_dict["avg_percentage"] = p[0]
        result.append(p_dict)
    return result


def get_region_cn_name(region_name):
    '''
    根据region_name获取对应中文名称
    :param  region_name: CN_HeBei_CTC
    :return: 中文名称：河北电信用户
    '''
    p_name,user_name = None,None
    if region_name and region_name != Region_Other:
        s_list = region_name.split('_')
        if len(s_list) == 2:
            province_code = s_list[1]
            operator_user_code = 'CTC'
        else:
            province_code = region_name[region_name.index('_')+1:region_name.rindex('_')]
            operator_user_code = region_name[region_name.rindex('_')+1:]
        provinces = Province.objects.filter(code = province_code)
        operator_users = OperatorUser.objects.filter(code = operator_user_code)
        if provinces and operator_users:
            p_name,user_name = provinces[0].name, operator_users[0].name
    elif region_name == Region_Other:
        p_name=Region_Other
        user_name=""
    return p_name,user_name


def get_datacenter_cn_name(dc_name):
    '''
    根据dc_name获取对应中文名称
    :param  dc_name: SH_YP_CTC
    :return: 中文名称：杨浦电信
    '''
    idc_name,o_name = "",""
    if dc_name:
        code_list = dc_name.split(UNDER_LINE)
        if len(code_list) >= 3:
            idc_code = code_list[1]
            operator_code = code_list[2]
            if code_list[0] == 'SG':
                idc_code = 'XJP'
                operator_code = 'CTC'
            idcs = IDC.objects.filter(code = idc_code)
            operators = Operator.objects.filter(code = operator_code)
            if idcs and operators:
                idc_name,o_name = idcs[0].name, operators[0].name
    return idc_name,o_name


def get_province_models(provinces_str):
    '''
    根据省份名称字串获取省份对应model的list
    :param provinces_str: 省份名1,省份名2
    :return:
    '''
    p_obs = list()
    p_list = provinces_str.split(",")
    for province_name in p_list:
        province = Province.objects.filter(name=province_name)
        if province:
            p_obs.append(province[0])
    return p_obs


def get_province_models_all(source_idc):
    '''
    根据省份名称字串获取省份对应model的list
    :param provinces_str: 省份名1,省份名2
    :return:
    '''
    p_obs = list()
    s_sgin = False
    p_list = get_all_provinces_percentage()
    logger.info('MIAO+++ p_list is %s, Region_other is %s'%(p_list,Region_Other))
    for province_name in p_list:
        if province_name['to_idc'] == source_idc:
            if province_name['province'] ==  Region_Other:
                s_sgin = True
            province = Province.objects.filter(name=province_name['province'])
            if province:
                p_obs.append(province[0])
    return p_obs,s_sgin

def get_idc_models(idc_cn_name):
    '''
    根据机房名称获取对应model
    :param idc_cn_name: 机房名
    :return:
    '''
    idc_m = None
    d_idcs = IDC.objects.filter(name=idc_cn_name)
    if d_idcs:
        idc_m = d_idcs[0]
    return idc_m


def get_idc_scale_data():
    '''
    获取机房比例组合数据
    :return:
    '''
    result = list()
    sql = "SELECT idc_name,scale from tb_province_idc_distribution GROUP BY idc_name,scale"
    from django.db import connection
    cursor = connection.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    connection.close()
    if len(rows) % 2 != 0:
        return result

    def get_other_idc(name,scale):
        other_scale1 = 10 - scale
        for r in rows:
            if r[0] != name and r[1] == other_scale1:
                return r[0], other_scale1
        return None,None

    def is_exist(idc_dict):
        for dd in result:
            for k,v in idc_dict.iteritems():
                if k in dd:
                    v1 = dd[k]
                    if v1 == v:
                        return True
        return False

    for row in rows:
        d = dict()
        d[row[0]] = row[1]
        other_name,other_scale = get_other_idc(row[0],row[1])
        if other_name and other_scale:
            d[other_name] = other_scale
            if not is_exist(d):
                result.append(d)
    return result


def get_idc_scale_province(idc_name,scale):
    '''
    根据机房名和比例获取省份名的list
    :param idc_name:
    :param scale:
    :return:
    '''
    result = list()
    from lugtm.datamodel.models import ProvinceIdcDistributionModel
    datas = ProvinceIdcDistributionModel.objects.filter(idc_name=idc_name, scale=int(scale))
    for data in datas:
        result.append(data.province_name)
    return result


@servicelogger
def get_all_provinces():
    result = []
    provinces = Province.objects.all()
    for province in provinces:
        p_dict = {k:v for k,v in province.__dict__.iteritems() if not k.startswith('_')}
        p_dict["zone_id"] = province.zone.id
        p_dict["zone_name"] = province.zone.name
        result.append(p_dict)
    return result


@servicelogger
def get_province_by_id(province_id):
    province = Province.objects.get(pk=province_id)
    if province:
        return {k:v for k,v in province.__dict__.iteritems() if not k.startswith('_')}
    else:
        return {}


@servicelogger
def get_province_by_name(chinese_name):
    provinces = Province.objects.filter(name=chinese_name)
    if provinces:
        return provinces[0]
    else:
        return {}


@servicelogger
def get_all_operators():
    result = []
    operators = Operator.objects.all()
    if operators:
        for operator in operators:
            result.append({k:v for k,v in operator.__dict__.iteritems() if not k.startswith('_')})
    return result


@servicelogger
def get_operator_by_id(operator_id):
    operator = Operator.objects.get(pk=operator_id)
    if operator:
        return {k:v for k,v in operator.__dict__.iteritems() if not k.startswith('_')}
    else:
        return {}

@servicelogger
def get_cmdbv3_table_dict(table_name, column_list, **kwargs):
    cur_url = '%s%s?q_columns=%s'% (CMDBV3_URL, table_name,  column_list)
    search_type = kwargs.pop('type', None)
    if search_type and search_type=='search':
        cur_url = '%s%s?q_columns=%s'% (CMDBV3_SEARCH_URL, table_name,  column_list)

    url_prefix = ''
    for cur_key, cur_val in kwargs.items():
        url_prefix += '&' + str(cur_key) + '=' + str(cur_val)
    cur_url += url_prefix
    r = requests.get(cur_url.replace("'",'"'), headers=CMDBV3_HEADERS)
    #from ipdb import set_trace; set_trace()
    result = r.json()['data']

    return result



