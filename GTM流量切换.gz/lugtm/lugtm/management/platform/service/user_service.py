#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/4/6

import requests
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import User
from lugtm.settings import SSO_APP_ID,SSO_APP_SECRET,SSO_URL


def get_username(request):
    '''
    根据请求获取登录用户名
    '''
    token = request.META.get('HTTP_X_CSRF_TOKEN',None)
    if not token:
        return None

    token_model = Token.objects.get(key=token)
    user = token_model.user
    return user.username


def create_user(username,password):
    users = User.objects.filter(username=username)
    if not users:
        user = User.objects.create_user(username=username, password=password,is_active=True)
    else:
        user = users[0]
    return user


def login_sso(username,password):
    body = {"um": username,
                "password": password,
                "is_debug": False,
                "app":SSO_APP_ID}
    zh_name, token, permissions = "", "", ""
    try:
        res = requests.post("%s/passport/account/api_login.json"%SSO_URL, body).json()
        token = res.get("data")
        if token:
            params = {"token": token,
                      "secret": SSO_APP_SECRET,
                      "app": SSO_APP_ID}
            user_info = requests.post("%s/passport/account/user_info.json"%SSO_URL, params).json()
            zh_name = user_info.get("data", {}).get('name', '')
            permissions = user_info.get("data", {}).get('permissions', [])
        return token, permissions,""
    except Exception, e:
        return token, permissions, e

