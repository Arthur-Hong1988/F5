#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/4/6

from lugtm.datamodel.models import TopologyRecordModel
import lugtm.base_sys.client_factory as clientFactory
from lugtm.management.gtm.service.topology import get_all_topology,get_topology_weight_by_records
from lugtm.management.platform.service.base_data import Region_Other
import logging,copy
from collections import OrderedDict

bigip=clientFactory.sbigip()

logger = logging.getLogger("lugtm.service")


def get_topology_summary_dict():
    '''
    获取gtm的最新topology字典
    :return: {CN_GuangXi_CTC: [{'dc_name': SH_YP_CTC, 'weight': 3090L,"order":366}, {'dc_name':SH_YP_CNC, 'weight': 3085L}, {'dc_name':SH_YP_CMCC, 'weight': 3080L}, {'dc_name':SH_BX_CTC, 'weight': 3075L}, {'dc_name': SH_BX_CNC, 'weight': 3070L}, {'dc_name': SH_YP_ALI, 'weight': 3065L}]}
    '''
    data_dict = OrderedDict()
    topologies = get_all_topology(bigip=bigip)
    logger.info('All topologies are %s'%topologies)
    weights,orders = get_topology_weight_by_records(topologies,bigip=bigip)
    logger.info('After All topologies are %s'%topologies)
    logger.info('After All weights are %s'%weights)
    logger.info('After All orders  are %s'%orders)

    for i in range(len(topologies)):
        tp = topologies[i]
        wt = weights[i]
        order = orders[i]
        dc_name = tp.server.content
        region_name = tp.ldns.content
        dc_name = dc_name[dc_name.rindex('/')+1:]
        region_name = region_name[region_name.rindex('/')+1:]
        if region_name in data_dict and data_dict.get(region_name):
            dc_list = data_dict.get(region_name)
            dc_w = OrderedDict()
            dc_w["weight"] = wt
            dc_w["dc_name"] = dc_name
            dc_w["order"] = order
            length = len(dc_list)
            index = 0
            for j in range(length):
                wt_t = dc_list[j].get("weight")
                if j == 0 and int(wt) >= int(wt_t):
                    index = j
                    break
                elif j == length-1 and int(wt) <= int(wt_t):
                    index = j+1
                    break
                else:
                    wt_t1 = dc_list[j+1].get("weight")
                    if int(wt)<=int(wt_t) and int(wt)>=int(wt_t1):
                        index = j+1
                        break
            dc_list.insert(index,dc_w)
            data_dict[region_name] = dc_list
        else:
            n_list = list()
            dc_w = OrderedDict()
            dc_w["weight"] = wt
            dc_w["dc_name"] = dc_name
            dc_w["order"] = order
            n_list.append(dc_w)
            data_dict[region_name] = n_list
    return data_dict


def get_topology_summary_dict_load(is_gtm=False):
    '''
    获取topology字典,通过本地数据库
    :return: {/Common/CN_GuangXi_CTC: [{'dc_name': /Common/SH_YP_CTC, 'weight': 3090L,"order":355}, {'dc_name': /Common/SH_YP_CNC, 'weight': 3085L}, {'dc_name': /Common/SH_YP_CMCC, 'weight': 3080L}, {'dc_name': /Common/SH_BX_CTC, 'weight': 3075L}, {'dc_name': /Common/SH_BX_CNC, 'weight': 3070L}, {'dc_name': /Common/SH_YP_ALI, 'weight': 3065L}]}
    '''
    data_dict = OrderedDict()
    if is_gtm:
        return get_topology_summary_dict()
    topologies = TopologyRecordModel.objects.order_by('weight').reverse()
    for tp in topologies:
        wt = tp.weight
        order = tp.order
        dc_name = tp.datacenter
        region_name = tp.region
        dc_w = OrderedDict()
        dc_w["weight"] = wt
        dc_w["dc_name"] = dc_name
        dc_w["order"] = order
        if region_name in data_dict:
            # length = len(dc_list)
            # index = 0
            # for j in range(length):
            #     wt_t = dc_list[j].get("weight")
            #     if j==0 and int(wt)>=int(wt_t):
            #         index = j
            #         break
            #     elif j==length-1 and int(wt)<=int(wt_t):
            #         index = j+1
            #         break
            #     else:
            #         wt_t1 = dc_list[j+1].get("weight")
            #         if int(wt)<=int(wt_t) and int(wt)>=int(wt_t1):
            #             index = j+1
            #             break
            # dc_list.insert(index,dc_w)
            data_dict[region_name].append(dc_w)
        else:
            n_list = list()
            n_list.append(dc_w)
            data_dict[region_name] = n_list
    return data_dict


def get_now_province_topology_info(province_obs,is_other=False):
    '''
    获取指定省份的gtm最新策略信息
    :param province_obs:[model]
    :return: {"省份":{region_name1:[dc1,dc2],region_name2,"":[]},"省份"：{}}
    dc1 = {'dc_name': /Common/SH_YP_CTC, 'weight': 3090L,"order":355}
    '''
    tp_dict = get_topology_summary_dict_load(is_gtm=True)
    result_dict = OrderedDict()
    info = OrderedDict()
    if is_other:
        tp_list = copy.deepcopy(tp_dict.get(Region_Other))
        for tp in tp_dict.get(Region_Other):
            dc_code = tp.get("dc_name","")
            if not dc_code.startswith("SH"):
                tp_list.remove(tp)
        info[Region_Other] = tp_list
        result_dict[Region_Other] = info

        return result_dict

    ##{"省份":[region_name1,region_name2],"":[]}
    for k, v in tp_dict.iteritems():
        for p in province_obs:
            if p.code in k:
                if p.name in info.keys():
                    info.get(p.name).append(k)
                else:
                    regions = list()
                    regions.append(k)
                    info[p.name] = regions
    for k1, v1 in info.iteritems():
        now_record = OrderedDict()
        for r in v1:
            now_record[r] = tp_dict.get(r)

        result_dict[k1] = now_record
    return result_dict

def get_now_province_topology_info_all(province_obs,a_other):
    '''
    获取指定省份的gtm最新策略信息
    :param province_obs:[model]
    :return: {"省份":{region_name1:[dc1,dc2],region_name2,"":[]},"省份"：{}}
    dc1 = {'dc_name': /Common/SH_YP_CTC, 'weight': 3090L,"order":355}
    '''
    tp_dict = get_topology_summary_dict_load(is_gtm=True)
    logger.info('@@@IDC_CHANGE get_now_province_topology_info_all: tp_dict is %s'%tp_dict)
    result_dict = OrderedDict()
    info = OrderedDict()
    if a_other:
        tp_list = copy.deepcopy(tp_dict.get(Region_Other))
        for tp in tp_dict.get(Region_Other):
            dc_code = tp.get("dc_name","")
            if not dc_code.startswith("SH"):
                tp_list.remove(tp)
        info[Region_Other] = tp_list
        result_dict[Region_Other] = info
        info = OrderedDict()

    ##{"省份":[region_name1,region_name2],"":[]}
    for k, v in tp_dict.iteritems():
        for p in province_obs:
            if p.code in k:
                if p.name in info.keys():
                    info.get(p.name).append(k)
                else:
                    regions = list()
                    regions.append(k)
                    info[p.name] = regions

    logger.info('@@@IDC_CHANGE get_now_province_topology_info_all: info is %s'%info)
    for k1, v1 in info.iteritems():
        now_record = OrderedDict()
        for r in v1:
            now_record[r] = tp_dict.get(r)

        result_dict[k1] = now_record
    return result_dict

def save_update_db_topology(region_name,dc_name,order,weight):
    des_list = TopologyRecordModel.objects.filter(region=region_name,datacenter=dc_name)
    if not des_list:
        dm = TopologyRecordModel()
        dm.order = order
        dm.region = region_name
        dm.datacenter = dc_name
        dm.weight = weight
        dm.save()
    else:
        des_dm = des_list[0]
        des_dm.order = order
        des_dm.weight = weight
        des_dm.save()


def update_gtm_topology_changed_to_db(new_records):
    '''
    new_records:{"省份":{region_name1:[dc1,dc2],region_name2,"":[]},"省份"：{}}
    dc1 = {'dc_name': SH_YP_CTC, 'weight': 3090L,"order":355}
    '''
    if not new_records:
        return
    for k1, v1 in new_records.iteritems():
        for region_name,dc_list in v1.iteritems():
            for dc in dc_list:
                save_update_db_topology(region_name,dc["dc_name"],dc["order"],dc["weight"])


def load_gtm_topology_to_db():
    '''
    加载最新gtm最新策略信息到db
    :return:
    '''
    from lugtm.management.gtm.service.topology import get_all_topology,get_topology_weight_by_records
    logger.info("Get gtm topology data.")
    topologies = get_all_topology(bigip=bigip)
    weights, orders = get_topology_weight_by_records(topologies,bigip=bigip)
    total = len(topologies)

    for i in range(total):
        tp = topologies[i]
        wt = weights[i]
        order = orders[i]
        dc_name = tp.server.content
        region_name = tp.ldns.content
        dc_name = dc_name[dc_name.rindex('/')+1:]
        region_name = region_name[region_name.rindex('/')+1:]
        save_update_db_topology(region_name,dc_name,order,wt)
    logger.info("Load gtm topology into db ok.Total:%s" % total)



