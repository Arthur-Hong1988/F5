#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import nose.tools as nt
from lugtm.management.platform.api.base import Province,Operator

from lugtm.tools.base import do_demo_request

province_view = Province.as_view()
operator_view = Operator.as_view()

user = {'username': u'mgm','password': u'mgm'}


class TestProvince(object):

    def setup(self):
        pass

    @nt.istest
    def test_001_get_all_provinces(self):
        response = do_demo_request('GET', '/mgm/province/', province_view,user=user)
        nt.eq_(response.status_code, 200, response.content)
        ##res = json.loads(response.content)


class TestOperator(object):

    def setup(self):
        pass

    @nt.istest
    def test_101_get_all_operators(self):
        response = do_demo_request('GET', '/mgm/operator/', operator_view,user=user)
        nt.eq_(response.status_code, 200, response.content)


