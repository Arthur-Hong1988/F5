#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/4/6

import urllib2
import json
import requests


def show_data():
    ##BaseURL = 'http://172.23.1.227:8000/api/datasources/3'
    BaseURL = 'http://172.23.1.227:8000/api/datasources/proxy/3/query?db=lma&q=select%20count(value)%20from%20virt_if_octets_rx%20where%20time%20>%20now()%20-%201h'

    data = { "db":"lma",
             "q":"select count(value) from virt_if_octets_rx where time > now() - 1h"
             }
    ##json.dumps(data)
    req = urllib2.Request(BaseURL,headers={'Content-Type': 'application/json'})
    req.add_header("Authorization", "Bearer %s" %
                   "eyJrIjoiZHRVaHlaUzVwcGpXVThnVXJUcVlqVHEzNHJ3MG5KNksiLCJuIjoiZ3RtYXBpIiwiaWQiOjF9")

#### Make REST Request  ###
    u = urllib2.urlopen(req)

#### Parse the Response sent in JSON format  ###
    resp = json.loads(u.read().decode('utf-8'))

    from pprint import pprint
#### Render the Response  ###
    pprint(resp)


def show_data_request():
    ##BaseURL = 'http://172.23.1.227:8000/api/datasources/3'
    BaseURL = 'http://172.23.1.227:8000/api/datasources/proxy/3/query'

    data = { "db":"lma",
             "q":"select count(value) from virt_if_octets_rx where time > now() - 1h"
             }
    headers = {'Content-Type': 'application/json',
               "Authorization": "Bearer %s" %
                   "eyJrIjoiZHRVaHlaUzVwcGpXVThnVXJUcVlqVHEzNHJ3MG5KNksiLCJuIjoiZ3RtYXBpIiwiaWQiOjF9"
    }
    res = requests.get(BaseURL,params=data,headers= headers)
    print res.text

#### Parse the Response sent in JSON format  ###
    resp = json.loads(res.text)

    from pprint import pprint
    pprint(resp)

def grafana_data_request():
    BaseURL = 'http://grafana.op.lufax.com/api/dashboards/db/ying-yong-liu-liang-da-pan'

    headers = {'Content-Type': 'application/json',
               "Authorization": "Bearer %s" %
                   "eyJrIjoiaHN6QXBBbGJVaVJjcXVKMDR4WkRIY0tHb2xBQ28wMlQiLCJuIjoiR1RNIiwiaWQiOjN9"
    }
    res = requests.get(BaseURL,headers= headers)
    print res.text

#### Parse the Response sent in JSON format  ###
    resp = json.loads(res.text)

    from pprint import pprint
    pprint(resp)


def grafana_data_request_sql():
    BaseURL = 'http://grafana.op.lufax.com/api/datasources/proxy/2/query'

    headers = {'Content-Type': 'application/json',
               "Authorization": "Bearer %s" %
                   "eyJrIjoiaHN6QXBBbGJVaVJjcXVKMDR4WkRIY0tHb2xBQ28wMlQiLCJuIjoiR1RNIiwiaWQiOjN9"
    }
    data = { "db":"flow",
             "q":"SELECT sum(value) FROM idc_domain_status_acc WHERE domain != 'default' AND time > now() - 1h GROUP BY idc",
             "epoch":"ms"     }

    res = requests.get(BaseURL,params=data,headers= headers)
    print res.text

#### Parse the Response sent in JSON format  ###
    resp = json.loads(res.text)

    from pprint import pprint
    pprint(resp)


def parse_grafana_results():
    text="results:" \
         "[{series: " \
         "[{columns: ['time', 'sum'],name: 'idc_domain_status_bytes',tags: {'idc': 'BX'}," \
         "values: [[1491903624414L, 750646182]]},{columns: ['time', 'sum'],name: 'idc_domain_status_bytes'," \
         "tags: {'idc': 'YP'},values: [[1491903624414L, 31483513721L]]}],'statement_id': 0}]"
    resp = json.loads(text)
    from pprint import pprint
    pprint(resp)


if __name__ == '__main__':
    ##parse_grafana_results()
    region_name="CN_GuangXi_CTC"
    print region_name[region_name.index('_')+1:region_name.rindex('_')]
    import re
    BUSINESS_RANGE = '06:30-18:30'
    re_pattern = re.match(r'^(\d*):(\d*)-(\d*):(\d*)$', BUSINESS_RANGE)
    print re_pattern
    if re_pattern:
        print re_pattern.group(1),re_pattern.group(2),re_pattern.group(3),re_pattern.group(4)
    import datetime
    ymdhms ='%Y-%m-%d %H:%M:%S'
    start_time = datetime.datetime.now()
    print start_time.strftime(ymdhms)
