#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/12

import logging


from rest_framework.views import APIView
from rest_framework import status
from rest_framework import exceptions
from rest_framework.response import Response
from lugtm.tools.logger import wraptlogger
from lugtm.tools.base import try_catch
from django.http import Http404
from django.contrib import auth
from rest_framework.authtoken.models import Token

from django.contrib.auth.models import User
from lugtm.management.platform.service.user_service import login_sso,create_user

logger = logging.getLogger("lugtm.views")


class UserLoginService(APIView):
    """API for User Login
    """
    @try_catch
    @wraptlogger
    def post(self,request,*args,**params):
        username = request.data.get("username")
        password = request.data.get("password")
        token, permissions, msg = login_sso(username,password)
        # user = auth.authenticate(username=username, password=password)
        # if user is not None and user.is_active:
        if token:
            if "login.login" in permissions:
                data = dict()
                luser = create_user(username,password)
                ltoken,create = Token.objects.get_or_create(user=luser)
                # token, create = Token.objects.get_or_create(user=user)
                # data['token'] = token.key
                # data['username'] = username
                # data['create'] = create
                data['token'] = ltoken.key
                data['username'] = username
                token_dict = {'X-CSRF-TOKEN': ltoken.key}
                return Response(data, headers=token_dict)
            else:
                return Response("login permissions check failed."+msg,
                            status=status.HTTP_403_FORBIDDEN)
        else:
            return Response("user name or password check failed."+msg,
                            status=status.HTTP_401_UNAUTHORIZED)


class UserRegistService(APIView):
    """API for Regist User
    """
    @try_catch
    @wraptlogger
    def post(self,request,*args,**params):
        username = request.data.get("username",None)
        password = request.data.get("password",None)
        re_password = request.data.get("re_password",None)
        if username and password:
            users = User.objects.filter(username=username)
            if not users:
                user = User.objects.create_user(username=username,password=password,is_active=True)
                if user is not None and user.is_active:
                    return Response("User created ok.",status=status.HTTP_200_OK)
                else:
                    return Response("User created failed.",
                                    status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            else:
                return Response("User created failed.username[%s] already exists." % username,
                                status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            return Response("User or Password must be not empty.",
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)
