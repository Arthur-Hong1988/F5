#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/18

import logging


from rest_framework.views import APIView
from rest_framework import status
from rest_framework import exceptions
from rest_framework.response import Response
from lugtm.tools.logger import wraptlogger
from lugtm.tools.base import try_catch
from lugtm.management.platform.service.base_data import get_all_provinces_percentage\
    ,get_all_operators,get_operator_by_id,get_all_provinces,get_all_provinces_avg_percentage, update_provinces_percent_from_es


# do not use logger,just use print
logger = logging.getLogger("lugtm.views.base")

class UpdatePercentage(APIView):
    """API for province 省份信息
    """
    @try_catch
    @wraptlogger
    def get(self, request, *args, **params):
        return Response(update_provinces_percent_from_es())

class Province(APIView):
    """API for province 省份信息
    """
    @try_catch
    @wraptlogger
    def get(self, request, *args, **params):
        data_type = request.query_params.get("data_type", None)
        if data_type == u"db":
            return Response(get_all_provinces())
        elif data_type == u"avg":
            get_all_provinces_avg_percentage()
            return Response(status.HTTP_200_OK)
        else:
            return Response(get_all_provinces_percentage())

class ProvinceStatus(APIView):
    """API for province 省份信息 for IDC switch info
    """
    #@try_catch
    #@wraptlogger
    def get(self, request, *args, **params):
        ret_dict = {"status":"0", "message":"OK", "app_name":"gtm",
                    "app_status":[{"master_idc":"BX", "detail":[]}, {"master_idc":"WGQ", "detail":[]}]}

        #idc_name_map = {u"宝信": 'BX', u"外高桥":'WGQ'}
        idc_name_map = {u"宝信": 'BX', u"外高桥":'WGQ'}
        raw_province_status_list = get_all_provinces_percentage()


        print 'ProvinceStatus: ************'


        if raw_province_status_list:
            for item in raw_province_status_list:
                if idc_name_map.get(item['to_idc'], '') == 'BX':
                    ret_dict['app_status'][0]['detail'].append({"unique_key":item['province'], "info":item})
                elif idc_name_map.get(item['to_idc'], '') == 'WGQ':
                    ret_dict['app_status'][1]['detail'].append({"unique_key":item['province'], "info":item})
        else:
            ret_dict["status"] = "1"
            ret_dict["message"] = "No info obtained"

        return Response(ret_dict)

class Operator(APIView):
    """API for operator
    """
    @try_catch
    @wraptlogger
    def get(self, request, *args, **params):
        operator_id = params.get("operator_id", None)
        if operator_id:
            return Response(get_operator_by_id(operator_id))
        else:
            return Response(get_all_operators())


class IdcScaleService(APIView):
    """API for idc scale
    """
    @try_catch
    @wraptlogger
    def get(self, request, *args, **params):
        idc_name = request.query_params.get("idc_name", None)
        scale = request.query_params.get("scale", None)
        from lugtm.management.platform.service.base_data import get_idc_scale_data,get_idc_scale_province
        if idc_name and scale:
            return Response(get_idc_scale_province(idc_name,scale))
        else:
            return Response(get_idc_scale_data())
