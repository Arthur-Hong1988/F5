#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/23

from rest_framework.authtoken.models import Token
from rest_framework import permissions
from lugtm.tools.utilfunc import DEFAULT_TOKEN

class CustomApiPermission(permissions.BasePermission):
    """
    Global permission check for api.
    """
    def has_permission(self, request, view):
        # for GTM idc switch
        special_token = request.query_params.dict().get("token", None)
        if special_token == DEFAULT_TOKEN:
            return True
        path = request.build_absolute_uri()
        if "login" in path or "regist" in path:
            return True
        has_permission = False
        token = request.META.get('HTTP_X_CSRF_TOKEN',None)
        if not token:
            token = request.META.get('HTTP_TOKEN',None)
            if not token:
                return has_permission

        token_model = Token.objects.get(key=token)
        cuser = token_model.user
        if cuser:
            has_permission = True
        return has_permission
