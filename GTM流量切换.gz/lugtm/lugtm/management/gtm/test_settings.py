#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by liuchunlin920 on 2016/12/21


BIGIP_ADDRESS = '172.22.6.1'

BIGIP_USER = 'admin'
BIGIP_PASS = 'admin'

BIGIP_PARTITION='Common'

STATE_DISABLED = "STATE_DISABLED"
STATE_ENABLED = "STATE_ENABLED"

TEST_DATACENTER = '/%s/lcl_test_datacenter' % BIGIP_PARTITION

TEST_REGION = 'lcl_test_region'

TEST_CIDRS = ['192.168.1.0/24','192.168.2.100/32']

TEST_POOL = 'lcl_test_pool'



