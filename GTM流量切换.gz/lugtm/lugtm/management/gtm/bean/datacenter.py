#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/9

import base


class DataCenter(base.Base):
    chinese_name = ''

    def __init__(self,name,status,chinese_name=''):
        base.Base.__init__(self,name,status)
        self.chinese_name = chinese_name

