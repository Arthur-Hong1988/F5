#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/9

from .base import Base
from .datacenter import DataCenter
from .region import Region


class Topology:
    weight = 0l
    datacenter = None
    region = None

    def __init__(self,weight,dc_name,dc_status,region_name):
        self.weight = weight
        self.datacenter = DataCenter(dc_name,dc_status)
        self.region = Region(region_name)

    def __str__(self):
        return "Topology(Weight:%s,DataCenter:%s,DataCenterStatus:%s,Region:%s)" \
               % (self.weight,self.datacenter.name,self.datacenter.status,self.region.name)



