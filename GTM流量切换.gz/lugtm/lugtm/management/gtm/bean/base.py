#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/9


class Base:

    name = ''
    #1:状态错误；0:状态正常
    status = 1

    def __init__(self,name,status):
        self.name = name
        self.status = status


