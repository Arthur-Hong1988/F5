#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/9

from .base import Base


class Region(Base):
    def __init__(self,name):
        Base.__init__(self,name,status=0)

