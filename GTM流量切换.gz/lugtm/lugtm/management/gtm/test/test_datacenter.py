# #!/usr/bin/env python
# # -*- coding: utf-8 -*-
# # Created by liuchunlin920 on 2016/12/21
#
#
# import json
# import nose.tools as nt
# from lugtm.management.gtm.test_settings import BIGIP_ADDRESS,TEST_DATACENTER as test_name,\
#     STATE_ENABLED,STATE_DISABLED
# import lugtm.management.gtm.service.datacenter as dc
#
# from lugtm.base_sys.client_factory import sbigip as bigip
#
# class TestDatacenter(object):
#
#     def setup(self):
#         self.bigip = bigip(BIGIP_ADDRESS)
#         pass
#
#     @nt.istest
#     def test_001_get_datacenters(self):
#         datacenters = dc.get_all_datacenters(bigip=self.bigip)
#         return datacenters
#
#     @nt.istest
#     def test_002_create_get_delete_datacenter(self):
#         dc.create_datacenter(test_name,bigip=self.bigip)
#         dc.set_enabled_state(test_name,STATE_DISABLED)
#         dc.get_enabled_state(test_name,bigip=self.bigip)
#         dc.get_datacenter_status(test_name,bigip=self.bigip)
#         dc.set_location_info(test_name,'ChongQing',bigip=self.bigip)
#         dc.get_location_info(test_name,bigip=self.bigip)
#         dc.set_description(test_name,description="lcl_des",bigip=self.bigip)
#         dc.get_description(test_name,bigip=self.bigip)
#         dc.set_contact(test_name,contact="lcl_contact",bigip=self.bigip)
#         dc.get_contact(test_name,bigip=self.bigip)
#         dc.delete_datacenter(test_name,bigip=self.bigip)
#
#
# if __name__ == '__main__':
#     pass
#
