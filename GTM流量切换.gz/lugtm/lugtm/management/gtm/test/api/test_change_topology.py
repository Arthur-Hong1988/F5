#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by liuchunlin920 on 2016/12/21


import json
import nose.tools as nt

from lugtm.tools.base import do_demo_request
from lugtm.management.platform.api.base import Province
from lugtm.management.gtm.api.topology import ChangeService

from lugtm.management.tasks.gtm_data_task import syn_topology_task

user = {'username': u'mgm','password': u'mgm'}

north = 2
sourth = 1


class TestChangeTopology(object):

    def setup(self):
        syn_topology_task()
        pass

    def get_province_topology(self,data={},user={}):
        response = do_demo_request('GET', '/mgm/province/',Province.as_view(),data=data,user=user)
        nt.eq_(response.status_code, 200, response.content)
        res = json.loads(response.content)
        return res

    def get_provinces_db(self,data={'data_type':'db'},user={}):
        response = do_demo_request('GET', '/mgm/province/',Province.as_view(),data=data,user=user)
        nt.eq_(response.status_code, 200, response.content)
        res = json.loads(response.content)
        return res

    def change_des_province_topology(self,data={},user={}):
        response = do_demo_request('POST', '/mgm/province/', ChangeService.as_view(), data=data, user=user)
        nt.eq_(response.status_code, 200, response.content)
        res = json.loads(response.content)
        print res
        return res

    @nt.istest
    def test_001_get_province_db(self):
        result = self.get_provinces_db(user=user)
        # for p in result:
        #     print p[u"name"], p[u"zone_id"]

    @nt.istest
    def test_002_get_province_topology(self):
        result = self.get_province_topology(user=user)
        # for p in result:
        #     print p[u"province"],p[u"to_idc"]

    @nt.istest
    def test_004_change_topology_by_db(self):
        result = self.get_provinces_db(user=user)

        des_zone_id = north

        data = {'source_idc': u'宝信','destination_idc': u'杨浦'}
        if des_zone_id == north:
            data = {'source_idc': u'杨浦','destination_idc': u'宝信'}
        for p in result:
            province = p["name"]
            zone_id = p["zone_id"]
            if zone_id != des_zone_id:
                continue
            data["provinces"] = province
            response = do_demo_request('GET', '/mgm/gtm/changeservice/',ChangeService.as_view(),data=data,user=user)
            nt.eq_(response.status_code, 200, response.content)
            response = do_demo_request('POST', '/mgm/gtm/changeservice/',ChangeService.as_view(),data=data,user=user)
            nt.eq_(response.status_code, 200, response.content)


