# coding=utf-8
import json
from collections import OrderedDict

# from lugtm.management.gtm.service.change_service import get_des_order_dc_v1
YGQ = 'WGQ'
a = {'CN_FuJian_CTC': [{'weight': 34090, 'dc_name': 'SH_BX_CTC', 'order': 904},
                       {'weight': 34085, 'dc_name': 'SH_WGQ_CTC', 'order': 905},
                       {'weight': 34080, 'dc_name': 'SH_BX_CNC', 'order': 906},
                       {'weight': 34075, 'dc_name': 'SH_WGQ_CNC', 'order': 907},
                       {'weight': 34070, 'dc_name': 'SH_BX_BaiDuCloud', 'order': 908},
                       {'weight': 34065, 'dc_name': 'SH_WGQ_BaiDuCloud', 'order': 909},
                       {'weight': 34060, 'dc_name': 'LF_CUCC_CNC', 'order': 910}]}


def get_operator_index(region_dcs):
    result = OrderedDict()
    is_exp = False
    for i in range(len(region_dcs)):
        dc = region_dcs[i]["dc_name"]
        dc_list = dc.split('_')
        # idc_code = dc_list[1]
        city_name = dc_list[0]
        print ('@@@get_operator_index city_name is %s' % (city_name))
        if city_name == 'SH':
            operator_code = dc_list[2]
            if operator_code in result.keys():
                result[operator_code]["end"] = i
            else:
                i_indx = OrderedDict()
                i_indx["start"] = i
                i_indx["end"] = i
                result[operator_code] = i_indx
        else:
            if i == 0:
                print ('@@@MIAO get_operator_index city_name is %s' % (city_name))
                is_exp = True

    if is_exp:
        print ('@@@MIAO result is %s' % (result))

    return result


def get_des_order_dc_v1(result_dcs, source_idc, des_idc):
    """
    根据idc 排定对应result_dcs的最新顺序
    :param result_dcs: 按weight降序的topology [{'dc_name': /Common/SH_YP_CTC, 'weight': 3090L,"order":355}, {'dc_name': /Common/SH_YP_CNC, 'weight': 3085L,"order":356}]
    :param source_idc: idc Model
    :param des_idc: idc Model
    :return:
    """
    import copy
    all_result = copy.deepcopy(result_dcs)
    change_result = [None for i in range(len(result_dcs))]
    update_result = list()

    result_indexs = get_operator_index(result_dcs)

    print('@@@NEW_IDC_CHANGE result_indexs is %s' % (result_indexs))
    for op, in_v in result_indexs.iteritems():
        s = in_v["start"]
        e = in_v["end"]
        if s == e:
            dc = result_dcs[s]["dc_name"]
            change_result[s] = dc
        else:
            e = s + 1
            if des_idc == YGQ:
                dcn = result_dcs[e]["dc_name"]
                dcs = result_dcs[s]["dc_name"]
                if des_idc in dcs:
                    continue
                change_result[s] = dcn
                for i in range(s, e):
                    dcn = result_dcs[i]["dc_name"]
                    change_result[i + 1] = dcn
            elif source_idc == YGQ:
                dcn = result_dcs[s]["dc_name"]
                if des_idc in dcn:
                    continue
                change_result[e] = dcn
                for i in range(s + 1, e + 1):
                    dcn = result_dcs[i]["dc_name"]
                    change_result[i - 1] = dcn
    for j in range(len(all_result)):
        dc1 = all_result[j]["dc_name"]
        dc2 = change_result[j]
        if dc2 is None or dc1 == dc2:
            continue
        all_result[j]["dc_name"] = dc2
        update_result.append(all_result[j])
        #
        #     change_result.append(result_dcs[i])
        # all_result.append(result_dcs[i])
    if update_result:
        print('\n\n\n@@@V1   all_resultis %s, \nupdate_result is %s\n\n\n' % (all_result, update_result))
        return all_result, update_result
    return [], []


def aa():
    all_result, update_result = (get_des_order_dc_v1(a['CN_FuJian_CTC'], 'BX', 'WGQ'))
    print all_result
    print update_result


dsl = {'size': 0,
       'query': {
           'bool': {
               'filter': [
                   {'range': {
                       '@timestamp': {
                           'gte': "2020-10-09T02:06:21", 'lte': "2020-10-09T02:06:26",
                           # 'format': 'epoch_millis'
                       }
                   }},
                   {'query_string': {
                       'analyze_wildcard': True,
                       'query': 'request_uri: * AND (idc: "WGQ" OR idc: "BX")'
                   }}
               ]
           }
       },
       'aggs': {'3': {'terms': {'field': 'geoip.region_name.keyword', 'size': 84,
                                'order': {'1': 'desc'},
                                'min_doc_count': 1},
                      'aggs': {'1': {'sum': {'field': 'body_bytes_sent'}}, '2': {
                          'date_histogram': {'interval': '2m', 'field': '@timestamp', 'min_doc_count': 0,
                                             'extended_bounds': {'min': "2020-10-09T02:06:21",
                                                                 'max': "2020-10-09T02:06:26"}},
                          'aggs': {'1': {'sum': {'field': 'body_bytes_sent'}}}}}
                      }
                }
       }
print(json.dumps(dsl))


def u_p():
    payload3 = {
        'size': 0,
        'query': {
            'bool': {
                'filter': [
                    {'range': {
                        '@timestamp': {'gte': 'cur_time_start_str', 'lte': 'cur_time_end_str',
                                       'format': 'epoch_millis'}}},
                    {
                        'query_string': {'analyze_wildcard': True,
                                         'query': 'url: * AND (isAcc: True) AND ( isLegal: True) AND (idc: "WGQ" OR idc: "BX")'}}
                ]
            }
        },
        'aggs': {
            '3': {
                'terms': {
                    'field': 'province',
                    'size': 84,
                    'order': {'1': 'desc'},
                    'min_doc_count': 1
                },
                'aggs': {
                    '1': {'sum': {'field': 'bodyBytesSent'}},
                    '2': {
                        'date_histogram': {'interval': '2m', 'field': '@timestamp', 'min_doc_count': 0,
                                           'extended_bounds': {'min': 'cur_time_start_str',
                                                               'max': 'cur_time_end_str'},
                                           'format': 'epoch_millis'},
                        'aggs': {'1': {'sum': {'field': 'bodyBytesSent'}}}
                    }
                }
            }
        }
    }
    payload4 = {
        'size': 0,
        'query': {
            'bool': {
                'filter': [
                    {'range': {
                        '@timestamp': {'gte': 'cur_time_start_str', 'lte': 'cur_time_end_str',
                                       'format': 'epoch_millis'}}},
                    {
                        'query_string': {'analyze_wildcard': True,
                                         'query': 'url: * AND (isAcc: True) AND ( isLegal: True) AND (idc: "WGQ" OR idc: "BX")'}}
                ]
            }
        }
    }

    # print(json.dumps(payload4))


if __name__ == '__main__':
    u_p()
