# #!/usr/bin/env python
# # -*- coding: utf-8 -*-
# # Created by liuchunlin920 on 2016/12/21
#
#
# import json
# import nose.tools as nt
# from lugtm.management.gtm.api.datacenter import DataCenter
#
# from lugtm.tools.base import do_demo_request
#
# datacenter_view = DataCenter.as_view()
#
#
# class TestDataCenter(object):
#
#     def setup(self):
#         pass
#
#     @nt.istest
#     def test_001_get_datacenter(self):
#         response = do_demo_request('GET', '/gtm/datacenter/',datacenter_view)
#         nt.eq_(response.status_code, 200, response.content)
#         res = json.loads(response.content)
#         # for dc in res:
#         #     print dc["chinese_name"],dc["name"],dc["status"]
#
