# #!/usr/bin/env python
# # -*- coding: utf-8 -*-
# # Created by liuchunlin920 on 2016/12/21
#
#
# import json
# import nose.tools as nt
#
# from lugtm.management.gtm.api.topology import TopologyStatus
#
# from lugtm.tools.base import do_demo_request
#
# topology_status_view = TopologyStatus.as_view()
#
#
# class TestTopology(object):
#
#     def setup(self):
#         pass
#
#     def get_operator_province_topology(self,data={}):
#         response = do_demo_request('GET', '/gtm/topology/',topology_status_view,data=data)
#         nt.eq_(response.status_code, 200, response.content)
#         res = json.loads(response.content)
#         print res
#
#     @nt.istest
#     def test_001_get_province_topology(self):
#         data = {'operator': u'CMCC','province': u'上海'}
#         self.get_operator_province_topology(data=data)
#
#     @nt.istest
#     def test_002_get_province_topology(self):
#         data = {'operator': u'CMCC'}
#         self.get_operator_province_topology(data=data)
#
#
