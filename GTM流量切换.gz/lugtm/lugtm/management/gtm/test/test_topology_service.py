# # encoding: utf-8
# '''
# Created on 2016年12月16日
#
# @author: xiangfei159
# '''
# import lugtm.management.gtm.service.topology as TP
# from lugtm.base_sys.client_factory import sbigip as bigip
# from .test_properties import hostname,new_datacenter_name,new_region_name
# import lugtm.management.gtm.service.region as region
# import lugtm.management.gtm.service.datacenter as dc
#
# # import bigsuds
#
# regiontype = TP.get_topology_regiontype(bigip(hostname))
#
#
# class TestTopologyService(object):
#
#     def setup(self):
#
#         self.bigip = bigip(hostname)
#
#     def test_001_get_all_topology(self):
#         return TP.get_all_topology(self.bigip)
#
#     def test_100_create_update_delete_topology(self):
#         ##create region
#         test_cidrs = ['172.16.20.0/24']
#         region.create_cidrs_region(new_region_name,test_cidrs, bigip=self.bigip)
#         ##create datacenter
#         dc.create_datacenter(new_datacenter_name, bigip=self.bigip)
#         ##create topology
#         testtopologyrecord = TP.topologyrecord(new_region_name, regiontype.REGION_TYPE_REGION, new_datacenter_name,regiontype.REGION_TYPE_DATA_CENTER, bigip=self.bigip)
#         TP.create_topology(testtopologyrecord, 5555, 2, self.bigip)
#         TP.set_topology_order_by_topologyrecord(testtopologyrecord, 555, self.bigip)
#         TP.set_topology_weight_by_topologyrecord(testtopologyrecord, 0, self.bigip)
#         TP.get_topology_weight_by_record(testtopologyrecord, self.bigip)
#         TP.get_topology_order_by_record(testtopologyrecord, self.bigip)
#
#         ##delete topology
#         TP.delete_topology_record(testtopologyrecord, self.bigip)
#         ##delete region
#         region.delete_region_and_items(new_region_name, bigip=self.bigip)
#         ##delete datacenter
#         dc.delete_datacenter(new_datacenter_name, bigip=self.bigip)
#
#     def teardown(self):
#         pass