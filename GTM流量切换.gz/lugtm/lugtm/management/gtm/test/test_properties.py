# # encoding: utf-8
# '''
# Created on 2016年12月16日
#
# @author: xiangfei159
# '''
#
# hostname = "172.22.6.1"
#
# exist_wide_ip = "web.f5.test.com"
#
# create_wide_ip = "www.testlugtm.com"
#
# exist_wide_ip_pool = "Pool_123456"
#
# exist_wide_ip_rule = "testvv"
#
# last_restore_pool_name = "web2"
#
#
# create_wide_ip_rule = "test_rule"
#
# create_wide_ip_rule_content = '''
#
# when RULE_INIT {
#
#    # Set a global max for number of concurrent TCP connections
#    set ::max_connections 2
#
#    # Set an HTML response to sent to clients who make a request while the VIP is over the max connection count
#    set ::html_content "<html>over limit</html>"
#
#    # Print debug messages to /var/log/ltm?  1=yes, 0=no
#    set ::debug 1
#
#    # Initialize a counter for active connections (don't modify this)
#    set ::active_connections 0
# }
#
# '''
#
# new_datacenter_name = "tp_test_datacenter"
#
# new_region_name = "tp_test_region"
#
