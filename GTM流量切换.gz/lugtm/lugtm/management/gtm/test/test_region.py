# #!/usr/bin/env python
# # -*- coding: utf-8 -*-
# # Created by LIUCHUNLIN920 on 2016/12/6
#
# import nose.tools as nt
# import lugtm.management.gtm.service.region as region
# from lugtm.base_sys.client_factory import sbigip as bigip
# from lugtm.management.gtm.test_settings import TEST_REGION,TEST_CIDRS,  BIGIP_ADDRESS
#
#
# class TestRegions(object):
#
#     def setup(self):
#         self.bigip = bigip(BIGIP_ADDRESS)
#
#     @nt.istest
#     def test_001_get_regions(self):
#         region.get_all_regions()
#
#     @nt.istest
#     def test_002_create_get_update_delete_regions(self):
#         update_cidrs = ['172.16.20.0/24']
#         region.create_cidrs_region(TEST_REGION,TEST_CIDRS, bigip=self.bigip)
#         region.get_region_items_by_name(TEST_REGION, bigip=self.bigip)
#         region.update_cidrs_region(TEST_REGION, update_cidrs)
#         region.get_region_items_by_name(TEST_REGION, bigip=self.bigip)
#         region.update_cidrs_region(TEST_REGION,update_cidrs, is_add=False)
#         region.get_region_items_by_name(TEST_REGION, bigip=self.bigip)
#         region.set_region_description(TEST_REGION,'lcl_description',bigip=self.bigip)
#         region.get_region_description(TEST_REGION, bigip=self.bigip)
#         region.delete_region_all_items(TEST_REGION, bigip=self.bigip)
#         region.get_region_items_by_name(TEST_REGION, bigip=self.bigip)
#         region.delete_region_and_items(TEST_REGION, bigip=self.bigip)
#
#
