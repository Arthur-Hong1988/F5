# #!/usr/bin/env python
# # -*- coding: utf-8 -*-
# # Created by LIUCHUNLIN920 on 2016/12/6
#
# import nose.tools as nt
#
# import lugtm.management.gtm.service.pool as pool
# import lugtm.management.gtm.service.virtualserver as VS
# import lugtm.management.gtm.service.server as SS
# import lugtm.management.gtm.service.datacenter as dc
# from lugtm.management.gtm.test_settings import BIGIP_ADDRESS ,TEST_POOL,TEST_DATACENTER as test_dc_name
# from lugtm.base_sys.client_factory import sbigip as bigip
#
#
# new_server_name = "test_f5_new_server"
#
# monitor_templates_list = ['/Common/bigip' , '/Common/tcp']
# ip_list = ["172.16.22.33" , "172.16.33.22"]
# add_ip_list = ["172.16.44.3","172.16.33.66"]
#
# pool_lb_methods = ["LB_METHOD_TOPOLOGY"]
#
#
# virtual_servername_0 = "vt_test_0"
# virtual_servername_1 = "vt_test_1"
#
# ip_0 = "5.5.5.5"
# ip_1 = "5.5.5.6"
# port = 22
#
# servertype = SS.get_server_type(bigip=bigip(BIGIP_ADDRESS))
#
#
# class TestPools(object):
#
#     def setup(self):
#         self.bigip = bigip(BIGIP_ADDRESS)
#
#     @nt.istest
#     def test_000_get_pools(self):
#         pool.get_all_pools(bigip=self.bigip)
#
#     @nt.istest
#     def test_001_create_update_delete_pools(self):
#         ##创建pool
#         pool.create_pool(TEST_POOL, lb_methods=pool_lb_methods, bigip=self.bigip)
#
#         ##创建datacenter
#         dc.create_datacenter(test_dc_name, bigip=self.bigip)
#         ##创建server
#         SS.create_v2(new_server_name, ip_list, servertype.SERVER_TYPE_BIGIP_STANDALONE, test_dc_name, bigip=self.bigip)
#         ##创建vs
#         VS.create(virtual_servername_0, new_server_name, ip_0, port, bigip=self.bigip)
#         VS.create(virtual_servername_1, new_server_name, ip_1, port, bigip=self.bigip)
#         ##vs添加进pool
#         pool.add_pool_member(TEST_POOL,virtual_servername_0,new_server_name,order=1,bigip=self.bigip)
#         pool.add_pool_member(TEST_POOL,virtual_servername_1,new_server_name,order=0,bigip=self.bigip)
#         ##获取pool members
#         pool.get_pool_members(TEST_POOL,bigip = self.bigip)
#         ##删除pool members
#         pool.delete_pool_all_members(TEST_POOL,bigip= self.bigip)
#         pool.get_pool_members(TEST_POOL,bigip = self.bigip)
#         ##删除vs
#         VS.delete_virtual_server(virtual_servername_0,new_server_name,bigip=self.bigip)
#         VS.delete_virtual_server(virtual_servername_1,new_server_name,bigip=self.bigip)
#         ##删除server
#         SS.delete_server(new_server_name, bigip=self.bigip)
#         ##删除datacenter
#         dc.delete_datacenter(test_dc_name, bigip=self.bigip)
#         ##删除pool
#         pool.delete_pool(TEST_POOL,bigip=self.bigip)
#
#
