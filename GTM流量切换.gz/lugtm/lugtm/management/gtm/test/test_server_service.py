# # encoding: utf-8
# '''
# Created on 2016年12月16日
#
# @author: xiangfei159
# '''
# import lugtm.management.gtm.service.server as SS
#
# # from  lugtm.base_sys.client_factory import Transaction
#
# from .test_properties import hostname
# from lugtm.base_sys.client_factory import sbigip as bigip
# import lugtm.management.gtm.service.datacenter as dc
# servertype = SS.get_server_type(bigip(hostname))
# commonstatetype = SS.get_common_state_type(bigip(hostname))
# monitortype = SS.get_monitor_type(bigip(hostname))
#
#
# new_server_name = "test_f5_new_server"
#
#
# new_server_name_list = [new_server_name]
#
# dc_temp_name="server_test_dc"
# set_dc_temp_name="set_server_test_dc"
# monitor_templates_list = ['/Common/bigip' , '/Common/tcp']
# ip_list = ["172.16.22.33" , "172.16.33.22"]
# add_ip_list = ["172.16.44.3","172.16.33.66"]
# serveripsequencesequence = SS.serveripsequencesequence(add_ip_list, bigip(hostname))
#
# class TestServerService(object):
#
#     def setup(self):
#
#         self.bigip = bigip(hostname)
#
#
#     def test_001_get_all_server(self):
#
#         return SS.get_all_server(self.bigip)
#
#
# #     def test_002_server_operation(self):
# #
# #         with Transaction(hostname):
# #             self.create_server()
# #             self.add_ip_v2()
# #
# #
# #             self.remove_ip_v2()
# #             self.delete_server()
#
#     def test_002_create_server(self):
#
#         return self.create_server()
#
#     def test_003_get_ip_v2(self):
#
#         return SS.get_ip_v2(new_server_name_list,self.bigip)
#
#     def test_004_get_limit(self):
#
#         return SS.get_limit(new_server_name_list,self.bigip)
#
#     def test_005_get_object_status(self):
#
#         return SS.get_object_status(new_server_name_list,self.bigip)
#
#     def test_006_get_prober_pool(self):
#
#         return SS.get_prober_pool(new_server_name_list,self.bigip)
#
#     def test_007_get_statistics(self):
#
#         return SS.get_statistics(new_server_name_list,self.bigip)
#
#     def test_008_get_prober_address(self):
#
#         return SS.get_prober_address(new_server_name_list,self.bigip)
#
#     def test_009_get_data_center(self):
#
#         return SS.get_data_center(new_server_name_list,self.bigip)
#
#     def test_010_get_description(self):
#
#         return SS.get_description(new_server_name_list, self.bigip)
#
#
#     def test_011_get_enabled_state(self):
#
#         return SS.get_enabled_state(new_server_name_list, self.bigip)
#
#     def test_012_set_description(self):
#
#         return SS.set_description(new_server_name, "new server description", self.bigip)
#
#     def test_013_set_enabled_state(self):
#
#         return SS.set_enabled_state(new_server_name, commonstatetype.STATE_DISABLED, self.bigip)
#
# #     def test_014_set_prober_address(self):
# #
# #         return SS.set_prober_address(new_server_name,{"name":"2.2.2.2"} , hostname)
#
#     def test_015_set_datacenter(self):
#         dc.create_datacenter(set_dc_temp_name,bigip=self.bigip)
#         return SS.set_data_center(new_server_name,set_dc_temp_name, self.bigip)
#
#     def test_016_get_monitor_association(self):
#         return SS.get_monitor_association(new_server_name , self.bigip)
#
#     def test_017_add_ip_v2(self):
#
#         return self.add_ip_v2()
#
#     def test_018_remove_ip_v2(self):
#
#         return self.remove_ip_v2()
#
#     def test_019_set_monitor_association(self):
#
#         return SS.set_monitor_association(new_server_name, monitortype.MONITOR_RULE_TYPE_AND_LIST, monitor_templates_list, 0, self.bigip)
#
#     def test_099_delete_server(self):
#         self.delete_server()
#         dc.delete_datacenter(dc_temp_name,bigip=self.bigip)
#         dc.delete_datacenter(set_dc_temp_name,bigip=self.bigip)
#
#     def create_server(self):
#         dc.create_datacenter(dc_temp_name,bigip=self.bigip)
#         return SS.create_v2(new_server_name, ip_list, servertype.SERVER_TYPE_BIGIP_STANDALONE , dc_temp_name, self.bigip)
#
#     def add_ip_v2(self):
#         return SS.add_ip_v2(new_server_name, serveripsequencesequence, self.bigip)
#
#     def remove_ip_v2(self):
#         return SS.remove_ip_v2(new_server_name, serveripsequencesequence, self.bigip)
#
#     def delete_server(self):
#         return SS.delete_server(new_server_name, self.bigip)