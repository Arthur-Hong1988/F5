# # -*- coding: utf-8 -*-
# '''
# Created on 2016年12月16日
#
# @author: xiangfei159
# '''
#
# import lugtm.management.gtm.service.virtualserver as VS
#
# from .test_properties import hostname
#
# from lugtm.base_sys.client_factory import sbigip as bigip
#
# virtual_servername = "vt_test"
# virtual_servername_list = [ virtual_servername ]
# masterservername = "test"
#
# ip = "5.5.5.5"
# port = 22
# st  =  VS.get_common_state_type(bigip(hostname))
#
# monitorruletype =  VS.get_monitorrule_type(bigip(hostname))
#
# monitor_templates_list = ['/Common/bigip' , '/Common/tcp']
# class VirtualServerService(object):
#
#     def setup(self):
#         
#         self.bigip = bigip(hostname)
#
#     def test_001_get_all_virtualserver(self):
#
#         return VS.get_all_virtualserver(self.bigip)
#
#
#     def test_002_create_virtualserver(self):
#
#         return VS.create(virtual_servername, masterservername, ip, port, self.bigip)
#
#
#     def test_003_set_translation(self):
#
#         return VS.set_translation([{"name":virtual_servername,"server":masterservername}], [{"address":  "1.1.1.1","port" : 22} ], self.bigip)
#
#     def test_004_get_translation(self):
#
#         return VS.get_translation([{"name":virtual_servername,"server":masterservername}] , self.bigip )
#
#
#     def test_005_set_monitor_rule(self):
#
#         return VS.set_monitor_rule(virtual_servername, masterservername,monitorruletype.MONITOR_RULE_TYPE_AND_LIST, monitor_templates_list, 0, self.bigip)
#
#     def test_006_get_monitor_rule(self):
#
#
#         return VS.get_monitor_rule(virtual_servername, masterservername, self.bigip)
#
#     def test_007_set_enabled_state(self):
#
#         return VS.set_enabled_state(virtual_servername, masterservername, st.STATE_DISABLED, self.bigip)
#
#     def test_008_get_enabled_state(self):
#
#         return VS.get_enabled_state(virtual_servername_list, self.bigip)
#
#     def test_099_delete_virtual_server(self):
#
#         return VS.delete_virtual_server(virtual_servername, masterservername, self.bigip)
#     def teardown(self):
#         pass
