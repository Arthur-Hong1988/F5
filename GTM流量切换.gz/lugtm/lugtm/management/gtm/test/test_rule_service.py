# # encoding: utf-8
# '''
# Created on 2016年12月16日
#
# @author: xiangfei159
# '''
#
# import lugtm.management.gtm.service.rule as RL
#
# from lugtm.base_sys.client_factory import sbigip as bigip
# from .test_properties import  hostname , create_wide_ip_rule , create_wide_ip_rule_content
#
#
# class TestRuleService(object):
#
#     def setup(self):
#
#         self.bigip = bigip(hostname)
#
#
#     def test_001_get_all_rule(self):
#         return RL.get_all_rule(self.bigip)
#
#     def test_002_create_rule(self):
#         return RL.create_rule(create_wide_ip_rule, create_wide_ip_rule_content, self.bigip)
#
#     def test_003_delete_rule(self):
#         return RL.delete_rule(create_wide_ip_rule, self.bigip)
#
#     def teardown(self):
#         pass
