# # encoding: utf-8
# '''
# Created on 2016年12月16日
#
# @author: xiangfei159
# '''
#
# import lugtm.management.gtm.service.wideip as WP
#
# # from  lugtm.base_sys.client_factory import Transaction
#
# from .test_properties import hostname , exist_wide_ip  as wide_ip ,create_wide_ip ,exist_wide_ip_pool ,exist_wide_ip_rule ,last_restore_pool_name
#
# from lugtm.base_sys.client_factory import sbigip as bigip
#
# import lugtm.management.gtm.service.pool as pool
#
# pool_lb_methods = ["LB_METHOD_TOPOLOGY"]
# test_pool = "wp_test_pool"
#
#
# lbtype  = WP.get_lb_method_type(bigip(hostname))
# wideiptype = WP.get_enabled_state_type(bigip(hostname))
#
# class TestWideIpService(object):
#
#     def setup(self):
#         self.bigip = bigip(hostname)
# #         self.hostname = hostname
# #         self.bigip = bigsuds.BIGIP(hostname=self.hostname)
#
#
#
#     def test_001_get_wideiplist(self):
#
#         return WP.get_all_wideip(self.bigip)
#
#     def test_002_get_wideip_pool(self):
#
#         return WP.get_wideip_pool(wide_ip, self.bigip)
#
#     def test_003_get_wideip_rule(self):
#
#         return WP.get_wideip_rule(wide_ip , self.bigip)
#
#     def test_004_get_pool_list_by_wideipname_list(self):
#
#         return WP.get_pool_list_by_wideipname_list([wide_ip] , self.bigip)
#
#     def test_005_get_lb_method_type(self):
#
#         return WP.get_lb_method_type(self.bigip)
#     def test_006_get_lb_method(self):
#
#         return WP.get_lb_method(wide_ip, self.bigip)
#
#     def test_007_get_description(self):
#
#         return WP.get_description(wide_ip,self.bigip)
#
#     def test_008_get_enabled_state(self):
#
#         return WP.get_enabled_state(wide_ip,self.bigip)
#
#     def test_009_get_persistence_ttl(self):
#
#         return WP.get_persistence_ttl(wide_ip, self.bigip)
#
#     def test_010_get_enabled_state_type(self):
#
#         return WP.get_enabled_state_type(self.bigip)
#
#     def test_011_get_persistence_state(self):
#
#         return WP.get_persistence_state(wide_ip,self.bigip)
#
#     def test_012_get_last_resort_pool(self):
#         return WP.get_last_resort_pool(wide_ip,self.bigip)
#
#
#
# #     def test_013_wideip_operation(self):
# #         with Transaction(hostname):
# #             self.create_wideip()
# #             self.add_wideip_pool()
# #             self.add_wideip_rule()
# #             self.remove_wideip_pool()
# #             self.remove_wideip_rule()
# #             self.set_lb_method()
# #             self.set_description()
# #             self.set_enabled_state()
# #             self.set_persistence_state()
# #             self.set_persistence_ttl()
# #             self.set_last_resort_pool()
# # #
# #             self.delete_wideip()
#
#
#
#     def test_013_create_wideip(self):
#
#         return self.create_wideip()
#
#     def test_014_add_wideip_pool(self):
#
#         return self.add_wideip_pool()
#
#     def test_015_add_wideip_rule(self):
#
#         return self.add_wideip_rule()
#
#     def test_018_set_lb_method(self):
#
#         return self.set_lb_method()
#
#     def test_019_set_description(self):
#
#         return self.set_description()
#
#
#     def test_020_set_enabled_state(self):
#
#         return self.set_enabled_state()
#
#     def test_021_set_persistence_state(self):
#         return self.set_persistence_state()
#
#     def test_022_set_persistence_ttl(self):
#         return self.set_persistence_ttl()
#
#     def test_023_set_last_resort_pool(self):
#
#         return self.set_last_resort_pool()
#
#     def test_016_remove_wideip_pool(self):
#         return self.remove_wideip_pool()
#
#     def test_080_remove_wideip_rule(self):
#
#         return self.remove_wideip_rule()
#
#     def test_099_delete(self):
#         self.delete_wideip()
#         ##删除pool
#         pool.delete_pool(test_pool,bigip=self.bigip)
#
#
#     def create_wideip(self):
#         return WP.create_wideip(create_wide_ip, self.bigip)
#
#     def add_wideip_pool(self):
#
#         ##创建pool
#         pool.create_pool(test_pool, lb_methods=pool_lb_methods, bigip=self.bigip)
#         return WP.add_wideip_pool(create_wide_ip,test_pool, 0, 3, self.bigip)
#
#     def add_wideip_rule(self):
#
#         return WP.add_wideip_rule(create_wide_ip, exist_wide_ip_rule, 0, self.bigip)
#
#     def remove_wideip_pool(self):
#         return WP.remove_wideip_pool(create_wide_ip,test_pool,self.bigip )
#
#     def remove_wideip_rule(self):
#         return WP.remove_wideip_rule(create_wide_ip, exist_wide_ip_rule, self.bigip)
#
#
#     def set_lb_method(self):
#
#         return WP.set_lb_method(create_wide_ip, lbtype.LB_METHOD_TOPOLOGY, self.bigip)
#
#
#     def set_description(self):
#
#         return WP.set_description(create_wide_ip , "description" , self.bigip)
#
#     def set_enabled_state(self):
#
#         return WP.set_enabled_state(create_wide_ip, wideiptype.STATE_DISABLED, self.bigip)
#
#     def set_persistence_state(self):
#
#         return WP.set_enabled_state(create_wide_ip, wideiptype.STATE_DISABLED, self.bigip)
#
#     def set_persistence_ttl(self):
#
#         return WP.set_persistence_ttl(create_wide_ip, 3600, self.bigip)
#
#
#     def set_last_resort_pool(self):
#
#         return WP.set_last_resort_pool(create_wide_ip, test_pool, self.bigip)
#
#     def delete_wideip(self):
#
#         return WP.delete_wideip(create_wide_ip, self.bigip)
# #     @nt.istest
# #     def test_002_get_pools(self):
# #         response = do_demo_request('GET', '/mgm/gtm/pool/',pools_view)
# #         nt.eq_(response.status_code, 200, response.content)
# #         res = json.loads(response.content)
# #         print res
#
#     def teardown(self):
#         pass
