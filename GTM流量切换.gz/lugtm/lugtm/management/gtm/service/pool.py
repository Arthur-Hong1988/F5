#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/5
'''
 Methods (99):
            add_member(Common.StringSequence pool_names, GlobalLB.Pool.PoolMemberDefinitionSequenceSequence members, )
            add_member_dependency(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, GlobalLB.VirtualServerIDSequenceSequenceSequence dependencies, )
            add_member_v2(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, Common.ULongSequenceSequence orders, )
            add_metadata(Common.StringSequence pool_names, Common.StringSequenceSequence names, Common.StringSequenceSequence values, )
            create(Common.StringSequence pool_names, GlobalLB.LBMethodSequence lb_methods, GlobalLB.Pool.PoolMemberDefinitionSequenceSequence members, )
            create_v2(Common.StringSequence pool_names, GlobalLB.LBMethodSequence lb_methods, GlobalLB.VirtualServerIDSequenceSequence members, Common.ULongSequenceSequence orders, )
            delete_all_pools()
            delete_pool(Common.StringSequence pool_names, )
            get_all_statistics()
            get_alternate_lb_method(Common.StringSequence pool_names, )
            get_answers_to_return(Common.StringSequence pool_names, )
            get_cname(Common.StringSequence pool_names, )
            get_description(Common.StringSequence pool_names, )
            get_dynamic_ratio_state(Common.StringSequence pool_names, )
            get_enabled_state(Common.StringSequence pool_names, )
            get_fallback_ip(Common.StringSequence pool_names, )
            get_fallback_ipv4(Common.StringSequence pool_names, )
            get_fallback_ipv6(Common.StringSequence pool_names, )
            get_fallback_lb_method(Common.StringSequence pool_names, )
            get_limit(Common.StringSequence pool_names, )
            get_list()
            get_manual_resume_state(Common.StringSequence pool_names, )
            get_member(Common.StringSequence pool_names, )
            get_member_dependency(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            get_member_description(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            get_member_enabled_state(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            get_member_limit(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            get_member_monitor_rule(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            get_member_object_status(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            get_member_order(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            get_member_ratio(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            get_member_statistics(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            get_member_v2(Common.StringSequence pool_names, )
            get_metadata(Common.StringSequence pool_names, )
            get_metadata_description(Common.StringSequence pool_names, Common.StringSequenceSequence names, )
            get_metadata_persistence(Common.StringSequence pool_names, Common.StringSequenceSequence names, )
            get_metadata_value(Common.StringSequence pool_names, Common.StringSequenceSequence names, )
            get_monitor_association(Common.StringSequence pool_names, ) Pool_SH_JQ_CTC_First
            get_object_status(Common.StringSequence pool_names, )
            get_preferred_lb_method(Common.StringSequence pool_names, )
            get_qos_coefficient_bps(Common.StringSequence pool_names, )
            get_qos_coefficient_connection_rate(Common.StringSequence pool_names, )
            get_qos_coefficient_hit_ratio(Common.StringSequence pool_names, )
            get_qos_coefficient_hops(Common.StringSequence pool_names, )
            get_qos_coefficient_lcs(Common.StringSequence pool_names, )
            get_qos_coefficient_packet_rate(Common.StringSequence pool_names, )
            get_qos_coefficient_rtt(Common.StringSequence pool_names, )
            get_qos_coefficient_topology(Common.StringSequence pool_names, )
            get_qos_coefficient_vs_capacity(Common.StringSequence pool_names, )
            get_qos_coefficient_vs_score(Common.StringSequence pool_names, )
            get_statistics(Common.StringSequence pool_names, )
            get_ttl(Common.StringSequence pool_names, )
            get_verify_member_availability_state(Common.StringSequence pool_names, )
            get_version()
            remove_all_member_dependencies(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            remove_all_members(Common.StringSequence pool_names, )
            remove_all_metadata(Common.StringSequence pool_names, )
            remove_member(Common.StringSequence pool_names, Common.IPPortDefinitionSequenceSequence members, )
            remove_member_dependency(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, GlobalLB.VirtualServerIDSequenceSequenceSequence dependencies, )
            remove_member_v2(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            remove_metadata(Common.StringSequence pool_names, Common.StringSequenceSequence names, )
            remove_monitor_association(Common.StringSequence pool_names, )
            reset_member_statistics(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, )
            reset_statistics(Common.StringSequence pool_names, )
            set_alternate_lb_method(Common.StringSequence pool_names, GlobalLB.LBMethodSequence lb_methods, )
            set_answers_to_return(Common.StringSequence pool_names, Common.ULongSequence answers, )
            set_cname(Common.StringSequence pool_names, Common.StringSequence cnames, )
            set_description(Common.StringSequence pool_names, Common.StringSequence descriptions, )
            set_dynamic_ratio_state(Common.StringSequence pool_names, Common.EnabledStateSequence states, )
            set_enabled_state(Common.StringSequence pool_names, Common.EnabledStateSequence states, )
            set_fallback_ip(Common.StringSequence pool_names, Common.IPAddressSequence ips, )
            set_fallback_ipv4(Common.StringSequence pool_names, Common.IPAddressSequence ips, )
            set_fallback_ipv6(Common.StringSequence pool_names, Common.IPAddressSequence ips, )
            set_fallback_lb_method(Common.StringSequence pool_names, GlobalLB.LBMethodSequence lb_methods, )
            set_limit(GlobalLB.Pool.PoolMetricLimitSequence limits, )
            set_manual_resume_state(Common.StringSequence pool_names, Common.EnabledStateSequence states, )
            set_member_description(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, Common.StringSequenceSequence descriptions, )
            set_member_enabled_state(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, Common.EnabledStateSequenceSequence states, )
            set_member_limit(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, GlobalLB.MetricLimitSequenceSequenceSequence limits, )
            set_member_monitor_rule(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, GlobalLB.MonitorRuleSequenceSequence rules, )
            set_member_order(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, Common.ULongSequenceSequence orders, )
            set_member_ratio(Common.StringSequence pool_names, GlobalLB.VirtualServerIDSequenceSequence members, Common.ULongSequenceSequence ratios, )
            set_metadata_description(Common.StringSequence pool_names, Common.StringSequenceSequence names, Common.StringSequenceSequence descriptions, )
            set_metadata_persistence(Common.StringSequence pool_names, Common.StringSequenceSequence names, Common.MetadataPersistenceSequenceSequence values, )
            set_metadata_value(Common.StringSequence pool_names, Common.StringSequenceSequence names, Common.StringSequenceSequence values, )
            set_monitor_association(GlobalLB.Pool.MonitorAssociationSequence monitor_associations, )
            set_preferred_lb_method(Common.StringSequence pool_names, GlobalLB.LBMethodSequence lb_methods, )
            set_qos_coefficient_bps(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_qos_coefficient_connection_rate(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_qos_coefficient_hit_ratio(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_qos_coefficient_hops(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_qos_coefficient_lcs(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_qos_coefficient_packet_rate(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_qos_coefficient_rtt(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_qos_coefficient_topology(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_qos_coefficient_vs_capacity(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_qos_coefficient_vs_score(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_ttl(Common.StringSequence pool_names, Common.ULongSequence values, )
            set_verify_member_availability_state(Common.StringSequence pool_names, Common.EnabledStateSequence states, )
'''

import lugtm.base_sys.client_factory as clientFactory
from lugtm.tools.logger import servicelogger
from lugtm.settings import BIGIP_ADDRESS


@servicelogger
def get_all_pools(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    pool_list = client.service.get_list()
    return pool_list

@servicelogger
def get_pool_status(pool_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    return client.service.get_object_status(pool_names=[pool_name])

@servicelogger
def get_enabled_state(pool_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    return client.service.get_enabled_state(pool_names=[pool_name])

@servicelogger
def set_enabled_state(pool_name,enable_state,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param pool_name:
    :param enable_state:
    (Common.EnabledState){
   STATE_DISABLED = "STATE_DISABLED"
   STATE_ENABLED = "STATE_ENABLED"
    }
    :param hostname:
    :return:
    '''
    client = clientFactory.get_poolclient(bigip = bigip)

    # enable_state = client.factory.create('Common.EnabledState')
    # print enable_state

    enable_state_seq = client.factory.create('Common.EnabledStateSequence')
    enable_state_seq.states = [enable_state]

    return client.service.set_enabled_state(pool_names=[pool_name],states = enable_state_seq)


@servicelogger
def get_member_enabled_state(pool_name,vs_name,server_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    vs_seq_seq = client.factory.create("GlobalLB.VirtualServerIDSequenceSequence")
    vs_seq = client.factory.create("GlobalLB.VirtualServerIDSequence")
    vs = client.factory.create("GlobalLB.VirtualServerID")
    vs.name=vs_name
    vs.server=server_name
    vs_seq.members=[vs]
    vs_seq_seq.members=[vs_seq]
    return client.service.get_member_enabled_state(pool_names=[pool_name],members=vs_seq_seq)


@servicelogger
def set_member_enabled_state(pool_name,vs_name,server_name,enable_state,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''

    :param pool_name:
    :param vs_name:
    :param server_name:
    :param enable_state:
       (Common.EnabledState){
   STATE_DISABLED = "STATE_DISABLED"
   STATE_ENABLED = "STATE_ENABLED"
    }
    :param hostname:
    :return:
    '''
    client = clientFactory.get_poolclient(bigip = bigip)
    vs_seq_seq = client.factory.create("GlobalLB.VirtualServerIDSequenceSequence")
    vs_seq = client.factory.create("GlobalLB.VirtualServerIDSequence")
    vs = client.factory.create("GlobalLB.VirtualServerID")
    vs.name=vs_name
    vs.server=server_name
    vs_seq.members=[vs]
    vs_seq_seq.members=[vs_seq]

    enable_state_seq = client.factory.create('Common.EnabledStateSequence')
    enable_state_seq.states = [enable_state]

    enable_state_seq_seq = client.factory.create('Common.EnabledStateSequenceSequence')
    enable_state_seq_seq.states = [enable_state_seq]

    return client.service.set_member_enabled_state(pool_names=[pool_name],members=vs_seq_seq,states=enable_state_seq_seq)

@servicelogger
def get_member_ratio(pool_name,vs_name,server_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    vs_seq_seq = client.factory.create("GlobalLB.VirtualServerIDSequenceSequence")
    vs_seq = client.factory.create("GlobalLB.VirtualServerIDSequence")
    vs = client.factory.create("GlobalLB.VirtualServerID")
    vs.name=vs_name
    vs.server=server_name
    vs_seq.members=[vs]
    vs_seq_seq.members=[vs_seq]
    return client.service.get_member_ratio(pool_names=[pool_name],members=vs_seq_seq)

@servicelogger
def set_member_ratio(pool_name,vs_name,server_name,ratio=1,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param pool_name:
    :param vs_name:
    :param server_name:
    :param ratio:
    :param hostname:
    :return:
    '''
    client = clientFactory.get_poolclient(bigip = bigip)
    vs_seq_seq = client.factory.create("GlobalLB.VirtualServerIDSequenceSequence")
    vs_seq = client.factory.create("GlobalLB.VirtualServerIDSequence")
    vs = client.factory.create("GlobalLB.VirtualServerID")
    vs.name=vs_name
    vs.server=server_name
    vs_seq.members=[vs]
    vs_seq_seq.members=[vs_seq]

    ration_seq_seq = client.factory.create("Common.ULongSequenceSequence")
    ration_seq_seq.orders=[ratio]

    return client.service.set_member_ratio(pool_names=[pool_name],members=vs_seq_seq,ratios=[ration_seq_seq])

@servicelogger
def get_pool_members(pool_name_list,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    #from ipdb import set_trace;set_trace()
    return client.service.get_member_v2(pool_names=pool_name_list)

@servicelogger
def create_pool(pool_name, lb_methods=[""], members=[{"name":"","server":""}],orders=[""],bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    ##create_v2(Common.StringSequence pool_names, GlobalLB.LBMethodSequence lb_methods, GlobalLB.VirtualServerIDSequenceSequence members, Common.ULongSequenceSequence orders, )
    return client.service.create_v2(pool_names=[pool_name],lb_methods=lb_methods,members=members,orders=orders)

@servicelogger
def add_pool_member(pool_name,vs_name,server_name,order=0,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param pool_name:
    :param members: [{name,server,order},{}]
    :param hostname:
    :return:
    [[(GlobalLB.VirtualServerID){
   name = "VS_SH_JQ_WEB1"
   server = "/Common/SH_JQ_WEB1"
 }, (GlobalLB.VirtualServerID){
   name = "VS_SH_JQ_WEB2"
   server = "/Common/SH_JQ_WEB2"
 }, (GlobalLB.VirtualServerID){
   name = "VS_SH_YP_WEB1"
   server = "/Common/SH_YP_WEB1"
 }, (GlobalLB.VirtualServerID){
   name = "VS_SH_YP_WEB2"
   server = "/Common/SH_YP_WEB2"
 }]]
    '''
    client = clientFactory.get_poolclient(bigip = bigip)
    vs_seq_seq = client.factory.create("GlobalLB.VirtualServerIDSequenceSequence")
    vs_seq = client.factory.create("GlobalLB.VirtualServerIDSequence")
    vs = client.factory.create("GlobalLB.VirtualServerID")
    vs.name=vs_name
    vs.server=server_name

    vs_seq.members=[vs]
    vs_seq_seq.members=[vs_seq]

    or_seq_seq = client.factory.create("Common.ULongSequenceSequence")
    or_seq_seq.orders=[order]

    return client.service.add_member_v2(pool_names=[pool_name],members=vs_seq_seq,orders=[or_seq_seq])


@servicelogger
def delete_pool_member(pool_name,vs_name,server_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''
    :param pool_name:
    :param members: [{name,server,order},{}]
    :param hostname:
    :return:
    '''
    client = clientFactory.get_poolclient(bigip = bigip)
    vs_seq_seq = client.factory.create("GlobalLB.VirtualServerIDSequenceSequence")
    vs_seq = client.factory.create("GlobalLB.VirtualServerIDSequence")
    vs = client.factory.create("GlobalLB.VirtualServerID")
    vs.name=vs_name
    vs.server=server_name

    vs_seq.members=[vs]
    vs_seq_seq.members=[vs_seq]

    return client.service.remove_member_v2\
        (pool_names=[pool_name],members=vs_seq_seq)

@servicelogger
def get_pool_member_order(pool_name,vs_name,server_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''

    :param pool_name:
    :param vs_name:
    :param server_name:
    :param hostname:
    :return:
    '''
    client = clientFactory.get_poolclient(bigip = bigip)
    vs_seq_seq = client.factory.create("GlobalLB.VirtualServerIDSequenceSequence")
    vs_seq = client.factory.create("GlobalLB.VirtualServerIDSequence")
    vs = client.factory.create("GlobalLB.VirtualServerID")
    vs.name=vs_name
    vs.server=server_name
    vs_seq.members=[vs]
    vs_seq_seq.members=[vs_seq]
    return client.service.get_member_order(pool_names=[pool_name],members=vs_seq_seq)


@servicelogger
def set_pool_member_order(pool_name,vs_name,server_name,order=0,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''

    :param pool_name:
    :param vs_name:
    :param server_name:
    :param hostname:
    :return:
    '''
    client = clientFactory.get_poolclient(bigip = bigip)
    vs_seq_seq = client.factory.create("GlobalLB.VirtualServerIDSequenceSequence")
    vs_seq = client.factory.create("GlobalLB.VirtualServerIDSequence")
    vs = client.factory.create("GlobalLB.VirtualServerID")
    vs.name=vs_name
    vs.server=server_name

    vs_seq.members=[vs]
    vs_seq_seq.members=[vs_seq]

    or_seq_seq = client.factory.create("Common.ULongSequenceSequence")
    or_seq_seq.orders=[order]
    return client.service.set_member_order(pool_names=[pool_name],members=vs_seq_seq,orders = [or_seq_seq])


@servicelogger
def delete_pool_all_members(pool_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    return client.service.remove_all_members(pool_names=[pool_name])


# def get_pool_status(pool_name,hostname='172.16.115.1'):
#     client = clientFactory.get_poolclient(bigip = bigip)
#     return client.service.get_object_status(pool_names=[pool_name])

@servicelogger
def get_preferred_lb_method(pool_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    return client.service.get_preferred_lb_method(pool_names=[pool_name])


@servicelogger
def get_alternate_lb_method(pool_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)

    return client.service.get_alternate_lb_method(pool_names=[pool_name])


@servicelogger
def get_fallback_lb_method(pool_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    return client.service.get_fallback_lb_method(pool_names=[pool_name])


@servicelogger
def set_preferred_lb_method(pool_name,lb_method,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''
    :param pool_name:
    :param lb_method:
    (GlobalLB.LBMethod){
   LB_METHOD_RETURN_TO_DNS = "LB_METHOD_RETURN_TO_DNS"
   LB_METHOD_NULL = "LB_METHOD_NULL"
   LB_METHOD_ROUND_ROBIN = "LB_METHOD_ROUND_ROBIN"
   LB_METHOD_RATIO = "LB_METHOD_RATIO"
   LB_METHOD_TOPOLOGY = "LB_METHOD_TOPOLOGY"
   LB_METHOD_STATIC_PERSIST = "LB_METHOD_STATIC_PERSIST"
   LB_METHOD_GLOBAL_AVAILABILITY = "LB_METHOD_GLOBAL_AVAILABILITY"
   LB_METHOD_VS_CAPACITY = "LB_METHOD_VS_CAPACITY"
   LB_METHOD_LEAST_CONN = "LB_METHOD_LEAST_CONN"
   LB_METHOD_LOWEST_RTT = "LB_METHOD_LOWEST_RTT"
   LB_METHOD_LOWEST_HOPS = "LB_METHOD_LOWEST_HOPS"
   LB_METHOD_PACKET_RATE = "LB_METHOD_PACKET_RATE"
   LB_METHOD_CPU = "LB_METHOD_CPU"
   LB_METHOD_HIT_RATIO = "LB_METHOD_HIT_RATIO"
   LB_METHOD_QOS = "LB_METHOD_QOS"
   LB_METHOD_BPS = "LB_METHOD_BPS"
   LB_METHOD_DROP_PACKET = "LB_METHOD_DROP_PACKET"
   LB_METHOD_EXPLICIT_IP = "LB_METHOD_EXPLICIT_IP"
   LB_METHOD_CONNECTION_RATE = "LB_METHOD_CONNECTION_RATE"
   LB_METHOD_VS_SCORE = "LB_METHOD_VS_SCORE"
 }
    :param hostname:
    :return:
    '''
    client = clientFactory.get_poolclient(bigip = bigip)
    # lb_method_em = client.factory.create('GlobalLB.LBMethod')
    # print lb_method_em

    lb_method_seq = client.factory.create('GlobalLB.LBMethodSequence')
    lb_method_seq.lb_methods=[lb_method]

    return client.service.set_preferred_lb_method(pool_names=[pool_name],lb_methods=lb_method_seq)


@servicelogger
def set_fallback_lb_method(pool_name,lb_method,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''
    :param pool_name:
    :param lb_method:
    (GlobalLB.LBMethod){
   LB_METHOD_RETURN_TO_DNS = "LB_METHOD_RETURN_TO_DNS"
   LB_METHOD_NULL = "LB_METHOD_NULL"
   LB_METHOD_ROUND_ROBIN = "LB_METHOD_ROUND_ROBIN"
   LB_METHOD_RATIO = "LB_METHOD_RATIO"
   LB_METHOD_TOPOLOGY = "LB_METHOD_TOPOLOGY"
   LB_METHOD_STATIC_PERSIST = "LB_METHOD_STATIC_PERSIST"
   LB_METHOD_GLOBAL_AVAILABILITY = "LB_METHOD_GLOBAL_AVAILABILITY"
   LB_METHOD_VS_CAPACITY = "LB_METHOD_VS_CAPACITY"
   LB_METHOD_LEAST_CONN = "LB_METHOD_LEAST_CONN"
   LB_METHOD_LOWEST_RTT = "LB_METHOD_LOWEST_RTT"
   LB_METHOD_LOWEST_HOPS = "LB_METHOD_LOWEST_HOPS"
   LB_METHOD_PACKET_RATE = "LB_METHOD_PACKET_RATE"
   LB_METHOD_CPU = "LB_METHOD_CPU"
   LB_METHOD_HIT_RATIO = "LB_METHOD_HIT_RATIO"
   LB_METHOD_QOS = "LB_METHOD_QOS"
   LB_METHOD_BPS = "LB_METHOD_BPS"
   LB_METHOD_DROP_PACKET = "LB_METHOD_DROP_PACKET"
   LB_METHOD_EXPLICIT_IP = "LB_METHOD_EXPLICIT_IP"
   LB_METHOD_CONNECTION_RATE = "LB_METHOD_CONNECTION_RATE"
   LB_METHOD_VS_SCORE = "LB_METHOD_VS_SCORE"
 }
    :param hostname:
    :return:
    '''
    client = clientFactory.get_poolclient(bigip = bigip)
    # lb_method_em = client.factory.create('GlobalLB.LBMethod')
    # print lb_method_em

    lb_method_seq = client.factory.create('GlobalLB.LBMethodSequence')
    lb_method_seq.lb_methods=[lb_method]

    return client.service.set_fallback_lb_method(pool_names=[pool_name],lb_methods=lb_method_seq)


@servicelogger
def set_alternate_lb_method(pool_name,lb_method,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''
    :param pool_name:
    :param lb_method:
    (GlobalLB.LBMethod){
   LB_METHOD_RETURN_TO_DNS = "LB_METHOD_RETURN_TO_DNS"
   LB_METHOD_NULL = "LB_METHOD_NULL"
   LB_METHOD_ROUND_ROBIN = "LB_METHOD_ROUND_ROBIN"
   LB_METHOD_RATIO = "LB_METHOD_RATIO"
   LB_METHOD_TOPOLOGY = "LB_METHOD_TOPOLOGY"
   LB_METHOD_STATIC_PERSIST = "LB_METHOD_STATIC_PERSIST"
   LB_METHOD_GLOBAL_AVAILABILITY = "LB_METHOD_GLOBAL_AVAILABILITY"
   LB_METHOD_VS_CAPACITY = "LB_METHOD_VS_CAPACITY"
   LB_METHOD_LEAST_CONN = "LB_METHOD_LEAST_CONN"
   LB_METHOD_LOWEST_RTT = "LB_METHOD_LOWEST_RTT"
   LB_METHOD_LOWEST_HOPS = "LB_METHOD_LOWEST_HOPS"
   LB_METHOD_PACKET_RATE = "LB_METHOD_PACKET_RATE"
   LB_METHOD_CPU = "LB_METHOD_CPU"
   LB_METHOD_HIT_RATIO = "LB_METHOD_HIT_RATIO"
   LB_METHOD_QOS = "LB_METHOD_QOS"
   LB_METHOD_BPS = "LB_METHOD_BPS"
   LB_METHOD_DROP_PACKET = "LB_METHOD_DROP_PACKET"
   LB_METHOD_EXPLICIT_IP = "LB_METHOD_EXPLICIT_IP"
   LB_METHOD_CONNECTION_RATE = "LB_METHOD_CONNECTION_RATE"
   LB_METHOD_VS_SCORE = "LB_METHOD_VS_SCORE"
 }
    :param hostname:
    :return:
    '''
    client = clientFactory.get_poolclient(bigip = bigip)
    # lb_method_em = client.factory.create('GlobalLB.LBMethod')
    # print lb_method_em

    lb_method_seq = client.factory.create('GlobalLB.LBMethodSequence')
    lb_method_seq.lb_methods=[lb_method]

    return client.service.set_alternate_lb_method(pool_names=[pool_name],lb_methods=lb_method_seq)


@servicelogger
def get_pool_monitor(pool_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    return client.service.get_monitor_association(pool_names=[pool_name])


@servicelogger
def set_pool_monitor(pool_name,monitor_rule_type,monitor_templates_list,quorum = 0,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''
    :param pool_name:
    :param monitor_rule_type:
     (GlobalLB.MonitorRuleType){
   MONITOR_RULE_TYPE_UNDEFINED = "MONITOR_RULE_TYPE_UNDEFINED"
   MONITOR_RULE_TYPE_NONE = "MONITOR_RULE_TYPE_NONE"
   MONITOR_RULE_TYPE_SINGLE = "MONITOR_RULE_TYPE_SINGLE"
   MONITOR_RULE_TYPE_AND_LIST = "MONITOR_RULE_TYPE_AND_LIST"
   MONITOR_RULE_TYPE_M_OF_N = "MONITOR_RULE_TYPE_M_OF_N"
 }
    :param monitor_templates_list:
    :param quorum:
    :param hostname:
    :return:
    '''
    client = clientFactory.get_poolclient(bigip = bigip)
    monitor_ass_seq = client.factory.create('GlobalLB.Pool.MonitorAssociationSequence')

    monitor_ass = client.factory.create('GlobalLB.Pool.MonitorAssociation')
    monitor_rule = client.factory.create('GlobalLB.MonitorRule')

    # monitor_type = client.factory.create('GlobalLB.MonitorRuleType')
    # print monitor_type

    monitor_rule.type = monitor_rule_type
    monitor_rule.quorum = quorum
    monitor_rule.monitor_templates = monitor_templates_list

    monitor_ass.pool_name=pool_name
    monitor_ass.monitor_rule=monitor_rule

    monitor_ass_seq.monitor_associations = [monitor_ass]
    return client.service.set_monitor_association(monitor_ass_seq)


@servicelogger
def delete_pool(pool_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_poolclient(bigip = bigip)
    return client.service.delete_pool(pool_names=[pool_name])



#===============================================================================
# load_method , LB_METHOD_RETURN_TO_DNS LB_METHOD_NULL
# LB_METHOD_ROUND_ROBIN LB_METHOD_RATIO
#===============================================================================

# @clientFactory.bigsuds_transaction
# def create_pool_2(name , preferred_lb , alternated_lb , fallback_lb , member_dict_list = None ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
#
#     members = []
#     orders = []
#     if member_dict_list:
#
#         for member_dict in member_dict_list:
#
#             members.append({ "name": member_dict.get('name') })
#             orders.append(member_dict.get('order'))
# #         members=[{"name":"","server":""}],orders=[""]
#     create_pool(name, [preferred_lb , alternated_lb , fallback_lb ], members, orders, bigip)

if __name__ == '__main__':
    # print get_all_pools()
    # print get_pool_status(pool_name="/Common/Pool_SH_YP_CNC_First")
    print get_member_ratio(pool_name="/Common/Pool_SH_YP_CNC_First",vs_name="VS_SH_JQ_WEB1",server_name="/Common/SH_JQ_WEB1")
    # print get_pool_members(pool_name="/Common/Pool_SH_YP_CNC_First")
    print set_member_ratio(pool_name="/Common/Pool_SH_YP_CNC_First",vs_name="VS_SH_JQ_WEB1",server_name="/Common/SH_JQ_WEB1",ratio=3)
    print get_member_ratio(pool_name="/Common/Pool_SH_YP_CNC_First",vs_name="VS_SH_JQ_WEB1",server_name="/Common/SH_JQ_WEB1")

    #print set_pool_monitor(pool_name="/Common/Pool_SH_YP_CNC_First",monitor_rule_type="MONITOR_RULE_TYPE_AND_LIST",monitor_templates_list=['/Common/http','/Common/gateway_icmp'])
    #delete_pool_all_members(pool_name="/Common/Pool_123456")
    #print create_pool(pool_name="/Common/Pool_123456")
    # members=[{"name":"VS_SH_YP_WEB1","server":"/Common/SH_YP_WEB1","order":0}]
    # print add_pool_member(pool_name="/Common/Pool_123456",vs_name="VS_SH_JQ_WEB1",server_name="/Common/SH_JQ_WEB1",order=0)
    # print add_pool_member(pool_name="/Common/Pool_123456",vs_name="VS_SH_JQ_WEB2",server_name="/Common/SH_JQ_WEB2",order=0)
    #delete_pool_all_members(pool_name="/Common/Pool_123456")
    #delete_pool(pool_name="/Common/Pool_123456")

    ##改变member order

