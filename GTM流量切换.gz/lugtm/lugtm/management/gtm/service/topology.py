#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/5
# Topology client
 # create(GlobalLB.Topology.TopologyRecordSequence records, Common.ULongSequence weights, Common.ULongSequence orders, )
 #            delete_all_topology_records()
 #            delete_topology_record(GlobalLB.Topology.TopologyRecordSequence records, )
 #            get_description(GlobalLB.Topology.TopologyRecordSequence records, )
 #            get_list()
 #            get_order(GlobalLB.Topology.TopologyRecordSequence records, )
 #            get_version()
 #            get_weight(GlobalLB.Topology.TopologyRecordSequence records, )
 #            set_description(GlobalLB.Topology.TopologyRecordSequence records, Common.StringSequence descriptions, )
 #            set_order(GlobalLB.Topology.TopologyRecordSequence records, Common.ULongSequence orders, )
 #            set_weight(GlobalLB.Topology.TopologyRecordSequence records, Common.ULongSequence weights, )
import time

import requests

import lugtm.base_sys.client_factory as clientFactory
import bigsuds
import logging
from lugtm.tools.logger import servicelogger
from lugtm.settings import BIGIP_ADDRESS


logger = logging.getLogger("lugtm.views")


def process_topology_records(province_new_records):
    '''
    处理region及其对应datacenter的策略，根据此数据重新设置策略weight,order
    :param province_new_records: {"CN_BeiJing_Other":[{"dc_name":"","weight":"10800","order":"355"},{}]} ##weight由高到低
    :return:
    '''
    result = False
    bigip=clientFactory.sbigip()
    records_list = list()
    weights = list()
    orders = list()
    regiontype = get_topology_regiontype(bigip)
    for region_key,records in province_new_records.iteritems():
        # if region_key != "CN_BeiJing_Other":
        #     continue
        for r in records:
            dc_name = r["dc_name"]
            weight = r["weight"]
            order = r["order"]
            topology_record = topologyrecord(region_key, regiontype.REGION_TYPE_REGION,
                dc_name,regiontype.REGION_TYPE_DATA_CENTER, bigip=bigip)
            records_list.append(topology_record)
            weights.append(weight)
            orders.append(order)
    if records_list and weights and orders:
        result = True
        handle_gtm_topology_transction(records_list,weights,orders,bigip=bigip)
    return result

def process_topology_records_all(province_new_records):
    '''
    处理region及其对应datacenter的策略，根据此数据重新设置策略weight,order
    :param province_new_records: {"CN_BeiJing_Other":[{"dc_name":"","weight":"10800","order":"355"},{}]} ##weight由高到低
    :return:
    '''
    result = False
    bigip=clientFactory.sbigip()
    records_list = list()
    weights = list()
    orders = list()
    logger.info('IDC_CHANGE: province_new_records is %s', province_new_records)
    regiontype = get_topology_regiontype(bigip)
    for province_new_record in province_new_records:
        for region_key,records in province_new_record.iteritems():
            for r in records:
                dc_name = r["dc_name"]
                weight = r["weight"]
                order = r["order"]
                topology_record = topologyrecord(region_key, regiontype.REGION_TYPE_REGION,
                    dc_name,regiontype.REGION_TYPE_DATA_CENTER, bigip=bigip)
                records_list.append(topology_record)
                weights.append(weight)
                orders.append(order)
    if records_list and weights and orders:
        result = True
        logger.info('IDC_CHANGE: before trans records_list is %s', records_list)
        handle_gtm_topology_transction_all(records_list,weights,orders,bigip=bigip)
    return result

# @clientFactory.bigsuds_transaction
def handle_gtm_topology_transction(topology_records,weights,orders,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    处理records，重新设置weights,orders
    '''
    bigip2 = bigip.with_session_id()
    bigip2.System.Session.set_transaction_timeout(20)
    with bigsuds.Transaction(bigip2) as t_bigip:
        for i in range(len(topology_records)):
            record = topology_records[i]
            weight = weights[i]
            order = orders[i]
            set_topology_weight_by_topologyrecord(record,weight,bigip=t_bigip)
            set_topology_order_by_topologyrecord(record,order,bigip=t_bigip)

def handle_gtm_topology_transction_all(topology_records,weights,orders,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    处理records，重新设置weights,orders
    '''
    bigip2 = bigip.with_session_id()
    bigip2.System.Session.set_transaction_timeout(20)
    with bigsuds.Transaction(bigip2) as t_bigip:
        set_topology_weight_by_topologyrecord_all(topology_records,weights,bigip=t_bigip)
        set_topology_order_by_topologyrecord_all(topology_records,orders,bigip=t_bigip)

def get_soap_topology_records_weights(province_pinyin,operator,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    """
    :param province_pinyin:省份拼音
    :param operator:运营商
    :param bigip:
    :return:([TopologyRecord,TopologyRecord],[weight,weight])
    """
    records = []
    t_list = get_all_topology(bigip=bigip)
    for topology in t_list:
        region_name = topology.ldns.content
        if province_pinyin in region_name and operator in region_name:
            records.append(topology)
    weights = get_topology_weight_by_records(records,bigip=bigip)
    return records,weights


def get_all_topology(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_topologyclient(bigip = bigip)
    return client.service.get_list()


@servicelogger
def topologyrecord(src, srctype_em , dest , desttype_em , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    @srctype_em  get_topology_regiontype
    '''
    client = clientFactory.get_topologyclient(bigip = bigip)
    server_endport = client.factory.create('GlobalLB.Topology.TopologyEndpoint')
    server_endport.content = dest
    server_endport.negate = False
    server_endport.type = desttype_em
    ldns_endport = client.factory.create('GlobalLB.Topology.TopologyEndpoint')
    ldns_endport.content = src
    ldns_endport.negate = False
    ldns_endport.type = srctype_em
    record = client.factory.create('GlobalLB.Topology.TopologyRecord')
    record.server = server_endport
    record.ldns = ldns_endport
    return record


@servicelogger
def get_topology_regiontype(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_topologyclient(bigip = bigip)
    regiontype = client.factory.create('GlobalLB.RegionType')
    return regiontype


@servicelogger
def get_topology_weight_by_record(toplogyrecord ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    """
    @param toplogyrecord: topologyrecord
    @return:
    """
    client = clientFactory.get_topologyclient(bigip = bigip)
    recordseq = client.factory.create('GlobalLB.Topology.TopologyRecordSequence')
    recordseq.records = [toplogyrecord]
    return client.service.get_weight(recordseq)


def get_topology_weight_by_records(toplogyrecords,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    """
    @param toplogyrecords: [topologyrecord]
    @return:
    """
    client = clientFactory.get_topologyclient(bigip = bigip)
    recordseq = client.factory.create('GlobalLB.Topology.TopologyRecordSequence')
    recordseq.records = toplogyrecords
    return client.service.get_weight(recordseq),client.service.get_order(recordseq)


def get_topology_orders_by_records(toplogyrecords,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    """
    @param toplogyrecords: [topologyrecord]
    @return:
    """
    client = clientFactory.get_topologyclient(bigip = bigip)
    recordseq = client.factory.create('GlobalLB.Topology.TopologyRecordSequence')
    recordseq.records = toplogyrecords
    return client.service.get_order(recordseq)

@servicelogger
def set_topology_weight_by_topologyrecord(toplogyrecord , weight ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_topologyclient(bigip = bigip)
    recordseq = client.factory.create('GlobalLB.Topology.TopologyRecordSequence')
    recordseq.records = [toplogyrecord]
    weightsequence = client.factory.create('Common.ULongSequence')
    weightsequence.weights =  [weight]
    return client.service.set_weight(recordseq,weightsequence)

@servicelogger
def set_topology_weight_by_topologyrecord_all(toplogyrecord , weight ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_topologyclient(bigip = bigip)
    recordseq = client.factory.create('GlobalLB.Topology.TopologyRecordSequence')
    recordseq.records = toplogyrecord
    weightsequence = client.factory.create('Common.ULongSequence')
    weightsequence.weights =  weight
    return client.service.set_weight(recordseq,weightsequence)


@servicelogger
def get_topology_order_by_record(toplogyrecord ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    """
    @param toplogyrecord: topologyrecord
    @return:
    """
    client = clientFactory.get_topologyclient(bigip = bigip)
    recordseq = client.factory.create('GlobalLB.Topology.TopologyRecordSequence')
    recordseq.records = [toplogyrecord]
    return client.service.get_order(recordseq)


@servicelogger
def set_topology_order_by_topologyrecord(toplogyrecord , order ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_topologyclient(bigip = bigip)
    recordseq = client.factory.create('GlobalLB.Topology.TopologyRecordSequence')
    recordseq.records = [toplogyrecord]
    ordersequence = client.factory.create('Common.ULongSequence')
    ordersequence.orders =  [order]
    return client.service.set_order(recordseq,ordersequence)

@servicelogger
def set_topology_order_by_topologyrecord_all(toplogyrecord , order ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_topologyclient(bigip = bigip)
    recordseq = client.factory.create('GlobalLB.Topology.TopologyRecordSequence')
    recordseq.records = toplogyrecord
    ordersequence = client.factory.create('Common.ULongSequence')
    ordersequence.orders =  order
    return client.service.set_order(recordseq,ordersequence)


@servicelogger
def delete_topology_record(toplogyrecord ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_topologyclient(bigip = bigip)
    recordseq = client.factory.create('GlobalLB.Topology.TopologyRecordSequence')
    recordseq.records = [toplogyrecord]
    return client.service.delete_topology_record(recordseq)


'''
import  lugtm.base_sys.client_factory as clientFactory
client = clientFactory.get_topologyclient()
regiontype = client.factory.create('GlobalLB.RegionType')
server_endport = client.factory.create('GlobalLB.Topology.TopologyEndpoint')
server_endport.content = '/Common/SH_JQ_CMCC'
server_endport.negate = False
server_endport.type = regiontype.REGION_TYPE_DATA_CENTER
ldns_endport = client.factory.create('GlobalLB.Topology.TopologyEndpoint')
ldns_endport.content = '/Common/gtm_test_region_lcl'
ldns_endport.negate = False
ldns_endport.type = regiontype.REGION_TYPE_REGION
record = client.factory.create('GlobalLB.Topology.TopologyRecord')
record.server = server_endport
record.ldns = ldns_endport
TG.create_topology(record, 22, 22)

'''
@servicelogger
def create_topology(toplogyrecord , weight , order,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_topologyclient(bigip = bigip)
    recordseq = client.factory.create('GlobalLB.Topology.TopologyRecordSequence')
    recordseq.records = [toplogyrecord]
    weightsequence = client.factory.create('Common.ULongSequence')
    weightsequence.weights =  [weight]
    ordersequence = client.factory.create('Common.ULongSequence')
    ordersequence.orders = [order]
    return client.service.create(recordseq ,weightsequence , ordersequence)


def percent_change_service(source_idc, destination_idc, provinces):
    # body = {"source_idc": "外高桥", "destination_idc": "宝信", "provinces": ",".join(bx_provinces)}
    start = time.time()
    direction = "%s > %s" % (source_idc, destination_idc)
    logger.info('percent_change_service: direction %s, provinces: %s' % (direction, provinces))
    if not provinces:
        logger.info('provinces 为空')
        return "provinces 为空"
    body = {"source_idc": source_idc, "destination_idc": destination_idc, "provinces": ",".join(provinces)}
    res = requests.post("http://127.0.0.1:8888/api/mgm/gtm/changeservice/?token=d37a11c829a74af983f120eaf7b3a520",
                        body)
    all_text = ""
    end = time.time()
    if res.status_code != 200:
        all_status_code = res.status_code
        logger.error('percent_change_service: error direction %s, res: %s' % (direction, res.content))
        all_text += '%s cost %s fail;' % (direction, end-start)
    else:
        all_text += '%s cost %s ok;' % (direction, end-start)

    return all_text


