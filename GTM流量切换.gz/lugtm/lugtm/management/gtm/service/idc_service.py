#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/4/5
from lugtm.tools.logger import servicelogger
from lugtm.datamodel.models import IDC,Province,ProvinceTrafficPercentageModel,IdcPercentageModel
from lugtm.management.platform.service.topology_db_service import get_topology_summary_dict_load
from lugtm.settings import UNDER_LINE


def get_idc_summary():
    '''
    获取策略中机房分布概况，暂未使用
    :return:
    '''
    # result = []
    idc_list = IDC.objects.all()
    topology_dict = get_topology_summary_dict_load()
    # print topology_dict
    count_data = dict()
    for idc in idc_list:
        count_data[idc.name] = 0
    all_count = len(topology_dict.keys())
    for k,v in topology_dict.iteritems():
        max_dc = v[0].get("dc_name")
        for idc in idc_list:
            if idc.code in max_dc and idc.location in max_dc:
                old = count_data.get(idc.name)
                count_data[idc.name] = old + 1
    for k,v in count_data.iteritems():
        v_p = round(float(v)/all_count,2)
        count_data[k] = v_p
    # count_data["total"] = all_count
    return count_data


def get_idc_summary_grafana():
    '''
    获取本地解析得到的机房流量分布概况 暂未使用
    :return:
    '''
    result = dict()
    idc_list = IdcPercentageModel.objects.all()

    for i_p in idc_list:
        percentage = i_p.percentage
        gtm_code = i_p.gtm_code
        idcs = IDC.objects.filter(code=gtm_code)
        data = dict()
        data["percentage"] = percentage
        data["province_max"] = 0.0
        if idcs:
            name = idcs[0].name
            result[name] = data
        else:
            result[gtm_code] = data
    from lugtm.management.platform.service.base_data import get_all_provinces_percentage
    p_vs = get_all_provinces_percentage()
    for p_v in p_vs:
        dc_name = p_v["to_idc"]
        value = p_v["percentage"]
        if dc_name in result.keys():
            v1 = result.get(dc_name).get("province_max")
            if value > v1:
                result.get(dc_name)["province_max"] = value
    return result


def get_idc_summary_local():
    '''
    获取本地解析得到的机房流量分布概况
    :return:
    '''
    result = dict()

    idcs = IDC.objects.all()
    for idc in idcs:
        #values = IdcPercentageModel.objects.filter(code=idc.code)
        data = dict()
        data["percentage"] = 0.0
        # if values:
        #     data["percentage"] = values[0].percentage
        data["province_max"] = 0.0
        data["province_avg"] = 0.0
        result[idc.name] = data

    from lugtm.management.platform.service.base_data import get_all_provinces_percentage
    p_vs = get_all_provinces_percentage()
    for p_v in p_vs:
        dc_name = p_v.get("to_idc", None)
        value = p_v["percentage"]
        avg_value = p_v.get("avg_percentage", 0.0)
        if dc_name in result.keys():
            v_max = result.get(dc_name).get("province_max")
            v_avg = result.get(dc_name).get("province_avg")
            v = result.get(dc_name).get("percentage")
            result.get(dc_name)["province_avg"] = v_avg+avg_value
            result.get(dc_name)["percentage"] = v+value
            if value > v_max:
                result.get(dc_name)["province_max"] = value
    for k,v in result.iteritems():
        current_value = round(v["percentage"], 2)
        avg_value = round(v["province_avg"], 2)
        result[k]["percentage"] = current_value
        result[k]["province_avg"] = avg_value
    return result


def get_province_list(idc_name=None):
    '''
    按idc获取对应策略的省份
    :param idc_name:
    :return:
    '''
    topology_dict = get_topology_summary_dict_load()
    result = dict()
    if idc_name:
        idc_list = IDC.objects.filter(name=idc_name)
    else:
        idc_list = IDC.objects.all()
    idc_p_code = dict()
    if idc_list:
        for idc in idc_list:
            p_list = list()
            for k, v in topology_dict.iteritems():
                if k == 'Other':
                    continue
                max_dc = v[0].get("dc_name")
                if idc.code in max_dc and idc.location in max_dc:
                    region_name = k
                    province_code = region_name[region_name.index(UNDER_LINE)+1:region_name.rindex(UNDER_LINE)]
                    if province_code not in p_list:
                        p_list.append(province_code)
            idc_p_code[idc.name] = p_list
    if idc_p_code:
        for k,v in idc_p_code.iteritems():
            p_name_list = list()
            for p_code in v:
                p_dict = dict()
                provinces = Province.objects.filter(code=p_code)
                if not provinces:
                    continue
                percentages = ProvinceTrafficPercentageModel.objects.filter(province=provinces[0])
                if not percentages:
                    continue
                p_dict["percentage"] = percentages[0].percentage
                p_dict["province"] = provinces[0].name
                p_name_list.append(p_dict)
            result[k] = p_name_list
    return result










