from lugtm.tools.logger import servicelogger
from lugtm.base_sys.client_factory import get_ruleclient


@servicelogger
def get_all_rule(bigip):

    ruleclient = get_ruleclient(bigip)
    return ruleclient.service.get_list()


rule_definition_example = '''

when RULE_INIT {

   # Set a global max for number of concurrent TCP connections
   set ::max_connections 2

   # Set an HTML response to sent to clients who make a request while the VIP is over the max connection count
   set ::html_content "<html>over limit</html>"

   # Print debug messages to /var/log/ltm?  1=yes, 0=no
   set ::debug 1

   # Initialize a counter for active connections (don't modify this)
   set ::active_connections 0
}

'''

@servicelogger
def create_rule(rule_name , rule_definition, bigip):
    ruleclient = get_ruleclient(bigip)
    ruldeseq = ruleclient.factory.create('GlobalLB.Rule.RuleDefinitionSequence')

    rulde = ruleclient.factory.create('GlobalLB.Rule.RuleDefinition')

    rulde.rule_name = rule_name

    rulde.rule_definition = rule_definition
    ruldeseq.rules = [rulde]
    return ruleclient.service.create(ruldeseq)

@servicelogger
def delete_rule(rule_name , bigip):
    ruleclient = get_ruleclient(bigip)
    return ruleclient.service.delete_rule(rule_names = [rule_name])
