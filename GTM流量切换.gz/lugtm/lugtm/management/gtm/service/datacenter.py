#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/5
'''
 add_metadata(Common.StringSequence data_centers, Common.StringSequenceSequence names, Common.StringSequenceSequence values, )
            create(GlobalLB.DataCenter.DataCenterAttributeSequence data_centers, )
            delete_all_data_centers()
            delete_data_center(Common.StringSequence data_centers, )
            get_all_statistics()
            get_contact_information(Common.StringSequence data_centers, )
            get_description(Common.StringSequence data_centers, )
            get_enabled_state(Common.StringSequence data_centers, )
            get_link(Common.StringSequence data_centers, )
            get_list()
            get_location_information(Common.StringSequence data_centers, )
            get_metadata(Common.StringSequence data_centers, )
            get_metadata_description(Common.StringSequence data_centers, Common.StringSequenceSequence names, )
            get_metadata_persistence(Common.StringSequence data_centers, Common.StringSequenceSequence names, )
            get_metadata_value(Common.StringSequence data_centers, Common.StringSequenceSequence names, )
            get_object_status(Common.StringSequence data_centers, )
            get_prober_pool(Common.StringSequence data_centers, )
            get_server(Common.StringSequence data_centers, )
            get_statistics(Common.StringSequence data_centers, )
            get_version()
            remove_all_metadata(Common.StringSequence data_centers, )
            remove_metadata(Common.StringSequence data_centers, Common.StringSequenceSequence names, )
            reset_statistics(Common.StringSequence data_centers, )
            set_contact_information(Common.StringSequence data_centers, Common.StringSequence contacts, )
            set_description(Common.StringSequence data_centers, Common.StringSequence descriptions, )
            set_enabled_state(Common.StringSequence data_centers, Common.EnabledStateSequence states, )
            set_location_information(Common.StringSequence data_centers, Common.StringSequence locations, )
            set_metadata_description(Common.StringSequence data_centers, Common.StringSequenceSequence names, Common.StringSequenceSequence descriptions, )
            set_metadata_persistence(Common.StringSequence data_centers, Common.StringSequenceSequence names, Common.MetadataPersistenceSequenceSequence values, )
            set_metadata_value(Common.StringSequence data_centers, Common.StringSequenceSequence names, Common.StringSequenceSequence values, )
            set_prober_pool(Common.StringSequence data_centers, Common.StringSequence pools, )
'''

import lugtm.base_sys.client_factory as clientFactory
from lugtm.tools.logger import servicelogger
from lugtm.management.gtm.bean.datacenter import DataCenter

from lugtm.settings import BIGIP_ADDRESS

 #    [(Common.ObjectStatus){
 #   availability_status = "AVAILABILITY_STATUS_GREEN"
 #   enabled_status = "ENABLED_STATUS_ENABLED"
 #   status_description = "Available"
 # }]

AVAILABILITY_STATUS_GREEN = u"AVAILABILITY_STATUS_GREEN"
ENABLED_STATUS_ENABLED = u"ENABLED_STATUS_ENABLED"
Available = u"Available"


@servicelogger
def get_all_status_by_host(hostname=BIGIP_ADDRESS):
    result = []
    bigip = clientFactory.sbigip(hostname=hostname)
    statuses = get_all_status(bigip=bigip)
    for dc in statuses:
        result.append(dc.__dict__)
    return result


def get_all_status(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    获取当前gtm各datacenter所有状态
    :param bigip:
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    dc_list = client.service.get_list()
    names = []
    for dc in dc_list:
        names.append(dc)
    statuses = client.service.get_object_status(data_centers=names)

    result = []
    for index in range(len(names)):
        name = names[index]
        dc_status = statuses[index]
        dc_zh = name
        status = 1
        if dc_status.availability_status == AVAILABILITY_STATUS_GREEN and \
            dc_status.enabled_status == ENABLED_STATUS_ENABLED and \
            dc_status.status_description == Available:
            status = 0
        result.append(DataCenter(name,status,chinese_name=dc_zh))
    return result


@servicelogger
def get_all_datacenters(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.get_list()

@servicelogger
def get_datacenter_status(name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param datacenter: /Common/SH_YP_CMCC
    :param hostname:
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.get_object_status(data_centers=[name])

@servicelogger
def get_enabled_state(name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param datacenter: /Common/SH_YP_CMCC
    :param hostname:
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.get_enabled_state(data_centers=[name])

@servicelogger
def set_enabled_state(name,enable_state,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param name: /Common/SH_YP_CMCC
    :param enable_state:
       (Common.EnabledState){
   STATE_DISABLED = "STATE_DISABLED"
   STATE_ENABLED = "STATE_ENABLED"
    }
    :param hostname:
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    enable_state_seq = client.factory.create('Common.EnabledStateSequence')
    enable_state_seq.states = [enable_state]
    return client.service.set_enabled_state(data_centers=[name],states = enable_state_seq)

@servicelogger
def get_prober_pool(name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param name: /Common/SH_YP_CMCC
    :param hostname:
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.get_prober_pool(data_centers=[name])

@servicelogger
def set_prober_pool(name,prober_pool,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    set_prober_pool(Common.StringSequence data_centers, Common.StringSequence pools, )
    :param name:
    :param hostname:
    :return:
    '''
    '''
    :param datacenter: /Common/SH_YP_CMCC
    :param hostname:
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.set_prober_pool(data_centers=[name],pools=[prober_pool])


@servicelogger
def get_datacenters_server(names,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''

    :param names: [datacenter1,datacenter2]
    :param hostname:
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.get_server(data_centers=names)


@servicelogger
def create_datacenter(name,location='ShangHai',contact=None,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param name:
    :param location:
    :param contact:
    :param hostname:
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    datacenter_attr = client.factory.create('GlobalLB.DataCenter.DataCenterAttribute')
    datacenter_attr.name=name
    datacenter_attr.location = location
    datacenter_attr.contact = contact

    datacenter_attr_seq = client.factory.create('GlobalLB.DataCenter.DataCenterAttributeSequence')
    datacenter_attr_seq.data_centers=[datacenter_attr]

    return client.service.create(data_centers = datacenter_attr_seq)


@servicelogger
def delete_datacenter(name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param name:/Common/SH_YP_CMCC
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.delete_data_center(data_centers=[name])


@servicelogger
def get_contact(name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param name:/Common/SH_YP_CMCC
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.get_contact_information(data_centers=[name])


@servicelogger
def get_location_info(name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param name:/Common/SH_YP_CMCC
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.get_location_information(data_centers=[name])


@servicelogger
def get_description(name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param name:/Common/SH_YP_CMCC
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.get_description(data_centers=[name])


@servicelogger
def set_contact(name,contact=None,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param name:/Common/SH_YP_CMCC
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.set_contact_information(data_centers=[name],contacts=[contact])


@servicelogger
def set_location_info(name,location,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param name:/Common/SH_YP_CMCC
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.set_location_information(data_centers=[name],locations=[location])


@servicelogger
def set_description(name,description = None,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param name:/Common/SH_YP_CMCC
    :return:
    '''
    client = clientFactory.get_datacenterclient(bigip = bigip)
    return client.service.set_description(data_centers=[name],descriptions= [description])


if __name__ == '__main__':
    print get_prober_pool('/Common/SH_JQ_CMCC')
    print set_prober_pool('/Common/SH_JQ_CMCC','/Common/Prober_Pool_JQ_WEB1')
    print get_prober_pool('/Common/SH_JQ_CMCC')

    # print get_datacenters_server(['/Common/SH_JQ_CMCC','/Common/SH_YP_CMCC'])

