#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/5

'''
(GlobalLB.RegionPort)
         Methods (11):
            add_region_item(GlobalLB.Region.RegionDefinitionSequence regions, GlobalLB.Region.RegionItemSequenceSequence items, )
            create(GlobalLB.Region.RegionDefinitionSequence regions, GlobalLB.Region.RegionItemSequenceSequence items, )
            delete_all_region_definitions()
            delete_region_definition(GlobalLB.Region.RegionDefinitionSequence regions, )
            get_description(GlobalLB.Region.RegionDefinitionSequence regions, )
            get_list()
            get_region_item(GlobalLB.Region.RegionDefinitionSequence regions, )
            get_version()
            remove_all_region_items(GlobalLB.Region.RegionDefinitionSequence regions, )
            remove_region_item(GlobalLB.Region.RegionDefinitionSequence regions, GlobalLB.Region.RegionItemSequenceSequence items, )
            set_description(GlobalLB.Region.RegionDefinitionSequence regions, Common.StringSequence descriptions, )
'''

import lugtm.base_sys.client_factory as clientFactory
from lugtm.tools.logger import servicelogger
import bigsuds
from lugtm.settings import BIGIP_ADDRESS


REGION_DB_TYPE_USER_DEFINED = u'REGION_DB_TYPE_USER_DEFINED'


@servicelogger
def get_all_regions(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_regionclient(bigip=bigip)

    result = []
    for region in client.service.get_list():
        if region.db_type.upper()==REGION_DB_TYPE_USER_DEFINED:
            result.append(region)
    return result


def get_region_items(region, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param region: tns:GlobalLB.Region.RegionDefinition
    :param hostname:
    :return:
    '''
    client = clientFactory.get_regionclient(bigip=bigip)
    region_sequence = client.factory.create('GlobalLB.Region.RegionDefinitionSequence')
    region_sequence.items = [region]

    items = client.service.get_region_item(region_sequence)
    return items


@servicelogger
def get_region_items_by_name(region_name, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''
    :param region_name:
    :param hostname:
    :return:
    '''
    client = clientFactory.get_regionclient(bigip=bigip)
    region = client.factory.create('GlobalLB.Region.RegionDefinition')
    region.name = region_name
    region.db_type = REGION_DB_TYPE_USER_DEFINED
    region_sequence = client.factory.create('GlobalLB.Region.RegionDefinitionSequence')
    region_sequence.items = [region]

    items = client.service.get_region_item(region_sequence)
    return items


def create_region_items(region_name,region_items,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''

    :param region_name:
    :param region_items: tns:GlobalLB.Region.RegionItem[]
    :param hostname:
    :return:
    '''
    client = clientFactory.get_regionclient(bigip=bigip)
    region = client.factory.create('GlobalLB.Region.RegionDefinition')
    region.name = region_name
    region.db_type = REGION_DB_TYPE_USER_DEFINED
    region_sequence = client.factory.create('GlobalLB.Region.RegionDefinitionSequence')
    region_sequence.items = [region]

    items_sequence_sequence = client.factory.create('GlobalLB.Region.RegionItemSequenceSequence')

    items_sequence = client.factory.create('GlobalLB.Region.RegionItemSequence')
    items_sequence.items= region_items

    items_sequence_sequence.items=[items_sequence]

    return client.service.create(region_sequence,items_sequence_sequence)


@servicelogger
def create_cidrs_region(region_name,cidrs,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''

    :param region_name:
    :param cidrs: [cidr,cidr]
    :param hostname:
    :return:
    '''
    client = clientFactory.get_regionclient(bigip=bigip)
    region_type = client.factory.create('GlobalLB.RegionType')
    items = []
    for c in cidrs:
        item = client.factory.create('GlobalLB.Region.RegionItem')
        item.negate = False
        item.type = region_type.REGION_TYPE_CIDR
        item.content = c
        items.append(item)
    return create_region_items(region_name,items,bigip=bigip)


@servicelogger
def update_cidrs_region(region_name,cidrs,is_add = True,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''
    :param region_name:
    :param cidrs: [cidr,cidr]
    :param hostname:
    :return:
    '''
    client = clientFactory.get_regionclient(bigip=bigip)
    region_type = client.factory.create('GlobalLB.RegionType')
    items = []
    for c in cidrs:
        item = client.factory.create('GlobalLB.Region.RegionItem')
        item.negate = False
        item.type = region_type.REGION_TYPE_CIDR
        item.content = c
        items.append(item)

    region = client.factory.create('GlobalLB.Region.RegionDefinition')
    region.name = region_name
    region.db_type = REGION_DB_TYPE_USER_DEFINED
    region_sequence = client.factory.create('GlobalLB.Region.RegionDefinitionSequence')
    region_sequence.items = [region]

    items_sequence_sequence = client.factory.create('GlobalLB.Region.RegionItemSequenceSequence')

    items_sequence = client.factory.create('GlobalLB.Region.RegionItemSequence')
    items_sequence.items= items

    items_sequence_sequence.items=[items_sequence]
    if is_add:
        return client.service.add_region_item(region_sequence,items_sequence_sequence)
    else:
        return client.service.remove_region_item(region_sequence,items_sequence_sequence)


@servicelogger
def delete_region_all_items(region_name, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''
    :param name: region name
    :return:
    '''
    client = clientFactory.get_regionclient(bigip=bigip)
    region = client.factory.create('GlobalLB.Region.RegionDefinition')
    region.name = region_name
    region.db_type = REGION_DB_TYPE_USER_DEFINED
    region_sequence = client.factory.create('GlobalLB.Region.RegionDefinitionSequence')
    region_sequence.items = [region]

    return client.service.remove_all_region_items(region_sequence)


@servicelogger
def delete_region_and_items(region_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''
    :param region_name: region name
    :return:
    '''
    client = clientFactory.get_regionclient(bigip=bigip)
    region = client.factory.create('GlobalLB.Region.RegionDefinition')
    region.name = region_name
    region.db_type = REGION_DB_TYPE_USER_DEFINED
    region_sequence = client.factory.create('GlobalLB.Region.RegionDefinitionSequence')
    region_sequence.items = [region]

    return client.service.delete_region_definition(region_sequence)



# def create_cidrs_region_transaction(region_dicts,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
#     '''
#
#     :param region_dicts:{name:[cidrs]}
#     :param hostname:
#     :return:
#     '''
#     bigip = bigsuds.BIGIP(hostname = hostname)
#     bigip.System.Session.set_transaction_timeout(30000)
#     # with bigsuds.Transaction(bigip):
#     with bigsuds.Transaction(bigip.with_session_id()) as bigip :
#         client = bigip.GlobalLB.Region._client
#         # bigip.System.Session.start_transaction()
#         # bigip.System.Session.set_transaction_timeout(300)
#         region_type = client.factory.create('GlobalLB.RegionType')
#         # region_dicts = dict()
#         print region_dicts.keys()
#         for region_name in region_dicts.keys():
#             region = client.factory.create('GlobalLB.Region.RegionDefinition')
#             region.name = region_name
#             region.db_type = REGION_DB_TYPE_USER_DEFINED
#             region_sequence = client.factory.create('GlobalLB.Region.RegionDefinitionSequence')
#             region_sequence.items = [region]
#             cidrs = region_dicts[region_name]
#             items = []
#             print region_name,len(cidrs)
#             for cidr in cidrs:
#                 item = client.factory.create('GlobalLB.Region.RegionItem')
#                 item.negate = False
#                 item.type = region_type.REGION_TYPE_CIDR
#                 item.content = cidr
#                 items.append(item)
#
#             items_sequence_sequence = client.factory.create('GlobalLB.Region.RegionItemSequenceSequence')
#
#             items_sequence = client.factory.create('GlobalLB.Region.RegionItemSequence')
#             items_sequence.items= items
#             items_sequence_sequence.items=[items_sequence]
#             client.service.create(region_sequence,items_sequence_sequence)


@servicelogger
def set_region_description(region_name,description,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param region_name:
    :param description:
    :param hostname:
    :return:
    '''
    client = clientFactory.get_regionclient(bigip=bigip)
    region = client.factory.create('GlobalLB.Region.RegionDefinition')
    region.name = region_name
    region.db_type = REGION_DB_TYPE_USER_DEFINED
    region_sequence = client.factory.create('GlobalLB.Region.RegionDefinitionSequence')
    region_sequence.items = [region]
##set_description(GlobalLB.Region.RegionDefinitionSequence regions, Common.StringSequence descriptions, )
    return client.service.set_description(regions = region_sequence,descriptions=[description])


@servicelogger
def get_region_description(region_name,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    :param region_name:
    :param hostname:
    :return:
    '''
    client = clientFactory.get_regionclient(bigip=bigip)
    region = client.factory.create('GlobalLB.Region.RegionDefinition')
    region.name = region_name
    region.db_type = REGION_DB_TYPE_USER_DEFINED
    region_sequence = client.factory.create('GlobalLB.Region.RegionDefinitionSequence')
    region_sequence.items = [region]
    return client.service.get_description(regions = region_sequence)

@servicelogger
@clientFactory.bigsuds_transaction
def create_cidrs_region_transaction(region_dicts,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    '''

    :param region_dicts:{name:[cidrs]}
    :param hostname:
    :return:
    '''

    client = bigip.GlobalLB.Region._client
    # bigip.System.Session.start_transaction()
    # bigip.System.Session.set_transaction_timeout(300)
    region_type = client.factory.create('GlobalLB.RegionType')
    # region_dicts = dict()
    print region_dicts.keys()
    for region_name in region_dicts.keys():
        region = client.factory.create('GlobalLB.Region.RegionDefinition')
        region.name = region_name
        region.db_type = REGION_DB_TYPE_USER_DEFINED
        region_sequence = client.factory.create('GlobalLB.Region.RegionDefinitionSequence')
        region_sequence.items = [region]
        cidrs = region_dicts[region_name]
        items = []
        print region_name,len(cidrs)
        for cidr in cidrs:
            item = client.factory.create('GlobalLB.Region.RegionItem')
            item.negate = False
            item.type = region_type.REGION_TYPE_CIDR
            item.content = cidr
            items.append(item)

        items_sequence_sequence = client.factory.create('GlobalLB.Region.RegionItemSequenceSequence')
        items_sequence = client.factory.create('GlobalLB.Region.RegionItemSequence')
        items_sequence.items= items
        items_sequence_sequence.items=[items_sequence]
        client.service.create(region_sequence,items_sequence_sequence)


    # bigip.System.Session.submit_transaction()

if __name__ == '__main__':
    ##print delete_region_and_items('lcl_test123')

    client = bigsuds.BIGIP(hostname = '172.16.115.1').with_session_id()
    client.System.Session.start_transaction()



    serverclient = clientFactory.get_serverclient()
    server_list = serverclient.service.get_list()
    for server in server_list:
        print server
    ##print update_cidrs_region(region_name='test_lcl_0909123',cidrs=['1.3.99.0/24','1.3.5.0/24'],is_add=False)







