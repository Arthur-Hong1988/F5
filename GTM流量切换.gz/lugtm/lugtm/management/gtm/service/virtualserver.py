import  lugtm.base_sys.client_factory as clientFactory
from lugtm.tools.logger import servicelogger
from lugtm.settings import BIGIP_ADDRESS


@servicelogger
def get_all_virtualserver(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)

    return client.service.get_list()



#servername_list=[{"name":"vs_gg","server":"gg"},{"server":"SH_JQ_WEB1","name":"VS_SH_JQ_WEB1"}]
@servicelogger
def get_object_status(servername_list , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)
    return client.service.get_object_status(virtual_servers=servername_list)

@servicelogger
def get_common_state_type(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)
    return client.factory.create('Common.EnabledState')
@servicelogger
def set_enabled_state(virtual_servername, mastername, common_state_type_em , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)

    stateseq = client.factory.create('Common.EnabledStateSequence')
    stateseq.states = [common_state_type_em ]

    return client.service.set_enabled_state(virtual_servers=[{"name":virtual_servername,"server":mastername}] , states = stateseq)

@servicelogger
def get_enabled_state(servername_list , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)
    return client.service.get_enabled_state(virtual_servers=servername_list)

#servername_list=[{"name":"vs_gg","server":"gg"},{"server":"SH_JQ_WEB1","name":"VS_SH_JQ_WEB1"}]
@servicelogger
def get_translation(servername_list , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)
    return client.service.get_translation(virtual_servers=servername_list)

#servername_list=[{"name":"vs_gg","server":"gg"},{"server":"SH_JQ_WEB1","name":"VS_SH_JQ_WEB1"}]
# example translations = [{"address":  "1.1.1.1","port" : 22}, ]
@servicelogger
def set_translation(servername_list ,translations , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)
    return client.service.set_translation(virtual_servers=servername_list , translations = translations)

@servicelogger
def create(virtual_servername , masterservername,ip, port ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)
    virtualserveridseq = client.factory.create('GlobalLB.VirtualServerIDSequence')

    virtualserverid = client.factory.create('GlobalLB.VirtualServerID')
    virtualserverid.name = virtual_servername
    virtualserverid.server = masterservername
    virtualserveridseq.virtual_servers = [virtualserverid]

    ipportsequence = client.factory.create('Common.IPPortDefinitionSequence')

    ipport = client.factory.create('Common.IPPortDefinition')
    ipport.address = ip
    ipport.port = port
    ipportsequence.addresses = [ipport]
    return client.service.create(virtualserveridseq , ipportsequence)

@servicelogger
def delete_virtual_server(virtual_servername,masterservername ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)
    virtualserveridseq = client.factory.create('GlobalLB.VirtualServerIDSequence')

    virtualserverid = client.factory.create('GlobalLB.VirtualServerID')
    virtualserverid.name = virtual_servername
    virtualserverid.server = masterservername
    virtualserveridseq.virtual_servers = [virtualserverid]
    return client.service.delete_virtual_server(virtualserveridseq)

@servicelogger
def get_monitor_rule(virtual_servername, masterservername, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)
    virtualserveridseq = client.factory.create('GlobalLB.VirtualServerIDSequence')
    virtualserverid = client.factory.create('GlobalLB.VirtualServerID')
    virtualserverid.server = masterservername
    virtualserverid.name = virtual_servername
    virtualserveridseq.virtual_servers = [virtualserverid]
    return client.service.get_monitor_rule(virtualserveridseq)

@servicelogger
def get_monitorrule_type(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)
    monitortype = client.factory.create('GlobalLB.MonitorRuleType')
    return monitortype

#set_monitor_rule(GlobalLB.VirtualServerIDSequence virtual_servers, GlobalLB.MonitorRuleSequence rules, )
@servicelogger
def set_monitor_rule(virtual_servername, masterservername, monitorruletype_em, template_list ,quorum = 0 ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
        @param template_list: ['/Common/bigip']
    '''
    client = clientFactory.get_virtual_serverclient_v2(bigip=bigip)
    virtualserveridseq = client.factory.create('GlobalLB.VirtualServerIDSequence')
    virtualserverid = client.factory.create('GlobalLB.VirtualServerID')
    virtualserverid.server = masterservername
    virtualserverid.name = virtual_servername
    virtualserveridseq.virtual_servers = [virtualserverid]

    ruleseq = client.factory.create('GlobalLB.MonitorRuleSequence')

    rule = client.factory.create('GlobalLB.MonitorRule')
    rule.type = monitorruletype_em
    rule.quorum = quorum
    rule.monitor_templates = template_list

    print rule
    ruleseq.rules = rule

    return client.service.set_monitor_rule(virtualserveridseq,ruleseq)


