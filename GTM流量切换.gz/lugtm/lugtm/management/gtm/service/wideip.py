import  lugtm.base_sys.client_factory as clientFactory
from lugtm.tools.logger import servicelogger
from lugtm.settings import BIGIP_ADDRESS

"""
 add_alias(Common.StringSequence wide_ips, Common.StringSequenceSequence aliases, )
            add_metadata(Common.StringSequence wide_ips, Common.StringSequenceSequence names, Common.StringSequenceSequence values, )
            add_wideip_pool(Common.StringSequence wide_ips, GlobalLB.WideIP.WideIPPoolSequenceSequence wideip_pools, )
            add_wideip_rule(Common.StringSequence wide_ips, GlobalLB.WideIP.WideIPRuleSequenceSequence wideip_rules, )
            create(Common.StringSequence wide_ips, GlobalLB.LBMethodSequence lb_methods, GlobalLB.WideIP.WideIPPoolSequenceSequence wideip_pools, GlobalLB.WideIP.WideIPRuleSequenceSequence wideip_rules, )
            delete_all_wideips()
            delete_wideip(Common.StringSequence wide_ips, )
            get_alias(Common.StringSequence wide_ips, )
            get_all_statistics()
            get_application(Common.StringSequence wide_ips, )
            get_description(Common.StringSequence wide_ips, )
            get_enabled_state(Common.StringSequence wide_ips, )
            get_ipv6_no_error_negative_ttl(Common.StringSequence wide_ips, )
            get_ipv6_no_error_response_state(Common.StringSequence wide_ips, )
            get_last_resort_pool(Common.StringSequence wide_ips, )
            get_lb_decision_log_verbosity(Common.StringSequence wide_ips, )
            get_lb_method(Common.StringSequence wide_ips, )
            get_list()
            get_metadata(Common.StringSequence wide_ips, )
            get_metadata_description(Common.StringSequence wide_ips, Common.StringSequenceSequence names, )
            get_metadata_persistence(Common.StringSequence wide_ips, Common.StringSequenceSequence names, )
            get_metadata_value(Common.StringSequence wide_ips, Common.StringSequenceSequence names, )
            get_object_status(Common.StringSequence wide_ips, )
            get_persistence_state(Common.StringSequence wide_ips, )
            get_persistence_ttl(Common.StringSequence wide_ips, )
            get_statistics(Common.StringSequence wide_ips, )
            get_version()
            get_wideip(Common.StringSequence aliases, )
            get_wideip_pool(Common.StringSequence wide_ips, )
            get_wideip_rule(Common.StringSequence wide_ips, )
            remove_alias(Common.StringSequence wide_ips, Common.StringSequenceSequence aliases, )
            remove_all_aliases(Common.StringSequence wide_ips, )
            remove_all_metadata(Common.StringSequence wide_ips, )
            remove_all_wideip_pools(Common.StringSequence wide_ips, )
            remove_all_wideip_rules(Common.StringSequence wide_ips, )
            remove_metadata(Common.StringSequence wide_ips, Common.StringSequenceSequence names, )
            remove_wideip_pool(Common.StringSequence wide_ips, GlobalLB.WideIP.WideIPPoolSequenceSequence wideip_pools, )
            remove_wideip_rule(Common.StringSequence wide_ips, GlobalLB.WideIP.WideIPRuleSequenceSequence wideip_rules, )
            reset_application(Common.StringSequence wide_ips, )
            reset_statistics(Common.StringSequence wide_ips, )
            set_application(Common.StringSequence wide_ips, Common.StringSequence applications, )
            set_description(Common.StringSequence wide_ips, Common.StringSequence descriptions, )
            set_enabled_state(Common.StringSequence wide_ips, Common.EnabledStateSequence states, )
            set_ipv6_no_error_negative_ttl(Common.StringSequence wide_ips, Common.ULongSequence values, )
            set_ipv6_no_error_response_state(Common.StringSequence wide_ips, Common.EnabledStateSequence states, )
            set_last_resort_pool(Common.StringSequence wide_ips, Common.StringSequence pool_names, )
            set_lb_decision_log_verbosity(Common.StringSequence wide_ips, GlobalLB.WideIP.LBDecisionLogVerbositySequenceSequence verbosities, )
            set_lb_method(Common.StringSequence wide_ips, GlobalLB.LBMethodSequence lb_methods, )
            set_metadata_description(Common.StringSequence wide_ips, Common.StringSequenceSequence names, Common.StringSequenceSequence descriptions, )
            set_metadata_persistence(Common.StringSequence wide_ips, Common.StringSequenceSequence names, Common.MetadataPersistenceSequenceSequence values, )
            set_metadata_value(Common.StringSequence wide_ips, Common.StringSequenceSequence names, Common.StringSequenceSequence values, )
            set_persistence_state(Common.StringSequence wide_ips, Common.EnabledStateSequence states, )
            set_persistence_ttl(Common.StringSequence wide_ips, Common.ULongSequence values, )
"""


@servicelogger
def get_all_wideip(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_wideipclient(bigip=bigip)

    return client.service.get_list()


'''
can use it when add aliases  for a wideip
'''
# def get_wideip(wide_ip,hostname='172.16.115.1'):
#
#
#     client = clientFactory.get_wideipclient(bigip=bigip)
#
#     return client.service.get_wideip(aliases = [wide_ip])

@servicelogger
def get_wideip_pool(wide_ip,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_wideipclient(bigip=bigip)

    return client.service.get_wideip_pool(wide_ips = [wide_ip])

@servicelogger
def get_wideip_rule(wide_ip,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_wideipclient(bigip=bigip)

    return client.service.get_wideip_rule(wide_ips = [wide_ip])

# wclient.service.get_wideip_pool(wide_ips = ["web.f5.test.com"])

@servicelogger
def get_pool_list_by_wideipname_list(wideipname_list, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

#     client = clientFactory.get_wideipclient(bigip=bigip)
#     if isinstance(wideipname, (str, unicode)):
#         return client.service.get_wideip_pool(wide_ips = [wideipname])
#     elif isinstance(wideipname, list):
#         return client.service.get_wideip_pool(wide_ips = wideipname)
#
#     else:
#         raise Exception("unknown wideipname")
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.get_wideip_pool(wide_ips = wideipname_list)

@servicelogger
def create_wideip(wide_ip, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

#     if isinstance(wide_ip, (str, unicode)):
#         wide_ip = [wide_ip]
#     elif isinstance(wide_ip, list):
#         pass
#     else:
#         raise Exception("unknown wideipname")
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.create(wide_ips = [wide_ip] , lb_methods = [""] ,
                                  wideip_pools = {"pool_name": '',"order": 0, "ratio": 0 },
                                  wideip_rules = {"rule_name": "","priority": 0}
                                  )

# def add_wideip_rule(wide_ip, rule_name , rule_priority, hostname='172.16.115.1'):
#
#     client = clientFactory.get_wideipclient(bigip=bigip)
#     return client.service.add_wideip_rule(wide_ips = [wide_ip] , wideip_rules = {"rule_name": rule_name ,"priority": rule_priority })


# def add_wideip_pool(wide_ip, pool_name , pool_porder, pool_ratio, hostname='172.16.115.1' ):
#
#     client = clientFactory.get_wideipclient(bigip=bigip)
#     return client.service.add_wideip_pool(wide_ips = [wide_ip] , wideip_pools = {"pool_name": pool_name ,"ratio": pool_ratio })
@servicelogger
def add_wideip_rule(wide_ip, rule_name , rule_priority, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_wideipclient(bigip=bigip)
    wideiprulseqseq = client.factory.create('GlobalLB.WideIP.WideIPRuleSequenceSequence')
    wideiprulseq = client.factory.create('GlobalLB.WideIP.WideIPRuleSequence')

    wideiprule =  client.factory.create('GlobalLB.WideIP.WideIPRule')
    wideiprule.rule_name = rule_name
    wideiprule.priority = rule_priority
    wideiprulseq.wideip_rules = [wideiprule]
    wideiprulseqseq.wideip_rules = [wideiprulseq]
    return client.service.add_wideip_rule(wide_ips = [wide_ip] , wideip_rules = wideiprulseqseq)

@servicelogger
def add_wideip_pool(wide_ip, pool_name , pool_porder, pool_ratio, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS) ):

    client = clientFactory.get_wideipclient(bigip=bigip)


    poolseqseq = client.factory.create('GlobalLB.WideIP.WideIPPoolSequenceSequence')

    poolseq = client.factory.create('GlobalLB.WideIP.WideIPPoolSequence')

    pool = client.factory.create('GlobalLB.WideIP.WideIPPool')
    pool.pool_name = pool_name
    pool.order = pool_porder
    pool.ratio = pool_ratio
    poolseq.wideip_pools = [pool]
    poolseqseq.wideip_pools = [poolseq]

    return client.service.add_wideip_pool(wide_ips = [wide_ip] , wideip_pools = poolseqseq)

@servicelogger
def remove_wideip_rule(wide_ip , rule_name ,  bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    wideiprulseqseq = client.factory.create('GlobalLB.WideIP.WideIPRuleSequenceSequence')
    wideiprulseq = client.factory.create('GlobalLB.WideIP.WideIPRuleSequence')

    wideiprule =  client.factory.create('GlobalLB.WideIP.WideIPRule')
    wideiprule.rule_name = rule_name
    wideiprule.priority = 0
    wideiprulseq.wideip_rules = [wideiprule]
    wideiprulseqseq.wideip_rules = [wideiprulseq]
    return client.service.remove_wideip_rule(wide_ips = [wide_ip] , wideip_rules = wideiprulseqseq)

@servicelogger
def remove_wideip_pool(wide_ip , pool_name ,  bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    poolseqseq = client.factory.create('GlobalLB.WideIP.WideIPPoolSequenceSequence')
    poolseq = client.factory.create('GlobalLB.WideIP.WideIPPoolSequence')
    pool = client.factory.create('GlobalLB.WideIP.WideIPPool')
    pool.pool_name = pool_name
    pool.order = 0
    pool.ratio = 0
    poolseq.wideip_pools = [pool]
    poolseqseq.wideip_pools = [poolseq]

    return client.service.remove_wideip_pool(wide_ips = [wide_ip] , wideip_pools = poolseqseq)

# remove_wideip_pool(Common.StringSequence wide_ips, GlobalLB.WideIP.WideIPPoolSequenceSequence wideip_pools, )

@servicelogger
def get_lb_method_type( bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    lb = client.factory.create('GlobalLB.LBMethod')
    return lb

@servicelogger
def get_lb_method(wide_ip , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.get_lb_method(wide_ips = [wide_ip])

def set_lb_method(wide_ip, lb_em , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    lbseq = client.factory.create('GlobalLB.LBMethodSequence')
    lbseq.lb_methods = [lb_em]
    return client.service.set_lb_method(wide_ips = [wide_ip] , lb_methods = lbseq)

@servicelogger
def get_description(wide_ip , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.get_description(wide_ips = [wide_ip])

@servicelogger
def get_enabled_state(wide_ip , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.get_enabled_state(wide_ips = [wide_ip])

@servicelogger
def get_persistence_state(wide_ip , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.get_persistence_state(wide_ips = [wide_ip])

@servicelogger
def get_persistence_ttl(wide_ip ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.get_persistence_ttl(wide_ips = [wide_ip])

@servicelogger
def set_description(wide_ip ,description,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.set_description(wide_ips = [wide_ip] , descriptions = [description])

@servicelogger
def get_enabled_state_type(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_wideipclient(bigip=bigip)
    enablestat = client.factory.create('Common.EnabledState')
    return enablestat

@servicelogger
def set_enabled_state(wide_ip ,enabled_state_em ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    enablestatseq = client.factory.create('Common.EnabledStateSequence')

    enablestatseq.states = [enabled_state_em]
    return client.service.set_enabled_state(wide_ips = [wide_ip], states = enablestatseq)

@servicelogger
def set_persistence_state(wide_ip ,enabled_state_em , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    enablestatseq = client.factory.create('Common.EnabledStateSequence')

    enablestatseq.states = [enabled_state_em]
    return client.service.set_persistence_state(wide_ips = [wide_ip], states = enablestatseq)

@servicelogger
def set_persistence_ttl(wide_ip ,timeout , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.set_persistence_ttl(wide_ips = [wide_ip] , values = [timeout])

@servicelogger
def get_last_resort_pool(wide_ip ,  bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.get_last_resort_pool(wide_ips = [wide_ip])

@servicelogger
def set_last_resort_pool(wide_ip , pool_name, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_wideipclient(bigip=bigip)
    return client.service.set_last_resort_pool(wide_ips = [wide_ip] , pool_names = [pool_name])

@servicelogger
def delete_wideip(wide_ip , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_wideipclient(bigip=bigip)
    client.service.delete_wideip(wide_ips = [wide_ip])

# def create_add_pool(wide_ip , pool_name,  hostname='172.16.115.1'):
#
#     with clientFactory.Transaction(hostname):
#         create_wideip(wide_ip = wide_ip , hostname= hostname)
#         raise
#         add_wideip_pool(wide_ip = wide_ip, pool_name = pool_name , pool_porder = 0, pool_ratio = 3, bigip=bigip)
#
#


# create("twip", [{'name','',order:'','ratio',''}],bigip)
@clientFactory.bigsuds_transaction
def create(wide_ip_name, pool_dict_list = None , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    create_wideip(wide_ip_name, bigip)

    if pool_dict_list:
        for  pool_dict in pool_dict_list:
            pool_name = pool_dict.get('name')
            pool_order =  pool_dict.get('order')
            pool_ratio = pool_dict.get('ratio')
            add_wideip_pool(wide_ip_name, pool_name , pool_order, pool_ratio, bigip)
