#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/4/7

from lugtm.settings import UNDER_LINE
from lugtm.management.platform.service.base_data import Region_Other
from lugtm.management.platform.service.topology_db_service import get_topology_summary_dict_load
from lugtm.management.platform.service.base_data import get_region_cn_name,get_datacenter_cn_name,\
    get_idc_models,get_province_models,get_province_models_all
import copy
import logging
from collections import OrderedDict
from lugtm.init_service.region_info import PROVINCE_FLAG,get_province_flag,TOPOLOGY_CONFIG
import sys
reload(sys)
sys.setdefaultencoding('utf8')

logger = logging.getLogger("lugtm.views")

YGQ = u'WGQ'

# --------------------------------------------------------------------------
##
# @synopsis  move_ordered_dict_element
#
# @param odict: OrderedDict
# @param thekey
# @param newpos
#
# @returns
# ----------------------------------------------------------------------------
def move_ordered_dict_element(odict, thekey, newpos):
    odict[thekey] = odict.pop(thekey)
    i = 0
    for key, value in odict.items():
        if key != thekey and i >= newpos:
            odict[key] = odict.pop(key)
        i += 1
    return odict

# --------------------------------------------------------------------------
##
# @synopsis  get_first_ordered_dict_key
#
# @param odict
#
# @returns  just the key string
# ----------------------------------------------------------------------------
def get_first_ordered_dict_key(odict):
	return next(iter(odict))

def get_province_regions(topology_summary_dict,province_models):
    '''
    从所有策略里获取对应省份有关的region 信息
    :param topology_summary_dict: 所有策略dict
    :param province_models: 所有省份model
    :return:
    '''
    result = OrderedDict()
    ##{"省份":[region_name1,region_name2],"":[]}
    for k, v in topology_summary_dict.iteritems():
        for p in province_models:
            if p.code in k:
                if p.name in result.keys():
                    result.get(p.name).append(k)
                else:
                    regions = list()
                    regions.append(k)
                    result[p.name] = regions
    return result


def get_des_order_dc_v2(target_zone, result_dcs,source_idc,des_idc):
    '''
    NOte: this just deal with non-Other province  case
	target_zone: LIKE CN_Fujian_CTC
    根据idc 排定对应result_dcs的最新顺序
    :param result_dcs: 按weight降序的topology [{'dc_name': SH_YP_CTC, 'weight': 3090L,"order":355}, {'dc_name': /Common/SH_YP_CNC, 'weight': 3085L,"order":356}]
    :param source_idc: idc Model
    :param des_idc: idc Model
    :return:
    '''
    logger.info('-------get_des_order_dc_v2 result_dcs is %s, source_idc %s des_idc is %s'%(result_dcs, source_idc, des_idc))
    all_result = list()
    change_result = list()
    new_datas = copy.deepcopy(result_dcs)
    province_name = target_zone.split(UNDER_LINE)[1]
    if 'ShanXi' in target_zone:
        operator_name = target_zone.split(UNDER_LINE)[3]
    else:
        operator_name = target_zone.split(UNDER_LINE)[2]

    # idc_location_name = target_zone.split(UNDER_LINE)[1]
    # base_topo_type = get_province_flag(province_name)
    source_idc_code_name = source_idc.code.upper()
    dest_idc_code_name = des_idc.code.upper()
    topo_mode_source = 0
    topo_mode_dest = 0


    # TOPOLOGY_CITY_BASE_CONFIG_DICT = {"SH": 0, 'LF':2}
    # TOPOLOGY_IDC_BASE_CONFIG_DICT = {"SH_WGQ": 0, "WGQ_WGQ": 0,'SH_BX':1}

    if source_idc_code_name == 'CUCC':
        if result_dcs[2].get('dc_name').startswith('SH_BX'):
            topo_mode_source = 3
        else:
            topo_mode_source = 2
        if dest_idc_code_name == 'BX':
            topo_mode_dest = 1
        elif dest_idc_code_name == 'WGQ':
            topo_mode_dest = 0
    else:
        if source_idc_code_name == 'BX':
            topo_mode_source = 1
            topo_mode_dest = 3
        elif source_idc_code_name == 'WGQ':
            topo_mode_source = 0
            topo_mode_dest = 2
    #TBD: Only support BX--GUCC
    # all_result eaquals update_result
    logger.info("topo_mode_dest:{0},operator_name:{1},province_name:{2},target_zone:{3}".format(topo_mode_dest,operator_name,province_name,target_zone))
    new_dc_name_list = TOPOLOGY_CONFIG[topo_mode_dest][operator_name]
    logger.info('-------get_des_order_dc_v2 topo_mode_dest is %s, topo_mode_source %s, new_dc_name_list is %s'%(topo_mode_dest, topo_mode_source, new_dc_name_list))

    # just adjust the dc_name , order and weight will be the same
    # if dest_idc_code_name == 'CUCC':
    #     for i in range(len(new_datas)):
    #         new_datas[i]["dc_name"] = new_dc_name_list[i]
    #         all_result.append(new_datas[i])
    #     # for i in range(len(new_datas)):
    #     #     if dest_idc_code_name in new_datas[i]["dc_name"]:
    #     #         all_result.append(new_datas[i])
    # else:
    #     for i in range(len(new_datas)):
    #         #new_datas[i]["dc_name"] = new_dc_name_list[i]
    #         all_result.append(new_datas[i])
    for i in range(len(new_datas)):
        new_datas[i]["dc_name"] = new_dc_name_list[i]
        all_result.append(new_datas[i])
    change_result = all_result
    ################################OLD version#################################
    # def is_glt_one(op_code):
        # nn = 0
        # first_idc = None
        # for d in result_dcs:
            # dc_name = d["dc_name"]
            # if dc_name.endswith(op_code):
                # nn = nn + 1
                # dc_list = dc_name.split(UNDER_LINE)
                # if not first_idc:
                    # first_idc = dc_list[1]
        # if nn>1:
            # return True,first_idc
        # else:
            # return False,first_idc

    # for i in range(len(new_datas)):
        # dc = new_datas[i]["dc_name"]
        # dc_list = dc.split(UNDER_LINE)
        # idc_code = dc_list[1]
        # operator_code = dc_list[2]
        # is_gltone, now_idc = is_glt_one(operator_code)
        # if now_idc in des_idc.code.upper():
            # all_result.append(new_datas[i])
            # continue
        # if is_gltone and idc_code == source_idc.code:
            # new_dc_name = dc.replace(idc_code,des_idc.code)
            # new_datas[i]["dc_name"] = new_dc_name
            # change_result.append(new_datas[i])
        # elif is_gltone and idc_code == des_idc.code:
            # new_dc_name = dc.replace(idc_code,source_idc.code)
            # new_datas[i]["dc_name"] = new_dc_name
            # change_result.append(new_datas[i])
        # all_result.append(new_datas[i])
    ################################OLD version#################################
    return all_result,change_result


def get_operator_index(region_dcs):
    result = OrderedDict()
    is_exp = False
    for i in range(len(region_dcs)):
        dc = region_dcs[i]["dc_name"]
        dc_list = dc.split(UNDER_LINE)
        # idc_code = dc_list[1]
        city_name = dc_list[0]
        logger.info('@@@get_operator_index city_name is %s'%(city_name))
        if city_name == 'SH':
            operator_code = dc_list[2]
            if operator_code in result.keys():
                 result[operator_code]["end"] = i
            else:
                i_indx = OrderedDict()
                i_indx["start"] = i
                i_indx["end"] = i
                result[operator_code] = i_indx
        else:
            if i == 0:
                logger.info('@@@MIAO get_operator_index city_name is %s'%(city_name))
                is_exp = True

    if is_exp:
        logger.info('@@@MIAO result is %s'%(result))

    return result


def get_des_order_dc_v1(result_dcs,source_idc,des_idc):
    '''
    根据idc 排定对应result_dcs的最新顺序
    :param result_dcs: 按weight降序的topology [{'dc_name': /Common/SH_YP_CTC, 'weight': 3090L,"order":355}, {'dc_name': /Common/SH_YP_CNC, 'weight': 3085L,"order":356}]
    :param source_idc: idc Model
    :param des_idc: idc Model
    :return:
    '''
    import copy
    all_result = copy.deepcopy(result_dcs)
    change_result = [None for i in range(len(result_dcs))]
    update_result = list()

    result_indexs = get_operator_index(result_dcs)

    logger.info('@@@NEW_IDC_CHANGE result_indexs is %s'%(result_indexs))
    for op,in_v in result_indexs.iteritems():
        s = in_v["start"]
        e = in_v["end"]
        if s == e:
            dc = result_dcs[s]["dc_name"]
            change_result[s] = dc
        else:
            e = s+1
            if des_idc.code.upper() == YGQ:
                dcn = result_dcs[e]["dc_name"]
                dcs = result_dcs[s]["dc_name"]
                if des_idc.code.upper() in dcs:
                    continue
                change_result[s]=dcn
                for i in range(s,e):
                    dcn = result_dcs[i]["dc_name"]
                    change_result[i+1]=dcn
            elif source_idc.code.upper() == YGQ:
                u"""
                wgq > bx 
                source wgq
                dcn sh bx ctc
                des_idc bx
                """
                dcn = result_dcs[s]["dc_name"]
                if des_idc.code.upper() in dcn:
                    continue
                change_result[e] = dcn
                for i in range(s+1,e+1):
                    dcn = result_dcs[i]["dc_name"]
                    change_result[i-1] = dcn
    for j in range(len(all_result)):
        dc1 = all_result[j]["dc_name"]
        dc2 = change_result[j]
        if dc2 is None or dc1 == dc2:
            continue
        all_result[j]["dc_name"] = dc2
        update_result.append(all_result[j])
        #
        #     change_result.append(result_dcs[i])
        # all_result.append(result_dcs[i])
    if update_result:
        logger.info('\n\n\n@@@V1   all_resultis %s, \nupdate_result is %s\n\n\n'%(all_result, update_result))
        return all_result,update_result
    return [],[]

def get_des_order_dc_sg(result_dcs,source_idc,des_idc):
    '''
    根据idc 排定对应result_dcs的最新顺序
    :param result_dcs: 按weight降序的topology [{'dc_name': /Common/SH_YP_CTC, 'weight': 3090L,"order":355}, {'dc_name': /Common/SH_YP_CNC, 'weight': 3085L,"order":356}]
    :param source_idc: idc Model
    :param des_idc: idc Model
    :return:
    '''
    import copy
    update_result = copy.deepcopy(result_dcs)
    if update_result :
        if des_idc.code in update_result[0]['dc_name']:
            return [], []
        if 'SG' in update_result[0]['dc_name'] and des_idc.code == 'XJP':
            return [], []
        if des_idc.code == 'XJP':
            s_stored = sorted(update_result,key=lambda update_result:update_result['weight'])
            update_result =s_stored
        llen = len(update_result)
        for i in xrange(2):
            for x in xrange(llen):
                if (llen-1) == x:
                    pass
                else:
                    temp = update_result[x]['dc_name']
                    update_result[x]['dc_name'] = update_result[x+1]['dc_name']
                    update_result[x+1]['dc_name'] = temp
        if update_result:
            s_stored = sorted(update_result,key=lambda update_result:update_result['weight'],reverse=True)
            update_result =s_stored
            return update_result,update_result
    return [],[]

###新规则下的切换
def get_province_change_topology_info_new(source_idc,des_idc,p_obs):
    '''
    获取变化的映射信息，以及要改变的region及dc策略
    :param source_idc:
    :param des_idc:
    :param p_obs: 省份model;[p1,p2]
    :return: changed_info,new_records,old_records
    '''
    result_info = OrderedDict()
    old_records = OrderedDict()
    des_change_records = OrderedDict()
    des_full_records = OrderedDict()
    is_ygq = 0#1:ygq 2:新加坡 0:其他
    if source_idc.code.upper() == YGQ or des_idc.code.upper() == YGQ:
        is_ygq = 1
    elif source_idc.code.upper() == 'XJP' or des_idc.code.upper() == 'XJP' :
        is_ygq = 2
    #elif source_idc.code.upper() == 'GUCC' or des_idc.code.upper() == 'GUCC' :
    #    is_ygq = 3
    tp_dict = get_topology_summary_dict_load()#所有区域的province
    logger.info('@@@NEW_IDC_CHANGE tp_dict is %s'%(tp_dict))
    info = get_province_regions(tp_dict,p_obs)
    logger.info("p_obsp_obs:"+ p_obs[0].code) #XinJiang
    logger.info("infoinfo:" + str(info))
    for k1, v1 in info.iteritems():
        data_list = list()
        des_records = OrderedDict()
        old_record = OrderedDict()
        full_records = OrderedDict()
        for r in v1:
            r_list = list()
            r_n1, r_n2 = get_region_cn_name(r)
            logger.info("info iteritems,k1:{0},r:{1},r_n1:{2},r_n2:{3}".format(k1,r,r_n1,r_n2))
            r_list.append(r_n1+r_n2)
            dcs = tp_dict.get(r, None)
            if dcs:
                s_idc = dcs[0].get("dc_name")
                dc_1, dc_2 = get_datacenter_cn_name(s_idc)
                logger.info("dcsdcs"+dc_1+dc_2)
                r_list.append(dc_1+dc_2)
            dcs = tp_dict.get(r)
            if is_ygq == 1:
                ds_full_order,change_order = get_des_order_dc_v1(dcs,source_idc,des_idc)
            elif is_ygq == 2 :
                if des_idc.code == YGQ :
                    dcs, change_orderr = get_des_order_dc_v1(dcs, source_idc, des_idc)
                if source_idc.code == YGQ:
                    des_id = get_idc_models(u'宝信')
                    dcs, change_orderr = get_des_order_dc_v1(dcs, source_idc, des_id)
                ds_full_order, change_order = get_des_order_dc_sg(dcs, source_idc, des_idc)
            else:
                logger.info("is_ygq333")
                logger.info("dcs" + str(dcs))
                logger.info("source_idc"+ str(source_idc.code))
                logger.info("des_idc"+str(des_idc.code))
                logger.info("rrrrr"+str(r))
                ds_full_order,change_order = get_des_order_dc_v2(r, dcs,source_idc,des_idc)
                logger.info(change_order)
                logger.info("change_orderchange_order")
            if ds_full_order:
                d_idc = ds_full_order[0].get("dc_name")
                dc_1,dc_2 = get_datacenter_cn_name(d_idc)
                logger.info("ds_full_orderds_full_order"+ d_idc+ dc_1+dc_2)
                r_list.append(dc_1+dc_2)
            old_record[r] = dcs
            des_records[r] = change_order
            full_records[r] = ds_full_order
            data_list.append(r_list)
        result_info[k1] = data_list
        des_change_records[k1] = des_records
        old_records[k1] = old_record
        des_full_records[k1] = full_records
    logger.info("result_inforesult_info:" + str(result_info))
    return result_info,des_change_records,old_records,des_full_records


def get_changed_info(source_idc,des_idc,provinces):
    '''
    :param source_idc:
    :param des_idc:
    :param provinces: 省份中文名1,省份中文名2
    :return:
    '''
    s_idc = get_idc_models(source_idc)
    d_idc = get_idc_models(des_idc)

    if Region_Other in provinces:  ###处理全局备策略 Other
        return get_changed_other(s_idc, d_idc, Region_Other)
    province_list = get_province_models(provinces)
    logger.info("SpecialFlow: s_idc is %s, d_idc %s, province_list: %s "%(s_idc, d_idc, province_list))
    if s_idc and d_idc and province_list:
        change_info,des_change_records,old_records,des_full_records = \
            get_province_change_topology_info_new(s_idc,d_idc,province_list)
        return change_info,des_change_records,old_records,des_full_records

    return None,None,None,None

def get_changed_info_all(source_idc,des_idc,a_other,province_list):
    '''
    :param source_idc:
    :param des_idc:
    :param provinces: 省份中文名1,省份中文名2
    :return:
    '''
    s_idc = get_idc_models(source_idc)
    d_idc = get_idc_models(des_idc)
    global otherall_change_info,otherall_des_change_records,otherall_old_records,\
        otherall_des_full_records
    if a_other:  ###处理全局备策略 Other
        otherall_change_info, otherall_des_change_records, otherall_old_records, \
        otherall_des_full_records = get_changed_other(s_idc, d_idc, Region_Other)
    if s_idc and d_idc and province_list:
        change_info,des_change_records,old_records,des_full_records = \
            get_province_change_topology_info_new(s_idc,d_idc,province_list)
        if a_other and  otherall_change_info and otherall_des_change_records:
            change_info['Other'] = otherall_change_info['Other']
            des_change_records['Other'] = otherall_des_change_records['Other']
            old_records['Other'] = otherall_old_records['Other']
            des_full_records['Other'] = otherall_des_full_records['Other']
        return change_info,des_change_records,old_records,des_full_records

    return None,None,None,None


def get_changed_other(source_idc,des_idc,region_other):
    '''
       全局备策略Other的处理
    :param source_idc:
    :param des_idc:
    :param region_other:
    :return:
    '''
    result_info = OrderedDict()
    old_records = OrderedDict()
    des_change_records = OrderedDict()
    des_full_records = OrderedDict()
    is_ygq = 0
    if source_idc.code.upper() == YGQ or des_idc.code.upper() == YGQ:
        is_ygq = 1
    tp_dict = get_topology_summary_dict_load()
    infos = tp_dict.get(region_other,None)
    if not infos:
        return None,None,None,None
    data_list = list()
    des_records = OrderedDict()
    old_record = OrderedDict()
    full_records = OrderedDict()

    r_list = list()
    r_list.append(region_other)

    full_other_old = copy.deepcopy(infos)
    for t in infos:
        dc_code = t.get("dc_name",'')
        if not dc_code.startswith("SH"):
            full_other_old.remove(t)

    dc_1,dc_2 = get_datacenter_cn_name(full_other_old[0].get("dc_name"))
    r_list.append(dc_1+dc_2)

    #Autually infos should be full_other_old
    infos = full_other_old
    if is_ygq == 1:
        ds_full_order, change_order = get_des_order_dc_v1(infos,source_idc,des_idc)
    elif is_ygq == 2:
        ds_full_order, change_order = get_des_order_dc_sg(infos, source_idc, des_idc)
    else:
        ds_full_order, change_order = get_des_order_dc_v2(region_other, infos,source_idc,des_idc)
    full_other = copy.deepcopy(ds_full_order)
    for t in ds_full_order:
        dc_code = t.get("dc_name",'')
        if not dc_code.startswith("SH"):
            full_other.remove(t)
    if full_other:
        dc_1,dc_2 = get_datacenter_cn_name(full_other[0].get("dc_name"))
        r_list.append(dc_1+dc_2)

    old_record[region_other] = infos
    des_records[region_other] = change_order
    full_records[region_other] = full_other
    data_list.append(r_list)

    result_info[region_other] = data_list
    des_change_records[region_other] = des_records
    old_records[region_other] = old_record
    des_full_records[region_other] = full_records
    return result_info,des_change_records,old_records,des_full_records





