#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/5

# from lugtm.tools.ffivemanagement import f5mgmt
#
# def get_all_server():
#
#     servers = f5mgmt.tm.gtm.servers.get_collection()
#     return [ server.to_dict() for server in servers]
#
# def get_server_by_name(name , partition='Common'):
#     server = f5mgmt.tm.gtm.servers.server.load(name=name, partition=partition)
#     return server
#
# def delete_server_by_name(name, partition='Common'):
#     server = get_server_by_name(name, partition)
#     server.delete()
#
# #"monitor":"/Common/http and /Common/custom_http_web "
# def create_server(name,addresses,datacenter):
#
#     f5mgmt.tm.gtm.servers.server.create(name= name , datacenter = datacenter , addresses = addresses)
#
# if __name__ == '__main__':
#     pass

import  lugtm.base_sys.client_factory as clientFactory
from .virtualserver import get_all_virtualserver , create as vs_create
from lugtm.tools.logger import servicelogger
from lugtm.settings import BIGIP_ADDRESS




@servicelogger
def get_all_server(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)

    return client.service.get_list()

@servicelogger
def get_all_virtual_server_by_servername(servername , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    virtul_list = get_all_virtualserver(bigip = bigip)
#     print virtul_list
    return [vs for vs in virtul_list if vs.server == servername]

@servicelogger
def delete_server(servername, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    commonseq = client.factory.create('Common.StringSequence')
    commonseq.servers = [servername]
    return client.service.delete_server(commonseq)

# type_list = ['SERVER_TYPE_BIGIP_STANDALONE', 'SERVER_TYPE_BIGIP_REDUNDANT','SERVER_TYPE_GENERIC_LOAD_BALANCER',
#              'SERVER_TYPE_ALTEON_ACE_DIRECTOR','SERVER_TYPE_CISCO_CSS','SERVER_TYPE_CISCO_LOCAL_DIRECTOR_V2',
#              'SERVER_TYPE_CISCO_LOCAL_DIRECTOR_V3','SERVER_TYPE_CISCO_SERVER_LOAD_BALANCER','SERVER_TYPE_EXTREME',
#              'SERVER_TYPE_FOUNDRY_SERVER_IRON','SERVER_TYPE_GENERIC_HOST','SERVER_TYPE_CACHEFLOW','SERVER_TYPE_NETAPP',
#              'SERVER_TYPE_WINDOWS_2000','SERVER_TYPE_NT4','SERVER_TYPE_SOLARIS','SERVER_TYPE_RADWARE'
#
#               ]

@servicelogger
def serveripsequencesequence(ip_list , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    ipsequencesequence = client.factory.create('GlobalLB.Server.ServerIPsSequenceSequence')
#
#     ipsequence = client.factory.create('GlobalLB.Server.ServerIPsSequence')
#
#     ips = client.factory.create('GlobalLB.Server.ServerIPs')
#
#     commonipseq = client.factory.create('Common.IPAddressSequence')
#     commonipseq.addresses = ip_list
#
# #     ips.device = "test"
#     ips.addresses_on_device = commonipseq
#     ipsequence.ips = ips
#     ipsequencesequence.ips = ipsequence

    ipsequencesequence.ips = serveripsequence(ip_list,bigip)

    return ipsequencesequence

@servicelogger
def serveripsequence(ip_list, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    ipsequence = client.factory.create('GlobalLB.Server.ServerIPsSequence')

    ips = client.factory.create('GlobalLB.Server.ServerIPs')

    commonipseq = client.factory.create('Common.IPAddressSequence')
    commonipseq.addresses = ip_list

    ips.device = "test"
    ips.addresses_on_device = commonipseq
    ipsequence.ips = ips
    return ipsequence

@servicelogger
def get_limit(virtual_servername_list, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.get_limit(servers = virtual_servername_list)

@servicelogger
def get_server_type(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    servertype =  client.factory.create('GlobalLB.ServerType')
    return servertype

@servicelogger
def get_description(servername_list , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.get_description(servers=servername_list)

@servicelogger
def set_description(servername, description , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.set_description(servers=[servername], descriptions = [description])

@servicelogger
def get_object_status(servername_list ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.get_object_status(servers=servername_list)

@servicelogger
def get_enabled_state(servername_list, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.get_enabled_state(servers=servername_list)

# STATE_DISABLED , STATE_ENABLED
@servicelogger
def get_common_state_type(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    return client.factory.create('Common.EnabledState')

@servicelogger
def set_enabled_state(server_name , common_state_type_em ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    stateseq = client.factory.create('Common.EnabledStateSequence')
    stateseq.states = [common_state_type_em ]
    return client.service.set_enabled_state(servers=server_name , states = stateseq)

@servicelogger
def get_prober_pool(servername_list , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.get_prober_pool(servers=servername_list)


@servicelogger
def set_prober_pool(servername_list , pool_list, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.set_prober_pool(servers=servername_list , pools = pool_list)

@servicelogger
def get_statistics(servername_list ,bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.get_statistics(server_names=servername_list)

@servicelogger
def get_prober_address(servername_list , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):


    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.get_prober_address(servers=servername_list)


#address_dict : {"name":""}
@servicelogger
def set_prober_address(servername_name,address_dict , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS) ):


    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.set_prober_address(servers=[servername_name] ,addresses = address_dict)

@servicelogger
def get_data_center(servername_list , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.get_data_center(servers=servername_list)

@servicelogger
def set_data_center(servername , datacenter , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.set_data_center(servers=[servername], data_centers = [datacenter])

@servicelogger
def get_ip_v2(servername_list , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.get_ip_v2(servers=servername_list)

@servicelogger
def create_v2(servername , ip_list ,servertype_enum , datacenter, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    type = get_server_type()
    SS.create_v2(servername = "testfei", ip = "4.4.4.4", servertype_enum = type.SERVER_TYPE_BIGIP_STANDALONE,
                datacenters="SH_YP_CTC", hostname='172.16.115.1')

    '''
    client = clientFactory.get_serverclient(bigip=bigip)
    typeseq = client.factory.create('GlobalLB.ServerTypeSequence')
    typeseq.types = servertype_enum
    datacenterseq = client.factory.create('Common.StringSequence')
    datacenterseq.datacenters = [datacenter]
    servereq = client.factory.create('Common.StringSequence')
    servereq.servers = [servername]

    ipsequencesequence  = serveripsequencesequence(ip_list)
    return client.service.create_v2(servereq,ipsequencesequence,typeseq,datacenterseq)


@servicelogger
def get_monitor_association(servername, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_serverclient(bigip=bigip)
    servereq = client.factory.create('Common.StringSequence')
    servereq.servers = [servername]
    return client.service.get_monitor_association(servereq)

@servicelogger
def get_monitor_type(bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_serverclient(bigip=bigip)
    monitortype = client.factory.create('GlobalLB.MonitorRuleType')
    return monitortype

@servicelogger
def set_monitor_association(servername, monitortype_em , monitor_templates_list , quorum = 0 , bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    '''
    montitortype.MONITOR_RULE_TYPE_SINGLE  can only set one
    montitortype.MONITOR_RULE_TYPE_AND_LIST can set list
    @param monitor_templates_list: ['/Common/bigip']

    '''

    client = clientFactory.get_serverclient(bigip=bigip)
    monitorassseq = client.factory.create('GlobalLB.Server.MonitorAssociationSequence')

    monitorass = client.factory.create('GlobalLB.Server.MonitorAssociation')
    monitorrule = client.factory.create('GlobalLB.MonitorRule')

    monitorrule.type = monitortype_em
    monitorrule.quorum = quorum
    monitorrule.monitor_templates = monitor_templates_list
    monitorass.server_name = servername
    monitorass.monitor_rule = monitorrule
    monitorassseq.monitor_associations = [monitorass]
    print monitorass
    return client.service.set_monitor_association(monitorassseq)



@servicelogger
def add_ip_v2(server, serveripsequencesequence, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.add_ip_v2(servers = [server] ,ips = serveripsequencesequence)

@servicelogger
def remove_ip_v2(server, serveripsequencesequence, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):
    client = clientFactory.get_serverclient(bigip=bigip)
    return client.service.remove_ip_v2(servers = [server] ,ips = serveripsequencesequence)





#===============================================================================
#create_server("web_x", "Generic Host", ["4.4.4.4","5.5.5.5"], "SH_YP_CTC", "xd", ["https"], [{"name":"web_x_v1", "ip":"3.4.5.6","port":"44"}], bigip)
#===============================================================================
@clientFactory.bigsuds_transaction
def create_server(servername , productname, address_list ,datacentername, propberpoolname , monitor_list , vs_dict_list = None, bigip = clientFactory.sbigip(hostname=BIGIP_ADDRESS)):

    create_v2(servername, address_list, productname, datacentername, bigip)

    set_data_center(servername , datacentername , bigip )

    set_prober_pool([servername] , [propberpoolname] ,bigip)

    montitortype = get_monitor_type()

    monitortype_em = montitortype.MONITOR_RULE_TYPE_AND_LIST

    set_monitor_association(servername, monitortype_em , monitor_list , quorum = 0 ,bigip = bigip)

    if vs_dict_list :

        for vs_dict in vs_dict_list:

            vs_name = vs_dict.get('name')
            vs_ip  =vs_dict.get('ip')
            vs_port = vs_dict.get('port')
            vs_create(vs_name , servername , vs_ip , vs_port , bigip)
