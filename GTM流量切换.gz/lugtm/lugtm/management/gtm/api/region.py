#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/5

import logging


from rest_framework.views import APIView
from rest_framework import status
from rest_framework import exceptions
from rest_framework.response import Response
from lugtm.tools.logger import wraptlogger
from lugtm.tools.base import try_catch


logger = logging.getLogger("lugtm.views")


class Regions(APIView):
    """API for region
    """
    @try_catch
    @wraptlogger
    def get(self, request, *args, **params):
        name = request.query_params.get("region_name", None)
        return Response([])

    @try_catch
    @wraptlogger
    def post(self, request, *args, **params):
        name = request.data.get("region_name", None)
        region_members = request.data.get("region_members",None)
        if name:
            member_list = []
            if region_members:
                member_list = region_members.split(',')
            return Response([])
        else:
            raise Response(status=status.HTTP_502_BAD_GATEWAY)

    @try_catch
    @wraptlogger
    def delete(self, request, *args, **params):
        name = params.get("region_name", None)
        if name:
            return Response([])
        else:
            exceptions.NotFound
