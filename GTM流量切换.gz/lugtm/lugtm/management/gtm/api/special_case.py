#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/9


import logging

from rest_framework.views import APIView
from rest_framework.response import Response
from lugtm.tools.logger import wraptlogger

logger = logging.getLogger("lugtm.views")


class ChangeServiceSpecial(APIView):
    """
    Special API for change province info
    ################特殊接口用于前台使用post方法替代get(带参数)###################
    """
    # @try_catch
    @wraptlogger
    def get(self, request, *args, **params):
        source_idc = request.query_params.get("source_idc", None)
        des_idc = request.query_params.get("destination_idc", None)
        provinces = request.query_params.get("provinces", None)
        result = dict()
        if source_idc and des_idc and provinces and source_idc != des_idc:
            from lugtm.management.gtm.service.change_service import get_changed_info
            result, des_change_records,old_records,des_full_records = get_changed_info(source_idc,des_idc,provinces)
        return Response(result)

     # @try_catch
    @wraptlogger
    def post(self, request, *args, **params):
        source_idc = request.data.get("source_idc", None)
        des_idc = request.data.get("destination_idc", None)
        provinces = request.data.get("provinces", None)
        result = dict()
        if source_idc and des_idc and provinces and source_idc != des_idc:
            from lugtm.management.gtm.service.change_service import get_changed_info
            result, des_change_records,old_records,des_full_records = get_changed_info(source_idc,des_idc,provinces)
        return Response(result)


class IdcScaleServiceSpecial(APIView):
    """API for idc scale
    ################特殊接口用于前台使用post方法替代get(带参数)###################
    """
    @wraptlogger
    def get(self, request, *args, **params):
        idc_name = request.query_params.get("idc_name", None)
        scale = request.query_params.get("scale", None)
        from lugtm.management.platform.service.base_data import get_idc_scale_data,get_idc_scale_province
        if idc_name and scale:
            return Response(get_idc_scale_province(idc_name,scale))
        else:
            return Response(get_idc_scale_data())

    @wraptlogger
    def post(self, request, *args, **params):
        idc_name = request.data.get("idc_name", None)
        scale = request.data.get("scale", None)
        from lugtm.management.platform.service.base_data import get_idc_scale_data,get_idc_scale_province
        if idc_name and scale:
            return Response(get_idc_scale_province(idc_name,scale))
        else:
            return Response(get_idc_scale_data())

