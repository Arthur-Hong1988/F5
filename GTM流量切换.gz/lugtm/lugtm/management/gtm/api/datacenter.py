#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/9


import logging


from rest_framework.views import APIView
from rest_framework import status
from rest_framework import exceptions
from rest_framework.response import Response
from lugtm.tools.logger import wraptlogger
from lugtm.tools.base import try_catch
from lugtm.settings import BIGIP_ADDRESS

from lugtm.management.gtm.service.datacenter import get_all_status_by_host

logger = logging.getLogger("lugtm.views")


class DataCenter(APIView):
    """API for datacenter 线路信息
    """
    @try_catch
    @wraptlogger
    def get(self, request, *args, **params):
        return Response(get_all_status_by_host(hostname=BIGIP_ADDRESS))



