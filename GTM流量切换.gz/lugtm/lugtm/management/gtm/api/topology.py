#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/9


import logging, time
import lugtm.base_sys.client_factory as clientFactory
from django.http import HttpResponse
import json
import requests

from rest_framework.views import APIView
from rest_framework import status
from rest_framework import exceptions
from rest_framework.response import Response
from lugtm.tools.logger import wraptlogger
from lugtm.tools.base import try_catch
from lugtm.management.platform.service.base_data import Region_Other, get_all_provinces_percentage, \
    query_all_provinces_percentage_order
from lugtm.management.platform.service.base_data import get_cmdbv3_table_dict

from lugtm.management.gtm.service.topology import process_topology_records, process_topology_records_all, \
    percent_change_service
from lugtm.management.gtm.service.topology import get_all_topology
from lugtm.init_service.region_info import PROVINCE_FLAG

logger = logging.getLogger("lugtm.views")

bigip = clientFactory.sbigip()


class TopologyByLib(APIView):
    """Docstring for TopologyByLib. """

    # @try_catch
    # @wraptlogger
    def get(self, request, *args, **params):
        return Response(get_all_topology())


class IDCSummary(APIView):
    """
    API for idc Summary status,用于获取机房总流量分布
    """

    # @try_catch
    # @wraptlogger
    def get(self, request, *args, **params):
        from lugtm.management.gtm.service.idc_service import get_idc_summary_local
        return Response(get_idc_summary_local())


class IDCProvince(APIView):
    """
    API for idc province status,no use
    """

    # @try_catch
    # @wraptlogger
    def get(self, request, *args, **params):
        idc_name = request.query_params.get("idc_name", None)
        from lugtm.management.gtm.service.idc_service import get_province_list
        return Response(get_province_list(idc_name=idc_name))


class ChangeServiceApi(APIView):
    """
    API for change province info
    """

    # @try_catch
    @wraptlogger
    def get(self, request, *args, **params):
        data = get_all_provinces_percentage()
        for i in xrange(len(data)):
            if data[i].has_key('to_idc'):
                if data[i].has_key('data_time'):
                    data[i]['data_time'] = str(data[i]['data_time'])
                if data[i]['to_idc'] == u'宝信':
                    data[i]['to_idc'] = 'BX'
                elif data[i]['to_idc'] == u'外高桥':
                    data[i]['to_idc'] = 'WGQ'
                else:
                    pass
        content = {
            'data': data,
            'message': 'success'
        }
        return HttpResponse(json.dumps(content), content_type='application/json')

    # @try_catch
    # @wraptlogger
    def post(self, request, *args, **params):
        try:

            print '@@@000 begin'
            canshu = {
                'BX': u"宝信",
                'LF': u"廊坊",
                'WGQ': u"外高桥"
            }
            source_idc = request.data.get("source_idc", None)
            des_idc = request.data.get("destination_idc", None)
            # provinces = request.data.get("provinces", None)
            from lugtm.management.platform.service.user_service import get_username
            username = get_username(request)
            content = dict()
            if source_idc and des_idc and source_idc != des_idc:
                source_idc = canshu[source_idc]
                des_idc = canshu[des_idc]
                from lugtm.management.platform.service.base_data import get_province_models_all
                from lugtm.management.gtm.service.change_service import get_changed_info_all
                p_models, a_other = get_province_models_all(source_idc)
                logger.info('@@@111%s, %s' % (p_models, a_other))
                result, records, old_records, des_full_records = get_changed_info_all(source_idc, des_idc, a_other,
                                                                                      p_models)
                logger.info('@@@IDC_CHANGE222 %s\n\n, %s\n\n, %s\n\n, %s\n\n' % (
                result, records, old_records, des_full_records))
                # print '@@@222%s, %s'%(result, records)
                # is_process = False
                all_province = []
                is_process = False
                if records:
                    for p_name, tp in records.iteritems():
                        all_province.append(tp)
                    is_process = process_topology_records_all(all_province)
                    print '@@@333%s' % is_process
                else:
                    content['data'] = 'flase'
                    content['message'] = 'all areas are in the destination machine room'
                    # logger.info("Process records end[%s][%s]" % (username, p_name))
                if is_process:
                    # time.sleep(10)
                    from lugtm.management.platform.service.topology_db_service import \
                        get_now_province_topology_info_all, \
                        update_gtm_topology_changed_to_db
                    print '@@@444  before get_now'
                    now_records = get_now_province_topology_info_all(p_models, a_other)
                    logger.info("Now records end[%s]" % str(now_records))
                    if now_records:
                        logger.info("Update changed topology info:%s" % str(now_records.keys()))
                        update_gtm_topology_changed_to_db(now_records)
                        logger.info("Update end.")
                        # for k,v in des_full_records.iteritems():
                        #     data = dict()
                        #     for r,dcs in v.iteritems():
                        #         now_dcs = now_records[k][r]
                        #         from lugtm.management.platform.service.base_data import get_datacenter_cn_name,get_region_cn_name
                        #         region_cn1,region_cn2 = get_region_cn_name(r)
                        #         now_cn1,now_cn2 = get_datacenter_cn_name(now_dcs[0]["dc_name"])
                        #         destination_cn1,destination_cn2 = get_datacenter_cn_name(dcs[0]["dc_name"])
                        #         data[region_cn1+region_cn2]={"now":now_cn1+now_cn2,"destination":destination_cn1+destination_cn2}
                        #     result1[k] = data
                        content['data'] = 'true'
                        content['message'] = 'success'
                    else:
                        content['data'] = 'flase'
                        content['message'] = 'failed'

            return HttpResponse(json.dumps(content), content_type='application/json')
        except Exception as e:
            logger.exception('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA: %s' % str(e))
            print('BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB: %s' % str(e))


class ChangeService(APIView):
    """
    API for change province info
    """

    # @try_catch
    @wraptlogger
    def get(self, request, *args, **params):
        source_idc = request.query_params.get("source_idc", None)
        des_idc = request.query_params.get("destination_idc", None)
        provinces = request.query_params.get("provinces", None)
        result = dict()
        if source_idc and des_idc and provinces and source_idc != des_idc:
            from lugtm.management.gtm.service.change_service import get_changed_info
            result, des_change_records, old_records, des_full_records = get_changed_info(source_idc, des_idc, provinces)
        return Response(result)

    # @try_catch
    @wraptlogger
    def post(self, request, *args, **params):
        source_idc = request.data.get("source_idc", None)
        des_idc = request.data.get("destination_idc", None)
        provinces = request.data.get("provinces", None)
        from lugtm.management.platform.service.user_service import get_username
        username = get_username(request)
        result1 = dict()
        logger.info("source_idc %s %s %s" % (source_idc, des_idc, provinces))
        if source_idc and des_idc and provinces and source_idc != des_idc:
            from lugtm.management.platform.service.base_data import get_province_models
            from lugtm.management.gtm.service.change_service import get_changed_info
            p_models = get_province_models(provinces)
            result, records, old_records, des_full_records = get_changed_info(source_idc, des_idc, provinces)
            logger.info("Change info[%s]: %s" % (username, str(result)))
            logger.info("Old records info[%s]: %s" % (username, str(old_records)))
            logger.info("New records info[%s]: %s" % (username, str(records)))
            is_process = False
            for p_name, tp in records.iteritems():
                if not tp:
                    continue
                logger.info("Start update records[%s][%s]" % (username, p_name))
                is_process = process_topology_records(tp)
                logger.info("Process records end[%s][%s]" % (username, p_name))
            if is_process:
                # time.sleep(10)
                from lugtm.management.platform.service.topology_db_service import get_now_province_topology_info, \
                    update_gtm_topology_changed_to_db
                now_records = get_now_province_topology_info(p_models, Region_Other in provinces)
                logger.info("Now records end[%s]" % str(now_records))
                if now_records:
                    logger.info("Update changed topology info:%s" % str(now_records.keys()))
                    update_gtm_topology_changed_to_db(now_records)
                    logger.info("Update end.")
                    for k, v in des_full_records.iteritems():
                        data = dict()
                        for r, dcs in v.iteritems():
                            now_dcs = now_records[k][r]
                            from lugtm.management.platform.service.base_data import get_datacenter_cn_name, \
                                get_region_cn_name
                            region_cn1, region_cn2 = get_region_cn_name(r)
                            ###这个逻辑
                            now_cn1, now_cn2 = get_datacenter_cn_name(now_dcs[0]["dc_name"])
                            destination_cn1, destination_cn2 = get_datacenter_cn_name(dcs[0]["dc_name"])
                            data[region_cn1 + region_cn2] = {"now": now_cn1 + now_cn2,
                                                             "destination": destination_cn1 + destination_cn2}
                        result1[k] = data
        return Response(result1)


class SpecialFlow(APIView):
    """
    API for change province info
    """

    # @try_catch
    @wraptlogger
    def post(self, request, *args, **params):
        direction = request.data.get("direction", None)
        # source_idc = request.data.get("source_idc", None)
        # des_idc = request.data.get("destination_idc", None)
        source_idc = ''
        des_idc = ''
        if direction == 'in':
            source_idc = u'宝信'
            destination_idc = u'廊坊'
        elif direction == 'out':
            source_idc = u'廊坊'
            destination_idc = u'宝信'
        else:
            return Response('direction error: %s!' % direction, status=500)

        raw_idc_list = get_cmdbv3_table_dict('idc', ['name', 'full_name', 'idc_status', 'province_list'], name='LF')
        logger.info('SpecialFlow: CMDBv3 idc data: %s' % raw_idc_list)
        idc_status = raw_idc_list[0].get('idc_status', '')
        if idc_status != 'normal' and direction == 'in':
            logger.info('SpecialFlow: idc status is not normal, Maybe in press status!')
            return Response('LF idc status is not normal, current status: %s!' % idc_status, status=500)
        else:
            provinces = raw_idc_list[0].get('province_list', [])
            # for province_item in raw_idc_list[0].get("province_list", "").split(','):
            #    if province_item in PROVINCE_FLAG.keys() and province_item not in provinces:
            #        provinces.append(province_item)

            logger.info('SpecialFlow: sourceidc %s, destination_idc: %s, provinces: %s' % (
            source_idc, destination_idc, provinces))

            try:
                all_status = True
                all_text = ''
                all_status_code = 200
                for province_item in provinces.split(','):
                    body = {"source_idc": source_idc, "destination_idc": destination_idc, "provinces": province_item}
                    res = requests.post(
                        "http://127.0.0.1:8888/api/mgm/gtm/changeservice/?token=d37a11c829a74af983f120eaf7b3a520", body)
                    logger.info('SpecialFlow: province %s, res: %s' % (province_item, res))
                    if res.status_code != 200:
                        all_status_code = res.status_code
                        all_text += '%s fail;' % province_item
                    else:
                        all_text += '%s ok;' % province_item

                return Response(all_text, status=all_status_code)
            except Exception as e:
                return Response(str(e), status=500)


class ChangePercentView(APIView):
    """
    API for change province info
    """

    @wraptlogger
    def get(self, request, *args, **params):
        """
        bx 60 wgq 40
        """
        result = dict()
        bx_target = int(request.query_params.get("bx", request.query_params.get("BX", None)))
        wgq_target = request.query_params.get("wgq", request.query_params.get("WGQ", None))
        bx_provinces = []
        wgq_provinces = []
        bx_current = 0
        wgq_current = 0
        for provinces_obj in query_all_provinces_percentage_order():
            if provinces_obj.province.name == "Other":
                wgq_current += provinces_obj.percentage
                continue
            if (bx_current+provinces_obj.percentage) * 100000 in range(bx_target * 1000 - 300, bx_target * 1000 + 300):
                bx_current += provinces_obj.percentage
                bx_provinces.append(provinces_obj.province.name)
                bx_target = 0
            if 0 <= (bx_current+provinces_obj.percentage) * 100000 < (int(bx_target) * 1000 - 300):
                bx_current += provinces_obj.percentage
                bx_provinces.append(provinces_obj.province.name)
            else:
                wgq_current += provinces_obj.percentage
                wgq_provinces.append(provinces_obj.province.name)
        from lugtm.management.platform.service.base_data import get_province_models_all
        wgq_cur_provinces_objs, wgq_other = get_province_models_all(u"外高桥")
        wgq_cur_provinces = [provinces_obj.name for provinces_obj in wgq_cur_provinces_objs]
        if wgq_other:
            wgq_cur_provinces.remove("Other")

        bx = list(filter(lambda x: x in wgq_cur_provinces, bx_provinces))

        wgq = list(filter(lambda x: x not in wgq_cur_provinces, wgq_provinces))

        result = {"bx": {"bx_target": bx_current, "provinces": bx_provinces, "wgq > bx": bx},
                  "wgq": {"wgq_target": wgq_current, "provinces": wgq_provinces, "bx > wgq": wgq},
                  "other": wgq_other, "wgq_cur_provinces": wgq_cur_provinces
                  }
        return Response(result)

    # @try_catch
    @wraptlogger
    def post(self, request, *args, **params):
        """
        curl -XPOST -H "Content-Type: application/json" -d '{"bx":50,"wgq":50}'
        """
        canshu = {
            'BX': u"宝信",
            'LF': u"廊坊",
            'WGQ': u"外高桥"
        }
        logger.info("SChangePercentView request data: %s " % request.data)
        bx_target = int(request.data.get("bx", request.data.get("BX", None)))
        wgq_target = int(request.data.get("wgq", request.data.get("WGQ", None)))
        if (bx_target + wgq_target) != 100:
            return Response({"message": "Percent ERROR"})
        bx_provinces = []
        wgq_provinces = []
        bx_current = 0
        wgq_current = 0
        logger.error("start check percent")
        if int(bx_target) == 50 and int(wgq_target) == 50:
            import traceback
            try:
                logger.error("change bx_target and  wgq_target 50%")
                # gtm临时把上海和other的流量切到宝信，针对宝信和外高桥各50%的策略
                for provinces_obj in query_all_provinces_percentage_order():
                    if provinces_obj.province.code in ("ShangHai", "Other"):
                        bx_current += provinces_obj.percentage
                        bx_provinces.append(provinces_obj.province.name)
                    else:
                        wgq_current += provinces_obj.percentage
                        wgq_provinces.append(provinces_obj.province.name)
                from lugtm.management.platform.service.base_data import get_province_models_all
                wgq_cur_provinces_objs, other = get_province_models_all(u"外高桥")
                wgq_cur_provinces = [provinces_obj.name for provinces_obj in wgq_cur_provinces_objs]
                bx, wgq = "", ""
                logger.error("wgq_cur_provinces:" + str(wgq_cur_provinces))
                logger.error("wgq_provinces:" + str(wgq_provinces))
                logger.error("bx_provinces:" + str(bx_provinces))
                if other:
                    wgq_cur_provinces.remove("Other")
                # wgq_to_bx = list(filter(lambda x: x in wgq_cur_provinces, bx_provinces))
                # bx_to_wgq = list(filter(lambda x: x not in wgq_cur_provinces, wgq_provinces))
                # result = {"wgq_cur_provinces": wgq_cur_provinces, "wgq_provinces": wgq_provinces,
                #           "bx_provinces": bx_provinces,"bx_to_wgq":bx_to_wgq,"wgq_to_bx":wgq_to_bx,"other":other}
                # return HttpResponse(json.dumps(result), content_type='application/json')
                if bx_provinces:
                    bx = percent_change_service("外高桥", "宝信",
                                                list(filter(lambda x: x in wgq_cur_provinces, bx_provinces)))
                if wgq_provinces:
                    wgq = percent_change_service("宝信", "外高桥",
                                                 list(filter(lambda x: x not in wgq_cur_provinces, wgq_provinces)))
                if other:
                    other = percent_change_service("外高桥", "宝信", ['Other'])
                result = {"bx": {"ret": bx, "bx_target": bx_current, "provinces": bx_provinces},
                          "wgq": {"ret": wgq, "wgq_target": wgq_current, "provinces": wgq_provinces},
                          "other": {"ret": other}}
            except Exception as e:
                result = {"error": traceback.format_exc() + '\n' + str(e)}
                return HttpResponse(json.dumps(result), content_type='application/json')
            return HttpResponse(json.dumps(result), content_type='application/json')


        for provinces_obj in query_all_provinces_percentage_order():
            if provinces_obj.province.name == "Other":
                wgq_current += provinces_obj.percentage
                continue
            if (bx_current+provinces_obj.percentage) * 100000 in range(bx_target * 1000 - 300, bx_target * 1000 + 300):
                bx_current += provinces_obj.percentage
                bx_provinces.append(provinces_obj.province.name)
                bx_target = 0
            if 0 <= (bx_current+provinces_obj.percentage) * 100000 < (bx_target * 1000 - 300):
                bx_current += provinces_obj.percentage
                bx_provinces.append(provinces_obj.province.name)
            else:
                wgq_current += provinces_obj.percentage
                wgq_provinces.append(provinces_obj.province.name)

        from lugtm.management.platform.service.base_data import get_province_models_all
        wgq_cur_provinces_objs, other = get_province_models_all(u"外高桥")
        wgq_cur_provinces = [provinces_obj.name for provinces_obj in wgq_cur_provinces_objs]
        bx, wgq = "", ""
        if other:
            wgq_cur_provinces.remove("Other")
        if bx_provinces:
            bx = percent_change_service("外高桥", "宝信", list(filter(lambda x: x in wgq_cur_provinces, bx_provinces)))
        if wgq_provinces:
            wgq = percent_change_service("宝信", "外高桥", list(filter(lambda x: x not in wgq_cur_provinces, wgq_provinces)))
        if not other:
            other = percent_change_service("宝信", "外高桥", ['Other'])

        result = {"bx": {"ret": bx, "bx_target": bx_current, "provinces": bx_provinces},
                  "wgq": {"ret": wgq, "wgq_target": wgq_current, "provinces": wgq_provinces},
                  "other": {"ret": other}}
        return HttpResponse(json.dumps(result), content_type='application/json')

class ChangePercentViewbak(APIView):
    """
    API for change province info
    """

    @wraptlogger
    def get(self, request, *args, **params):
        """
        bx 60 wgq 40
        """
        result = dict()
        bx_target = int(request.query_params.get("bx", request.query_params.get("BX", None)))
        wgq_target = request.query_params.get("wgq", request.query_params.get("WGQ", None))
        bx_provinces = []
        wgq_provinces = []
        bx_current = 0
        wgq_current = 0
        for provinces_obj in query_all_provinces_percentage_order():
            if provinces_obj.province.name == "Other":
                wgq_current += provinces_obj.percentage
                continue
            if (bx_current+provinces_obj.percentage) * 100000 in range(bx_target * 1000 - 300, bx_target * 1000 + 300):
                bx_current += provinces_obj.percentage
                bx_provinces.append(provinces_obj.province.name)
                bx_target = 0
            if 0 <= (bx_current+provinces_obj.percentage) * 100000 < (int(bx_target) * 1000 - 300):
                bx_current += provinces_obj.percentage
                bx_provinces.append(provinces_obj.province.name)
            else:
                wgq_current += provinces_obj.percentage
                wgq_provinces.append(provinces_obj.province.name)
        from lugtm.management.platform.service.base_data import get_province_models_all
        wgq_cur_provinces_objs, wgq_other = get_province_models_all(u"外高桥")
        wgq_cur_provinces = [provinces_obj.name for provinces_obj in wgq_cur_provinces_objs]
        if wgq_other:
            wgq_cur_provinces.remove("Other")

        bx = list(filter(lambda x: x in wgq_cur_provinces, bx_provinces))

        wgq = list(filter(lambda x: x not in wgq_cur_provinces, wgq_provinces))

        result = {"bx": {"bx_target": bx_current, "provinces": bx_provinces, "wgq > bx": bx},
                  "wgq": {"wgq_target": wgq_current, "provinces": wgq_provinces, "bx > wgq": wgq},
                  "other": wgq_other, "wgq_cur_provinces": wgq_cur_provinces
                  }
        return Response(result)

    # @try_catch
    @wraptlogger
    def post(self, request, *args, **params):
        """
        curl -XPOST -H "Content-Type: application/json" -d '{"bx":50,"wgq":50}'
        """
        canshu = {
            'BX': u"宝信",
            'LF': u"廊坊",
            'WGQ': u"外高桥"
        }
        logger.info("SChangePercentView request data: %s " % request.data)
        bx_target = int(request.data.get("bx", request.data.get("BX", None)))
        wgq_target = int(request.data.get("wgq", request.data.get("WGQ", None)))
        if (bx_target + wgq_target) != 100:
            return Response({"message": "Percent ERROR"})
        bx_provinces = []
        wgq_provinces = []
        bx_current = 0
        wgq_current = 0
        logger.error("start check percent")
        if int(bx_target) == 50 and int(wgq_target) == 50:
            import  traceback
            try:
                logger.error("change bx_target and  wgq_target 50%")
                #gtm临时把上海和other的流量切到宝信，针对宝信和外高桥各50%的策略
                for provinces_obj in query_all_provinces_percentage_order():
                    if provinces_obj.province.code in ("ShangHai","Other"):
                        bx_current += provinces_obj.percentage
                        bx_provinces.append(provinces_obj.province.name)
                    else:
                        wgq_current += provinces_obj.percentage
                        wgq_provinces.append(provinces_obj.province.name)
                from lugtm.management.platform.service.base_data import get_province_models_all
                wgq_cur_provinces_objs, other = get_province_models_all(u"外高桥")
                wgq_cur_provinces = [provinces_obj.name for provinces_obj in wgq_cur_provinces_objs]
                bx, wgq = "", ""
                logger.error("wgq_cur_provinces:" + str(wgq_cur_provinces))
                logger.error("wgq_provinces:" + str(wgq_provinces))
                logger.error("bx_provinces:" + str(bx_provinces))
                if other:
                    wgq_cur_provinces.remove("Other")
                # wgq_to_bx = list(filter(lambda x: x in wgq_cur_provinces, bx_provinces))
                # bx_to_wgq = list(filter(lambda x: x not in wgq_cur_provinces, wgq_provinces))
                # result = {"wgq_cur_provinces": wgq_cur_provinces, "wgq_provinces": wgq_provinces,
                #           "bx_provinces": bx_provinces,"bx_to_wgq":bx_to_wgq,"wgq_to_bx":wgq_to_bx,"other":other}
                # return HttpResponse(json.dumps(result), content_type='application/json')
                if bx_provinces:
                    bx = percent_change_service("外高桥", "宝信", list(filter(lambda x: x in wgq_cur_provinces, bx_provinces)))
                if wgq_provinces:
                    wgq = percent_change_service("宝信", "外高桥", list(filter(lambda x: x not in wgq_cur_provinces, wgq_provinces)))
                if other:
                    other = percent_change_service("外高桥", "宝信", ['Other'])
                result = {"bx": {"ret": bx, "bx_target": bx_current, "provinces": bx_provinces},
                      "wgq": {"ret": wgq, "wgq_target": wgq_current, "provinces": wgq_provinces},
                      "other": {"ret": other}}
            except Exception as e:
                result = {"error": traceback.format_exc() + '\n' + str(e)}
                return HttpResponse(json.dumps(result), content_type='application/json')
            return HttpResponse(json.dumps(result), content_type='application/json')
