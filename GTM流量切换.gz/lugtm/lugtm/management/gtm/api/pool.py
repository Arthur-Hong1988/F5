#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/5

import logging


from rest_framework.views import APIView
from rest_framework import status
from rest_framework import exceptions
from rest_framework.response import Response
from lugtm.tools.logger import wraptlogger
from lugtm.tools.base import try_catch

from lugtm.management.gtm.service.wideip import get_pool_list_by_wideipname_list
from lugtm.management.gtm.service.pool import get_pool_members


logger = logging.getLogger("lugtm.views")


class Pools(APIView):
    """API for pool
    """
    @try_catch
    @wraptlogger
    def get(self, request, *args, **params):
        name = request.query_params.get("pool_name", None)
        return Response([])


class DomainIpInfo(APIView):

    """Docstring for DomainIpInfo. """

    @try_catch
    @wraptlogger
    def get(self, request, *args, **kwparams):
        raw_wideip_names = request.query_params.get("wideip_names", None)
        wideip_names = raw_wideip_names.split(',')
        server_dict = {}
        domain_pool_dict = {}
        pool_list = []

        pool_list_of_ip = get_pool_list_by_wideipname_list(wideip_names)
        if len(pool_list_of_ip) != len(wideip_names):
            logger.error('return pool count is not consistent with wideip')
            return Response("return pool count is not consistent with wideip", status=500)

        #from ipdb import set_trace;set_trace()
        for index in range(0, len(pool_list_of_ip)):
            #Now we only have one pool
            domain_pool_dict[wideip_names[index]] = pool_list_of_ip[index][0].pool_name
            pool_list.append(pool_list_of_ip[index][0].pool_name)

        raw_pool_member_list  = get_pool_members(pool_list)

        for index in range(0, len(raw_pool_member_list)):
            raw_pool_member = raw_pool_member_list[index]
            ip_str_list = []
            for server_index in range(0, len(raw_pool_member)):
                name_str_list = raw_pool_member[server_index].name.split('_')
                #[u'SH', u'YP', u'140', u'206', u'77', u'193', u'CNC', u'443']
                ip_str = name_str_list[2] + '.' + name_str_list[3] + '.' + name_str_list[4] + '.' + name_str_list[5]
                ip_str_list.append({"ip":ip_str, "idc":name_str_list[1], "operator":name_str_list[6], "port": name_str_list[7], "city":name_str_list[0]})

            server_dict[wideip_names[index]] = ip_str_list

        return Response(server_dict)


if __name__ == '__main__':
    pass

