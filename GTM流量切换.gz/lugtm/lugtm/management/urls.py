#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/11/16


from django.conf.urls import url
from lugtm.management.gtm.api.region import Regions
from lugtm.management.gtm.api.pool import Pools
from lugtm.management.gtm.api.pool import DomainIpInfo
from lugtm.management.gtm.api.topology import IDCSummary, IDCProvince, ChangeService, ChangeServiceApi, TopologyByLib, \
    SpecialFlow, ChangePercentView, ChangePercentViewbak
from lugtm.management.gtm.api.datacenter import DataCenter
from lugtm.management.platform.api.user import UserLoginService,UserRegistService
from lugtm.management.platform.api.base import Province,Operator,IdcScaleService,ProvinceStatus,UpdatePercentage

from lugtm.management.gtm.api.special_case import ChangeServiceSpecial,IdcScaleServiceSpecial

urlpatterns = [
    ############################################### GTM ####################################################
    url(r'^gtm/region/$',Regions.as_view(),name='region'),
    url(r'^gtm/region/(?P<region_name>[^/]+)/$', Regions.as_view(), name='region'),
    url(r'^gtm/pool/$',Pools.as_view(),name='pool'),
    url(r'^gtm/pool/(?P<pool_name>[^/]+)/$', Pools.as_view(), name='pool'),
    # url(r'^gtm/topology/$',TopologyStatus.as_view(),name='topology'),
    url(r'^gtm/datacenter/$',DataCenter.as_view(),name='datacenter'),
    url(r'^gtm/idcsummary/$',IDCSummary.as_view(),name='idcsummary'),###获取idc相关总计概况
    url(r'^gtm/idcprovince/$',IDCProvince.as_view(),name='idcprovince'),
    url(r'^gtm/changeservice/$',ChangeService.as_view(),name='changeservice'),###获取策略变更信息服务
    url(r'^gtm/specialflow/$',SpecialFlow.as_view(),name='specialflow'),###获取策略变更信息服务
    url(r'^gtm/apichangeservice/$',ChangeServiceApi.as_view(),name='apichangeservice'),###获取策略变更信息服务
    url(r'^gtm/scaleservice/$',IdcScaleService.as_view(),name='scaleservice'),###获取本地比例数据
    url(r'^gtm/change_percent/$',ChangePercentView.as_view(),name='change_percent'),
    url(r'^gtm/change_percent_bak/$',ChangePercentViewbak.as_view(),name='change_percent'),
    ############################################### PLATFORM DATA ####################################################
    url(r'^user/login/$',UserLoginService.as_view(),name='user_login'),###用户登录
    url(r'^user/regist/$',UserRegistService.as_view(),name='user_regist'),
    url(r'^province/$',Province.as_view(),name='province'),###获取全国省份信息
    url(r'^province/(?P<province_id>[^/]+)/$',Province.as_view(),name='province'),
    url(r'^operator/$',Operator.as_view(),name='operator'),
    url(r'^operator/(?P<operator_id>[^/]+)/$',Operator.as_view(),name='operator'),
    url(r'^UpdatePercentage/$',UpdatePercentage.as_view(),name='update_percentage'),###获取全国省份信息
    ################################# Special API post instead of get with parameters###################
    ###获取策略变更信息服务以get,post提供
    url(r'^special/changeservice/$',ChangeServiceSpecial.as_view(),name='change_service_special'),
    ######获取本地比例数据以get,post提供
    url(r'^special/scaleservice/$',IdcScaleServiceSpecial.as_view(),name='scale_service_special'),
    url(r'^status/$',ProvinceStatus.as_view(),name='province_status'),


    url(r'^topology_by_lib/$',TopologyByLib.as_view(),name='topology_by_lib'),
    url(r'^domain_ip_info/$',DomainIpInfo.as_view(),name='domain_ip_info'),
]

