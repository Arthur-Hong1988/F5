import bigsuds
from lugtm.settings import BIGIP_USER,BIGIP_PASS,BIGIP_ADDRESS


def sbigip(hostname=BIGIP_ADDRESS):
    return bigsuds.BIGIP(hostname=hostname,username=BIGIP_USER,password=BIGIP_PASS)


def get_topologyclient(bigip=sbigip(hostname=BIGIP_ADDRESS)):
    client = bigip.GlobalLB.Topology._client
    return client



def get_wideipclient(bigip=sbigip(hostname=BIGIP_ADDRESS)):

    client = bigip.GlobalLB.WideIP._client
    return client



def get_serverclient(bigip=sbigip(hostname=BIGIP_ADDRESS)):

    client = bigip.GlobalLB.Server._client
    return client

def get_virtual_serverclient_v2(bigip=sbigip(hostname=BIGIP_ADDRESS)):

    client = bigip.GlobalLB.VirtualServerV2._client
    return client

def get_properpool_client(bigip=sbigip(hostname=BIGIP_ADDRESS)):

    client = bigip.GlobalLB.ProberPool._client
    return client


def get_regionclient(bigip=sbigip(hostname=BIGIP_ADDRESS)):
    client = bigip.GlobalLB.Region._client
    return client

def get_poolclient(bigip=sbigip(hostname=BIGIP_ADDRESS)):

    client = bigip.GlobalLB.Pool._client
    return client

def get_ruleclient(bigip=sbigip(hostname=BIGIP_ADDRESS)):
    client = bigip.GlobalLB.Rule._client
    return client


def get_datacenterclient(bigip=sbigip(hostname=BIGIP_ADDRESS)):
    client = bigip.GlobalLB.DataCenter._client
    return client


# self._headers = {'X-iControl-Session': str(session_id)}
#         client.set_options(headers=self._headers)
# class Transaction(object):
#     """This class is a context manager for iControl transactions.
#
#     Upon successful exit of the with statement, the transaction will be
#     submitted, otherwise it will be rolled back.
#
#     NOTE: This feature was added to BIGIP in version 11.0.0.
#
#     Example:
#     > bigip = BIGIP(<args>)
#     > with Transaction(bigip):
#     >     <perform actions inside a transaction>
#
#     Example which creates a new session id for the transaction:
#     > bigip = BIGIP(<args>)
#     > with Transaction(bigip.use_session_id()) as bigip:
#           rule = bigip.BIGIP(hostname = hostname).GlobalLB.Rule._client
#           rule.service.
#     >     <perform actions inside a transaction>
#     """
#     def __init__(self, hostname):
#         self.hostname = hostname
#         self.bigip = bigsuds.BIGIP(hostname = hostname)
#         self.bigip.with_session_id()
#     def __enter__(self):
#         print "enter"
#         self.bigip.System.Session.start_transaction()
#         return self.bigip
#
#     def __exit__(self, excy_type, exc_value, exc_tb):
#         print "exit"
#         if exc_tb is None:
#             self.bigip.System.Session.submit_transaction()
#         else:
#             try:
#                 self.bigip.System.Session.rollback_transaction()
#             # Ignore ServerError. This happens if the transaction is already
#             # timed out. We don't want to ignore other errors, like
#             # ConnectionErrors.
#             except ServerError:
#                 pass


import wrapt

@wrapt.decorator
def bigsuds_transaction(wrapped, instance, args, kwargs):

    bigipsession = None
    args_list = list(args)
    for arg in args_list:
        if isinstance(arg, bigsuds.BIGIP):
            ind =  args_list.index(arg)
            args_list[ind] =  arg.with_session_id()
            bigipsession = args_list[ind]
#             args_list[ind] =  "yyyyyy"
    if not bigipsession:
        bigip_value = kwargs.get("bigip",None)
        if bigip_value:
            bigipsession = bigip_value.with_session_id()

    args = tuple(args_list)

    with bigsuds.Transaction(bigipsession):
        return wrapped(*args, **kwargs)



if __name__ == '__main__':
    import os
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "lugtm.settings")


    from  lugtm.management.gtm.service.server import create_v2  , get_server_type
    servertype = get_server_type(sbigip())

    ip_list = ["172.16.22.33" , "172.16.33.22"]
    add_ip_list = ["172.16.44.3","172.16.33.66"]
    exist_datacenter_name = "SH_YP_ALI"
    new_server_name = "test_f5_new_server"
    new_server_name_list = [new_server_name]
    monitor_templates_list = ['/Common/bigip' , '/Common/tcp']

    @bigsuds_transaction
    def say(username , bigip , password):
        create_v2(new_server_name, ip_list, servertype.SERVER_TYPE_BIGIP_STANDALONE , exist_datacenter_name, bigip)
        print username , bigip , password

    bigip = sbigip("172.22.6.1")
    say("xxxxx", bigip , "yyyyyyy")
