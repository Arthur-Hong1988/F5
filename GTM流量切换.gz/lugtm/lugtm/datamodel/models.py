#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/9

from django.db import models


class ProvinceManager(models.Manager):
    use_in_migrations = True


class OperatorUserManager(models.Manager):
    use_in_migrations = True


class ProvinceZoneManager(models.Manager):
    use_in_migrations = True


class OperatorManager(models.Manager):
    use_in_migrations = True


class DataCenterManager(models.Manager):
    use_in_migrations = True


class IDCManager(models.Manager):
    use_in_migrations = True


class ProvinceTrafficPercentageManager(models.Manager):
    use_in_migrations = True


class OperatorTrafficPercentageManager(models.Manager):
    use_in_migrations = True


class TopologyRecordManager(models.Manager):
    use_in_migrations = True


class IdcPercentageManager(models.Manager):
    use_in_migrations = True


class ProvinceTrafficPercentageHistoryManager(models.Manager):
    use_in_migrations = True


class ProvinceAvgPercentageManager(models.Manager):
    use_in_migrations = True


class ProvinceIdcDistributionManager(models.Manager):
    use_in_migrations = True


class SolarWindsInternetInfoManager(models.Manager):
    use_in_migrations = True


class ProvinceZone(models.Model):
    name = models.CharField(max_length=128, blank=True)
    code = models.CharField(max_length=128, blank=True, null=True)
    objects = ProvinceZoneManager()

    class Meta:
        db_table="tb_province_zone"


class Province(models.Model):
    name = models.CharField(max_length=128, blank=True)
    code = models.CharField(max_length=128, blank=True, null=True)
    zone = models.ForeignKey(ProvinceZone, on_delete=models.CASCADE, default=None)
    objects = ProvinceManager()

    class Meta:
        db_table="tb_province"


class Operator(models.Model):
    name = models.CharField(max_length=128, blank=True)
    code = models.CharField(max_length=128, blank=True, null=True)
    objects = OperatorManager()

    class Meta:
        db_table="tb_operator"


class IDC(models.Model):
    name = models.CharField(max_length=128, blank=True)
    code = models.CharField(max_length=128, blank=True, null=True)
    location = models.CharField(max_length=128, blank=True, null=True)
    objects = IDCManager()

    class Meta:
        db_table="tb_idc"


class OperatorUser(models.Model):
    name = models.CharField(max_length=128, blank=True)
    code = models.CharField(max_length=128, blank=True, null=True)
    operator = models.ForeignKey(Operator, on_delete=models.CASCADE, default=None)
    objects = OperatorUserManager()

    class Meta:
        db_table="tb_operator_user"


class DataCenterModel(models.Model):
    data_time = models.DateTimeField(null=True,auto_now=True)
    name = models.CharField(max_length=128, blank=True)
    code = models.CharField(max_length=128, blank=True, null=True)
    status = models.CharField(max_length=128, blank=True, null=True)
    operator = models.ForeignKey(Operator, on_delete=models.CASCADE, default=None)
    idc = models.ForeignKey(IDC, on_delete=models.CASCADE, default=None)
    objects = DataCenterManager()

    class Meta:
        db_table="tb_datacenter"


class ProvinceTrafficPercentageModel(models.Model):
    data_time = models.DateTimeField(null=True,auto_now=True)
    percentage = models.FloatField(null=True)
    province = models.ForeignKey(Province, on_delete=models.CASCADE, default=None)
    objects = ProvinceTrafficPercentageManager()

    class Meta:
        db_table="tb_province_traffic_percentage"


class OperatorTrafficPercentageModel(models.Model):
    data_time = models.DateTimeField(null=True,auto_now=True)
    percentage = models.FloatField(null=True)
    province = models.ForeignKey(Province, on_delete=models.CASCADE, default=None)
    operator_user = models.ForeignKey(OperatorUser, on_delete=models.CASCADE, default=None)
    objects = OperatorTrafficPercentageManager()

    class Meta:
        db_table="tb_operator_traffic_percentage"


class TopologyRecordModel(models.Model):
    data_time = models.DateTimeField(null=True,auto_now=True)
    order = models.IntegerField(null=True)
    region = models.CharField(max_length=128, blank=True, null=True)
    datacenter = models.CharField(max_length=128, blank=True, null=True)
    weight = models.IntegerField(null=True)
    objects = TopologyRecordManager()

    class Meta:
        db_table="tb_topology_record"


class IdcPercentageModel(models.Model):
    data_time = models.DateTimeField(null=True,auto_now=True)
    code = models.CharField(max_length=128, blank=True, null=True)
    gtm_code = models.CharField(max_length=128, blank=True, null=True)
    percentage = models.FloatField(null=True)
    objects = IdcPercentageManager()

    class Meta:
        db_table="tb_idc_percentage"


class ProvinceTrafficPercentageHistoryModel(models.Model):
    data_time = models.DateTimeField(null=True,auto_now=True)
    percentage = models.FloatField(null=True)
    province = models.ForeignKey(Province, on_delete=models.CASCADE, default=None)
    objects = ProvinceTrafficPercentageHistoryManager()

    class Meta:
        db_table="tb_province_traffic_percentage_history"


class ProvinceAvgPercentageModel(models.Model):
    data_time = models.DateTimeField(null=True,auto_now=True)
    percentage_avg = models.FloatField(null=True)
    province = models.ForeignKey(Province, on_delete=models.CASCADE, default=None)
    objects = ProvinceAvgPercentageManager()

    class Meta:
        db_table="tb_province_percentage_statistics"


class ProvinceIdcDistributionModel(models.Model):
    data_time = models.DateTimeField(null=True,auto_now=True)
    idc_name = models.CharField(max_length=128, blank=True, null=True)
    scale = models.IntegerField(blank=True, null=True)
    province_name = models.CharField(max_length=128, blank=True, null=True)
    objects = ProvinceIdcDistributionManager()

    class Meta:
        db_table="tb_province_idc_distribution"


class SolarWindsInternetInfoModel(models.Model):
    data_time = models.DateTimeField(null=True,auto_now=True)
    device_name = models.CharField(max_length=128, blank=True, null=True)
    node_id = models.CharField(max_length=128, blank=True, null=True)
    interface_id = models.CharField(max_length=128, blank=True, null=True)
    calculate_column = models.CharField(max_length=32, blank=True, null=True)
    idc_code = models.CharField(max_length=32, blank=True, null=True)
    operator_code = models.CharField(max_length=32, blank=True, null=True)
    objects = SolarWindsInternetInfoManager()

    class Meta:
        db_table = "tb_solarwinds_internet_info"



##





