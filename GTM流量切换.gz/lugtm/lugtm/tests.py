# -*- coding: utf8 -*-

import requests

headers = {
        'content-type': 'application/json',
        'token': 'aa2f04398ba6663031aee07d07fb626652a66546'
    }

data = {'bx': 50, 'wgq': 50}
res = requests.post(url='http://30.94.0.135:8888/api/mgm/gtm/change_percent/?token=aa2f04398ba6663031aee07d07fb626652a66546',json=data,headers=headers)
print(res.status_code)
print(res.json())