# -*-coding:utf-8-*-
# auth: ZJW
# Date: 2015-10-26

import os
# import sys
import time
import logging 
from config import logmangers, logcount
from rest_framework.response import Response

_ApSysLogger = None
_CurrLogFile = None
DEFAULTNAME = 'LuFirewall'

# class OurLogRecord(logging.LogRecord):
#     def __init__(self, name, level, fn, lno, msg, args, exc_info, func):
#         logging.LogRecord.__init__(self, name, level, fn, lno, msg, args, exc_info, func)
# 
#         self.classname = 'class_name'
#         self.funcname = 'function_name'
# class OurLogger(logging.getLoggerClass()):
#     def makeRecord(self, name, level, fn, lno, msg, args, exc_info, func=None, extra=None):
#         rv = OurLogRecord(name, level, fn, lno, msg, args, exc_info, func)
#         if extra:
#             for key in extra:
#                 if (key in ["message", "asctime"]) or (key in rv.__dict__):
#                     raise KeyError("Attempt to overwrite %r in LogRecord" % key)
#                 rv.__dict__[key] = extra[key]
#         return rv

# class CustomFormatter(logging.Formatter):
#  
#     def format(self, record):
#         if not hasattr(record, 'classname'): 
#             record.classname = ''
#         if not hasattr(record, 'functionname'): 
#             record.functionname = ''
#         if not hasattr(record, 'logtype'): 
#             record.logtype = ''
#         return super(CustomFormatter , self).format(record)

import threading
local = threading.local()

class BaseLoggerFilter(logging.Filter):

    def filter(self, record):

        record.classname = getattr(local, 'classname', '')
        record.logtype = getattr(local, 'logtype', '')
        record.functionname = getattr(local, 'functionname', '')
        record.uuid = getattr(local, 'uuid', '')
        record.md = getattr(local, 'md', '')
        return True


# from lucloud.settings import  LOGPATH
# # logging.setLoggerClass(OurLogger)
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)
# import wrapt
# # create a file handler
# basehandler = logging.handlers.TimedRotatingFileHandler('%s/baselog/baselog.log'%LOGPATH , 'midnight',1)
# basehandler.suffix = "%Y-%m-%d"
# basehandler.setLevel(logging.DEBUG)
# 
# # create a logging format
# formatter = CustomFormatter('%(asctime)s - %(levelname)s - classname [%(classname)s] - functionname [%(functionname)s] [%(logtype)s] - %(message)s')
# #formatter = logging.Formatter('%(asctime)s - %(levelname)s  - %(message)s')
# basehandler.setFormatter(formatter)
# 
# 
# sysloghandler = logging.StreamHandler()
# sysloghandler.setFormatter(formatter)
# sysloghandler.setLevel(logging.DEBUG)
# logger.addHandler(basehandler)
# logger.addHandler(sysloghandler)

import wrapt
import uuid
import inspect
@wrapt.decorator
def wraptlogger(wrapped, instance, args, kwargs):
    #return wrapped(*args, **kwargs)
    logger =  logging.getLogger("baselogger")
    try:
        class_name = wrapped.im_self.__class__.__name__
    except Exception as ex:
        if ex:
            pass
        class_name = 'function'
    args_dict = inspect.getcallargs(wrapped, *args)
    function_name =  wrapped.__name__
    local.uuid = uuid.uuid4().hex
    local.logtype = 'input'
    local.classname = class_name
    local.functionname = function_name
    local.md = inspect.getmodule(wrapped).__name__
    for k, v in kwargs.items(): 
        args_dict.setdefault(k, v)
    logger.debug(args_dict)
    ss = wrapped(*args, **kwargs)
    local.logtype = 'output'
    local.classname = class_name
    local.functionname = function_name
    local.md = inspect.getmodule(wrapped).__name__
    if isinstance(ss,Response):
        logger.debug(ss.data)
    else:
        logger.debug(ss)
    return ss

@wrapt.decorator
def servicelogger(wrapped, instance, args, kwargs):
    #return wrapped(*args, **kwargs)
    logger =  logging.getLogger("servicelogger")
    try:
        class_name = wrapped.im_self.__class__.__name__
    except Exception as ex:
        if ex:
            pass
        class_name = 'function'
    function_name =  wrapped.__name__
    local.logtype = 'input'
    local.classname = class_name
    local.functionname = function_name
    local.md = inspect.getmodule(wrapped).__name__
    args_dict = inspect.getcallargs(wrapped, *args)
    for k, v in kwargs.items(): 
        args_dict.setdefault(k, v)
    logger.debug(args_dict)
    ss = wrapped(*args, **kwargs)
    local.logtype = 'output'
    local.classname = class_name
    local.functionname = function_name
    local.md = inspect.getmodule(wrapped).__name__
    if isinstance(ss,Response):
        logger.debug(ss.data)
    else:
        logger.debug(ss)
     
    return ss


def setErrMails(logger):
    from logging.handlers import SMTPHandler
    mail_handler = SMTPHandler('127.0.0.1',
                               'server-error@example.com',
                               logmangers, 'YourApplication Failed')
    mail_handler.setLevel(logging.ERROR)
    logger.addHandler(mail_handler)


def _initLog(module, logerFileName):
    if module:
        logger = logging.getLogger(module)
    else:
        logger = logging.getLogger()
    hdlr = _getLogHandler(logerFileName)
    logger.addHandler(hdlr)
    # setErrMails(logger)
    # sys.stdout = open(logerFileName, 'w')
    # sys.stderr = sys.stdout
    return logger


def getLogsPath():
    defaultPath = os.getenv('APPDATA')
    if not defaultPath:
        defaultPath = '/var/log'
    path = os.path.join(defaultPath, DEFAULTNAME)
    if not os.path.exists(path):
        os.makedirs(path)

    return path


def _getLogHandler(logerFileName):
    logerfile = os.path.join(getLogsPath(), logerFileName)
    hdlr = logging.FileHandler(logerfile)
    formatter = logging.Formatter(
        '[%(asctime)s] [%(levelname)s] [%(name)s:%(lineno)d] [%(module)s:%(funcName)s] -> %(message)s')
    hdlr.setFormatter(formatter)
    os.chmod(logerfile, 644)
    return hdlr


def clean():
    logerFolder = getLogsPath()
    if os.path.exists(logerFolder):
        files = os.listdir(logerFolder)
        files.sort(lambda x, y: cmp(os.path.getmtime(os.path.join(logerFolder, x)),
                                    os.path.getmtime(os.path.join(logerFolder, y))))
        filesLen = len(files)
        for one_file in files:
            if filesLen > logcount:
                one_file_path = os.path.join(logerFolder, one_file).replace('\\', '/')
                try:
                    os.remove(one_file_path)
                    filesLen -= 1
                except Exception, e:
                    if e:
                        pass
                    continue
                    # filesLen -= 1


def getLogger(name=DEFAULTNAME):
    global _ApSysLogger
    global _CurrLogFile
    logerFileName = time.strftime(name + '-%Y-%m-%d.log', time.localtime())
    if not _ApSysLogger:
        _ApSysLogger = _initLog(name, logerFileName)
        _ApSysLogger.setLevel(logging.DEBUG)

    elif _CurrLogFile != logerFileName:
        _ApSysLogger.removeHandler(_ApSysLogger.handlers[0])
        _ApSysLogger.addHandler(_getLogHandler(logerFileName))

    _CurrLogFile = logerFileName
    return _ApSysLogger


def _formatMsgStr(msg, operator=None):
    # ===========================================================================
    # if current_user:
    #     from dbmanager import mergeObj 
    #     try:
    #         userName = current_user.get_username()
    #     except:
    #         mergeObj(current_user)
    #         userName = current_user.get_username()
    #     msg = userName + ': '+ msg
    # elif operator:  
    #     msg = operator + ': '+ msg
    # ===========================================================================

    return msg


def debug(msg, operator=None, name=DEFAULTNAME):
    getLogger(name).debug(_formatMsgStr(msg, operator))


def info(msg, operator=None, name=DEFAULTNAME):
    getLogger(name).info(_formatMsgStr(msg, operator))


def warning(msg, operator=None, name=DEFAULTNAME):
    getLogger(name).warning(_formatMsgStr(msg, operator))


def exception(msg, operator=None, name=DEFAULTNAME):
    getLogger(name).exception(_formatMsgStr(msg, operator))


def error(msg, operator=None, name=DEFAULTNAME):
    getLogger(name).error(_formatMsgStr(msg, operator))


if __name__ == "__main__":
    info("info")
    debug("debug")
    warning("warning")
    exception("exception")
    error("error")
