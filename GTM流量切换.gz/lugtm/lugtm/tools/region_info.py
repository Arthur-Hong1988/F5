#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/9

import re


PROVINCE={
    u"北京":u"BeiJing",
    u"贵州":u"GuiZhou",
    u"河南":u"HeNan",
    u"山东":u"ShanDong",
    u"四川":u"SiChuan",
    u"江苏":u"JiangSu",
    u"青海":u"QingHai",
    u"新疆":u"XinJiang",
    u"福建":u"FuJian",
    u"浙江":u"ZheJiang",
    u"湖北":u"HuBei",
    u"天津":u"TianJin",
    u"江西":u"JiangXi",
    u"海南":u"HaiNan",
    u"黑龙江":u"HeiLongJiang",
    u"广东":u"GuangDong",
    u"云南":u"YunNan",
    u"广西":u"GuangXi",
    u"陕西":u"ShanXi_XA",
    u"甘肃":u"GanSu",
    u"河北":u"HeBei",
    u"吉林":u"JiLin",
    u"重庆":u"ChongQing",
    u"宁夏":u"NingXia",
    u"湖南":u"HuNan",
    u"内蒙古":u"NeiMengGu",
    u"上海":u"ShangHai",
    u"山西":u"ShanXi_TY",
    u"西藏":u"XiZang",
    u"辽宁":u"LiaoNing",
    u"安徽":u"AnHui",
    u"中国":u"ZhongGuo",
}

OPERATOR = {
    "电信":u"CTC",
    "联通":u"CNC",
    "移动":u"CMCC",
}

MATCH_PATTERN = r'^[a-zA-Z-.]+$'


def get_province_py(province):
    return PROVINCE.get(province,None)


def get_operator_en(operator):
    if operator == u"电信":
        return "CTC"
    elif operator == u"联通":
        return "CNC"
    elif operator == u"移动":
        return "CMCC"
    else:
        if operator=="*" or re.match(MATCH_PATTERN,operator):
            return "Other"
        else:
            return "BGP"


if __name__ == '__main__':
    print get_operator_en(u"联通")

