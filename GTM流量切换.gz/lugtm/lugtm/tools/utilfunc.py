# -*-coding:utf-8-*-
# auth: ZJW
# Date: 2016-07-20

import re
import types
import httplib
import urllib
import json
import platform
import socket
import struct

from django.db import connections
from django.http import Http404

# from lucloud.settings import OPENSTACK_HOST

DEFAULT_TOKEN = "d37a11c829a74af983f120eaf7b3a520"


def get_platform():
    return platform.uname()


def get_ip(ethname='eth0'):
    if 'Windows' in platform.system():
        ip = socket.gethostbyname(socket.gethostname())
    else:
        import fcntl
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ip = socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0X8915, struct.pack('256s', ethname[:15]))[20:24])
    return ip


def get_netsegment(ip):
    return ".".join(ip.split(".")[:3] + ["0/24"])


def check_ip(sip):
    if sip:
        if re.match(r'((?:(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d))))',
                    sip):
            return True
    return False


def check_name(sname):
    if sname:
        if re.match(r'^[A-Za-z0-9\-]+$', sname):
            return True
    return False


def send_request(method, url, args=None, token=DEFAULT_TOKEN):
    if args:
        if method.lower() in ['get', 'delete']:
            for key in args.keys():
                if isinstance(args[key], types.ListType) or isinstance(args[key], types.DictType):
                    args[key] = json.dumps(args[key])
            body = urllib.urlencode(args)
            url += '?' + body
        else:
            body = json.dumps(args)
    else:
        body = ''
    headers = {"Content-type": "application/json",
               'Content-Length': str(len(body)),
               "Accept": "application/json",
               "x-csrf-token": token,
               }

    conn = httplib.HTTPConnection("172.16.73.13", 8880)
    conn.request(method, url, body, headers)
    ret = conn.getresponse()
    if ret.status != 200:
        raise Http404
    return ret.read()


def close_old_connections():
    for conn in connections.all():
        conn.close_if_unusable_or_obsolete()


def list_to_str(d_list = None):
    if d_list:
        return ",".join(d_list)
    else:
        return None

def str_to_list(str = None):
    if str:
        return str.split(",")
    else:
        return None



if __name__ == "__main__":
    a = send_request("GET", "/om/volumes/?format=json")
    b = send_request("GET", "/om/images/?format=json")
    c = 35
