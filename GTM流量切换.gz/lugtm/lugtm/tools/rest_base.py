##
# @file rest_base.py
# @synopsis  REST/HTTP releated base behavior
# @author Ren Miaojian
# @version 1.0
# @date 2016-07-28

def parse_filters_kwargs(request, client_keywords=None):
    """Extract REST filter parameters from the request GET args.

    Client processes some keywords separately from filters and takes
    them as separate inputs. This will ignore those keys to avoid
    potential conflicts.
    """
    filters = {}
    kwargs = {}
    client_keywords = client_keywords or {}
    for param in request.GET:
        if param in client_keywords:
            kwargs[param] = request.GET[param]
        else:
            filters[param] = request.GET[param]
    return filters, kwargs

