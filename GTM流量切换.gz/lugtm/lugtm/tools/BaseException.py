#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/11/23

from rest_framework.exceptions import APIException


class ServiceUnavailable(APIException):
    status_code = 503
    default_detail = "Can't connect the firewall, try again later."
    default_code = 'service_unavailable'


class AddressUnavailable(APIException):
    status_code = 521
    default_detail = "The addresses unavailable or error. Can't get route and zone info."
    default_code = 'addresses_unavailable'


class PolicyExist(APIException):
    status_code = 520
    default_detail = "The policy name already exists on the firewall."
    default_code = 'policy_name_exist'


class PolicyAnyNotAllowed(APIException):
    status_code = 522
    default_detail = "The address is any that is not allowed on the firewall."
    default_code = 'policy_any_not_allowed'


class PolicySetExecutedError(APIException):
    status_code = 523
    default_detail = "The policy is executed failed on the firewall."
    default_code = 'policy_set_executed_error'


class PolicySetDataEmpty(APIException):
    status_code = 524
    default_detail = "The policy data is empty that is not allowed."
    default_code = 'policy_set_data_empty'


if __name__ == '__main__':
    pass

