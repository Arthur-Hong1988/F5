#!/usr/bin/env python3.4
##
# @file design_pattern.py
# @synopsis design pattern base class   
# @author Ren Miaojian
# @version 1.0
# @date 2016-07-25

"""
In most of other languages Strategy pattern is implemented via creating some
base strategy interface/abstract class and subclassing it with a number of
concrete strategies (as we can see at
http://en.wikipedia.org/wiki/Strategy_pattern), however Python supports
higher-order functions and allows us to have only one class and inject
functions into it's instances, as shown in this example.

This pattern is introduced because multi-modes should be supported for network, LIKE ML2 and GBP
Ref: http://stackoverflow.com/questions/963965/how-to-write-strategy-pattern-in-python-differently-than-example-in-wikipedia
"""
import sys
import types

# from abc import ABCMeta, abstractmethod

if sys.version_info[0] > 2:  # Python 3+
    create_bound_method = types.MethodType
else:
    def create_bound_method(func, obj):
        return types.MethodType(func, obj, obj.__class__)


class StrategyPattern(object):
    """ Strategy pattern """

    # __metaclass__ = ABCMeta

    def __init__(self, name='Default', func=None):
        self.name = name
        if func is not None:
            self.execute = create_bound_method(func, self)

    def get_strategy_name(self):
        print(self.name)


class _Singleton(type):
    """ A metaclass that creates a Singleton base class when called. 
        works in Python 2 & 3
        Ref: http://stackoverflow.com/questions/6760685/creating-a-singleton-in-python
    """
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(_Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]


class Singleton(_Singleton('SingletonMeta', (object,), {})):
    def __init__(self):
        pass
