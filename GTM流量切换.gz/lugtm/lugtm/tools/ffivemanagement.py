from lugtm.settings import  BIGIP_ADDRESS ,BIGIP_USER , BIGIP_PASS
from f5.bigip import ManagementRoot
# Connect to the BIG-IP
global f5mgmt
f5mgmt = ManagementRoot(BIGIP_ADDRESS, BIGIP_USER, BIGIP_PASS)
# f5mgmt.tm.gtm.topologys.get_collection()