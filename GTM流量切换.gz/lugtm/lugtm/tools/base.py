# -*-coding:utf-8-*-
# author: ZJW
# Date: 2016-07-27

# ===============================================================================
# from lucloud.settings import OPENSTACK_HOST, OPENSTACK_KEYSTONE_PORT
# AUTH_URL = "http://%s:%s/v2.0"%(OPENSTACK_HOST, OPENSTACK_KEYSTONE_PORT)
# AUTH_URL_PORT_35357 = "http://%s:%s/v2.0"%(OPENSTACK_HOST, 35357)
# ===============================================================================

import json
import logging
import inspect
import time
from functools import wraps
from django.test.client import Client
from django.db import connection
#from django.core.cache import cache
from rest_framework import status
from rest_framework.test import APIRequestFactory
from rest_framework.response import Response

demo_client = None
demo_factory = None
demo_token = None

logger = logging.getLogger("lufirewall.views")


def _get_demo_factory():
    if not demo_factory:
        global demo_factory
        demo_factory = APIRequestFactory()
    return demo_factory


def _get_demo_client():
    if not demo_client:
        global demo_client
        demo_client = Client()
    return demo_client


def init_connection():
    def _is_connection_usable():
        try:
            connection.connection.ping()
        except Exception, e:
            if e:
                pass
            return False
        else:
            return True

    if not _is_connection_usable():
        connection.close()

def dict_object(object):
    return {_attr : object.__dict__[_attr] for _attr in object.__dict__ if not _attr.startswith('_')}


def parse_filters_kwargs(request, client_keywords=None):
    """Extract REST filter parameters from the request GET args.

    Client processes some keywords separately from filters and takes
    them as separate inputs. This will ignore those keys to avoid
    potential conflicts.
    """
    filters = {}
    kwargs = {}
    client_keywords = client_keywords or {}
    for param in request.GET:
        if param in client_keywords:
            kwargs[param] = request.GET[param]
        else:
            if not param.lower() in ['format', '_']:
                filters[param] = request.GET[param]
    return filters, kwargs


def try_catch(func):
    
    cls_name = func.im_class if hasattr(func, "im_class") else ""
    func_name  = cls_name + "." + func.__name__
    
    @wraps(func)
    def _do_try_catch(*args, **params):
        try:
            return func(*args, **params)
        except Exception, e:
            args_dict = inspect.getcallargs(func, *args)
            for k, v in params.items(): args_dict.setdefault(k, v)
            if args_dict.has_key("self"): del args_dict["self"] 
            if args_dict.has_key("request"): del args_dict["request"] 
            logger.exception("Function_Name:[%s] Input_Params:[%s]"%(func_name, args_dict))
            if hasattr(e, "code") or hasattr(e, "status_code"):
                if hasattr(e, "code"): 
                    e.status_code = e.code
                     
                if int(e.status_code) in (status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN):
                    pass
                    
                return Response(str(e), e.status_code)

            raise e
    
    return _do_try_catch


class APIResourceWrapper(object):
    """Simple wrapper for api objects.

    Define _attrs on the child class and pass in the
    api object as the only argument to the constructor
    """
    _attrs = []
    _apiresource = None  # Make sure _apiresource is there even in __init__.

    def __init__(self, apiresource):
        self._apiresource = apiresource

    def __getattribute__(self, attr):
        try:
            return object.__getattribute__(self, attr)
        except AttributeError:
            if attr not in self._attrs:
                raise
            # __getattr__ won't find properties
            return getattr(self._apiresource, attr)

    def __repr__(self):
        return "<%s: %s>" % (self.__class__.__name__,
                             dict((attr, getattr(self, attr))
                                  for attr in self._attrs
                                  if hasattr(self, attr)))

    def to_dict(self):
        obj = {}
        for key in self._attrs:
            obj[key] = getattr(self._apiresource, key, None)
        return obj


def _get_demo_token(username="admin", password="admin"):
    data = {'username': username, 'password': password}
    try:
        loginresponse = _get_demo_client().post('/mgm/user/login/', data)
        demo_token = json.loads(loginresponse.content).get('token')
    except Exception, e:
        logger.exception('login failed! Reason[%s]'%str(e))
        print e
        init_connection()
        time.sleep(0.5)
        return _get_demo_token(username, password)

    return demo_token


def get_token_request(request=None, user={}):
    if not request:
        request = _get_demo_factory().request()
    request.META['HTTP_X_CSRF_TOKEN'] = _get_demo_token(**user)
    return request


def do_demo_request(method, url, view, data=None, request_format="json", **params):
    if method.upper() == "GET":
        request = _get_demo_factory().get(url, data)
    elif method.upper() == "POST":
        request = _get_demo_factory().post(url, data, request_format)
    elif method.upper() == "PUT":
        request = _get_demo_factory().put(url, data, request_format)
    elif method.upper() == "PATCH":
        request = _get_demo_factory().patch(url, data, request_format)
    elif method.upper() == "OPTIONS":
        request = _get_demo_factory().options(url, data, request_format)
    else:
        request = _get_demo_factory().delete(url, data, request_format)
    request.session = {}
    request = get_token_request(request, params.get('user', {}))
    response = view(request, **params)
    response.render()
    return response
