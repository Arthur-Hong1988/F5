#!usr/bin/env python  
#coding: utf-8  
  
import ldap
from config import ldaphost, ldapport, baseDN, domainname

#===============================================================================
# ldaphost   = "172.16.10.201"
# ldapport   = "389"
# domainname = "Ljs"
# baseDN     = "DC=Ljs,DC=stg" 
#===============================================================================


def login_ldap(username, password):  
    try:  
        ldapServer = "ldap://%s:%s"%(ldaphost, ldapport)  
        searchScope = ldap.SCOPE_SUBTREE  
        # 设置过滤属性，这里只显示cn=test的信息  
        searchFilter = "sAMAccountName=" + username  
        # 为用户名加上域名  
        username = '%s\\%s'%(domainname, username)  
          
          
        # None表示搜索所有属性，['cn']表示只搜索cn属性  
        retrieveAttributes = None  
        conn = ldap.initialize(ldapServer)  
        #非常重要  
        conn.set_option(ldap.OPT_REFERRALS, 0)  
        conn.protocol_version = ldap.VERSION3  
        # 这里用户名是域账号的全名例如domain/name  
        conn.simple_bind_s(username, password)   
  
        #调用search方法返回结果id  
        ldap_result_id = conn.search(baseDN, searchScope, searchFilter, retrieveAttributes)  
        result_set = []  
        while 1:  
            result_type, result_data = conn.result(ldap_result_id, 0)  
            if not result_data:
                break  
            else:  
                if result_type == ldap.RES_SEARCH_ENTRY:  
                    result_set.append(result_data)  
  
        Name, Attrs = result_set[0][0]
        if Name:
            pass
        if Attrs:
            pass
        if hasattr(Attrs, 'has_key') and Attrs.has_key('name'):  
            user_name = Attrs['sAMAccountName'][0]
            display_name = Attrs.get('displayName', [None])[0] or user_name
            return {'displayName':display_name, 'user':user_name, 'lastLogon':Attrs['lastLogon'][0]}
  
        else:
            return None 

    except ldap.LDAPError, e:  
        print e
        return None  

if __name__ == "__main__":  
    username = "zhaojunwang272" # ldap中用户名  
    password = "Pa888888" # ldap中密码  
      
    login_ldap(username, password)
