# coding=utf-8


from f5.bigip.resource import Collection
from f5.bigip.resource import Resource


class Regions(Collection):
    """BIG-IP® GTM Region collection"""
    def __init__(self, gtm):
        super(Regions, self).__init__(gtm)
        self._meta_data['allowed_lazy_attributes'] = [Region]
        self._meta_data['attribute_registry'] = \
            {'tm:gtm:region:regionstate': Region}


class Region(Resource):
    """BIG-IP® GTM Region resource"""
    def __init__(self, region):
        super(Region, self).__init__(region)
        self._meta_data['required_json_kind'] = 'tm:gtm:region:regionstate'

