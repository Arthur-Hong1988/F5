# coding=utf-8

from f5.bigip.resource import Collection
from f5.bigip.resource import Resource
class Topologys(Collection):
    """BIG-IP® GTM Topology collection"""
    def __init__(self, gtm):
        super(Topologys, self).__init__(gtm)
        self._meta_data['allowed_lazy_attributes'] = [Topology]
        self._meta_data['attribute_registry'] = \
            {'tm:gtm:topology:topologystate': Topology}


class Topology(Resource):
    """BIG-IP® GTM Topology resource"""
    def __init__(self, topologies):
        super(Topology, self).__init__(topologies)
        self._meta_data['required_json_kind'] = 'tm:gtm:topology:topologystate'
#         self._meta_data['required_creation_parameters'] = set(('datacenter','region','score'))
        self._meta_data['required_creation_parameters'].update(
            ('datacenter', 'region' , 'score'))