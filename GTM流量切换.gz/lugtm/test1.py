# -*- coding: utf-8 -*-

import requests
import json

province_info = {
            "Beijing": "北京",
            "Guizhou": "贵州",
            "Henan": "河南",
            "Shandong": "山东",
            "Sichuan": "四川",
            "Jiangsu": "江苏",
            "Qinghai": "青海",
            "Xinjiang Uyghur Autonomous Region": "新疆",
            "Fujian": "福建",
            "Zhejiang": "浙江",
            "Hubei": "湖北",
            "Tianjin": "天津",
            "Jiangxi": "江西",
            "Hainan": "海南",
            "Heilongjiang": "黑龙江",
            "Guangdong": "广东",
            "Yunnan": "云南",
            "Guangxi": "广西",
            "Shaanxi": "陕西",
            "Gansu": "甘肃",
            "Hebei": "河北",
            "Jilin": "吉林",
            "Chongqing": "重庆",
            "Ningxia Hui Autonomous Region": "宁夏",
            "Hunan": "湖南",
            "Inner Mongolia Autonomous Region": "内蒙古",
            "Shanghai": "上海",
            "Shanxi": "山西",
            "Tibet": "西藏",
            "Liaoning": "辽宁",
            "Anhui": "安徽",
            "Hongkong": "香港",
            "Macao": "澳门",
            "Taibet city": "台湾",
            #"other": "Other"
        }

url = 'http://localhost:8888/api/mgm/special/changeservice/'

for _, province in province_info.items():
    data = {
        "source_idc": "廊坊",
        "destination_idc": "宝信",
        "provinces": province
    }
    resp = requests.post(url=url, data=data, headers=headers)
    if resp.status_code != 200:
        print(province)

