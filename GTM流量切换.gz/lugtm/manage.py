#!/usr/bin/env python
import os
import sys

if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "lugtm.settings")

    os.environ['REUSE_DB'] = '1'
    
    from django.core.management import execute_from_command_line

    from lugtm.management.tasks.gtm_data_task import data_main_start
    data_main_start()
    execute_from_command_line(sys.argv)
