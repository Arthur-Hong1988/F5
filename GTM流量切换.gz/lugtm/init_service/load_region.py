#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/16
# 加载ip数据文件，只能执行一次
# 只会下载原始配置文件，在此基础上追加Region配置
#
import paramiko,os
from settings import BIGIP_GTM_CONF,BIGIP_PARTITION,IP_ERROR_FILE,IP_FILE_SEPARATOR,READ_LINE_NUMBER,COUNTRY_CODE,IP_OUT_FILE
from region_info import get_province_py,get_operator_en
from ipaddr import summarize_address_range,IPv4Address

global regions
regions = dict()


def remote_scp(host_ip, remote_path, local_path, username="root", password="default"):
    t = paramiko.Transport((host_ip,22))
    t.connect(username=username, password=password) # 登录远程服务器
    sftp = paramiko.SFTPClient.from_transport(t)  # sftp传输协议
    src = remote_path
    des = local_path
    sftp.get(src, des)
    t.close()
    print "%s is load to %s."%(remote_path,local_path)


def remote_upload(host_ip, remote_path, local_path, username="root", password="default"):
    t = paramiko.Transport((host_ip,22))
    t.connect(username=username, password=password) # 登录远程服务器
    sftp = paramiko.SFTPClient.from_transport(t)  # sftp传输协议
    des = remote_path
    src = local_path
    sftp.put(src, des)
    t.close()
    print "%s is upload to %s."%(local_path,remote_path)


def back_gtm_conf(host_ip, back_file, username="root", password="default"):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host_ip, 22, username=username, password=password, timeout=4)
    stdin, stdout, stderr = client.exec_command('cp %s %s '%(BIGIP_GTM_CONF,back_file))
    for std in stdout.readlines():
       print std,
    client.close()
    print "%s is copy to %s."%(BIGIP_GTM_CONF,back_file)


def reload_gtm_conf(host_ip,username="root", password="default"):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host_ip, 22, username=username, password=password, timeout=4)
    stdin, stdout, stderr = client.exec_command('tmsh load sys config gtm-only')
    for std in stdout.readlines():
       print std,
    client.close()


def get_ip_mask_addr(start_ip, end_ip):
    result = []
    try:
        ip_infos = summarize_address_range(IPv4Address(get_ip(start_ip)),IPv4Address(get_ip(end_ip)))
        for ip in ip_infos:
            result.append(str(ip))
    except Exception, e:
        pass
    return result


def get_ip(ip):
    return ".".join([ str(int(i)) for i in ip.split(".") ])


def get_all_cn_data(file):
    ip_file = open(file,'r')
    if os.path.exists(IP_ERROR_FILE):
        os.remove(IP_ERROR_FILE)
    error_file = open(IP_ERROR_FILE, 'w')

    if os.path.exists(IP_OUT_FILE):
        os.remove(IP_OUT_FILE)
    out_file = open(IP_OUT_FILE, 'w')
    ##lines = ip_file.readlines(10)
    i=0
    while True:
        lines = ip_file.readlines(READ_LINE_NUMBER)
        if not lines:
            break
        for line in lines:
            line_info = line.decode("utf-8")
            line_data = line_info.split(IP_FILE_SEPARATOR)
            start_ip = line_data[0]
            end_ip = line_data[1]
            country = line_data[2]
            province = line_data[3]
            city = line_data[4]
            operator = line_data[6]
            cn = line_data[13]
            if cn.upper() in COUNTRY_CODE:
                #处理中国范围内
                # print line_info
                province_py = get_province_py(province)
                if province_py:
                    if province_py == 'ZhongGuo':
                        province_py ="BeiJing"
                    operator_en = get_operator_en(operator)
                    region_name = "CN_"+province_py+"_"+operator_en
                    # region_name = "CN_"+province_py
                    ipmasks = get_ip_mask_addr(start_ip,end_ip)
                    if ipmasks:
                        if region_name not in regions.keys():
                            data = []
                            for ipmask in ipmasks:
                                data.append(ipmask)
                            regions[region_name]=data
                        else:
                            for ipmask in ipmasks:
                                regions[region_name].append(ipmask)
                    else:
                        ##print line_info
                        error_file.write(line_info.encode("utf8"))
                        print "Can't Proccess The Info:"+line_info
                else:
                    pass
                    ##print "Can't Proccess The Province Info:"+line_info
                i = i+1
    ip_file.close()
    error_file.close()
    for k,v in regions.iteritems():
        data_info = k+":"+','.join(v)+"\n"
        out_file.write(data_info.encode("utf8"))
    out_file.close()


def write_region_conf(local_file):
    conf_file = open(local_file, 'a')
    for region in regions.keys():
        conf_str = get_single_region_conf(region_name=region,ip_list=regions.get(region,None))
        if conf_str:
            conf_file.write(conf_str.encode("utf8"))
    bak_str = get_single_region_conf(region_name="Other",ip_list=["0.0.0.0/0"])
    conf_file.write(bak_str.encode("utf8"))
    conf_file.close()


def get_single_region_conf(region_name,ip_list):
    '''
    # gtm region /Common/CN_HeBei_Other {
#     region-members {
#         subnet 49.4.112.0/20 { }
#         subnet 117.136.47.0/26 { }
#     }
#     }
    :param region_name:
    :param ip_list:
    :return:
    '''
    subnet_str=[]
    if ip_list:
        for ip in ip_list:
            subnet_str.append("subnet %s { }"%ip)
        return "\ngtm region /%s/%s {\n" \
            "    region-members {\n"\
            "        %s\n"\
            "    }\n"\
            "}" % (BIGIP_PARTITION,region_name, "\n        ".join(subnet_str))
    else:
        return None



