#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/9

import re

###["省份拼音",1 or 0]
###1:北方 0:南方
PROVINCE={
    u"北京":[u"BeiJing",1],
    u"贵州":[u"GuiZhou",0],
    u"河南":[u"HeNan",1],
    u"山东":[u"ShanDong",1],
    u"四川":[u"SiChuan",0],
    u"江苏":[u"JiangSu",0],
    u"青海":[u"QingHai",0],
    u"新疆":[u"XinJiang",1],
    u"福建":[u"FuJian",0],
    u"浙江":[u"ZheJiang",0],
    u"湖北":[u"HuBei",0],
    u"天津":[u"TianJin",1],
    u"江西":[u"JiangXi",0],
    u"海南":[u"HaiNan",0],
    u"黑龙江":[u"HeiLongJiang",1],
    u"广东":[u"GuangDong",0],
    u"云南":[u"YunNan",0],
    u"广西":[u"GuangXi",0],
    u"陕西":[u"ShanXi_XA",1],
    u"甘肃":[u"GanSu",1],
    u"河北":[u"HeBei",1],
    u"吉林":[u"JiLin",1],
    u"重庆":[u"ChongQing",0],
    u"宁夏":[u"NingXia",1],
    u"湖南":[u"HuNan",0],
    u"内蒙古":[u"NeiMengGu",1],
    u"上海":[u"ShangHai",0],
    u"山西":[u"ShanXi_TY",1],
    u"西藏":[u"XiZang",0],
    u"辽宁":[u"LiaoNing",1],
    u"安徽":[u"AnHui",0],
    u"香港":[u"XiangGang",0],
    u"台湾":[u"TaiWan",0],
    u"澳门":[u"AoMen",0],
    u"中国":[u"ZhongGuo",1],
}


#######北方:1(优先宝信) ,南方:0(优先外高桥)
PROVINCE_FLAG={
    u"BeiJing":1,
    u"GuiZhou":0,
    u"HeNan":0,
    u"ShanDong":1,
    u"SiChuan":0,
    u"JiangSu":1,
    u"QingHai":0,
    u"XinJiang":0,
    u"FuJian":0,
    u"ZheJiang":1,
    u"HuBei":1,
    u"TianJin":0,
    u"JiangXi":0,
    u"HaiNan":0,
    u"HeiLongJiang":0,
    u"GuangDong":1,
    u"YunNan":0,
    u"GuangXi":0,
    u"ShanXi_XA":0,
    u"GanSu":0,
    u"HeBei":0,
    u"JiLin":0,
    u"ChongQing":0,
    u"NingXia":0,
    u"HuNan":0,
    u"NeiMengGu":0,
    u"ShangHai":0,
    u"ShanXi_TY":0,
    u"XiZang":2,
    u"LiaoNing":1,
    u"AnHui":0,
    u"XiangGang":4,
    u"TaiWan":0,
    u"AoMen":0,
}


MATCH_PATTERN = r'^[a-zA-Z-.]+$'

#######北方:1(优先宝信) ,南方:0(优先外高桥) 2: 廊坊北方灾难备份机房 3: 廊坊南方
TOPOLOGY_CONFIG = {
 3 :{u"CTC":["LF_CUCC_CTC", "LF_CUCC_CNC","SH_BX_CTC","SH_WGQ_CTC","SH_BX_CNC","SH_WGQ_CNC", "SH_BX_BaiDuCloud"],
    u"Other":["LF_CUCC_CTC", "LF_CUCC_CNC","SH_BX_CTC","SH_WGQ_CTC","SH_BX_CNC","SH_WGQ_CNC", "SH_BX_BaiDuCloud"],
    u"CNC":["LF_CUCC_CNC", "LF_CUCC_CTC","SH_BX_CNC","SH_WGQ_CNC","SH_BX_CTC","SH_WGQ_CTC", "SH_BX_BaiDuCloud"],
    u"CMCC":["LF_CUCC_CTC", "LF_CUCC_CNC","SH_BX_CTC","SH_WGQ_CTC","SH_BX_CNC","SH_WGQ_CNC", "SH_BX_BaiDuCloud"]
   },
 2 : {
   u"CTC":["LF_CUCC_CTC", "LF_CUCC_CNC","SH_WGQ_CTC","SH_BX_CTC","SH_WGQ_CNC","SH_BX_CNC", "SH_BX_BaiDuCloud"],
   u"Other":["LF_CUCC_CTC", "LF_CUCC_CNC","SH_WGQ_CTC","SH_BX_CTC","SH_WGQ_CNC","SH_BX_CNC", "SH_BX_BaiDuCloud"],
   u"CNC":["LF_CUCC_CNC", "LF_CUCC_CTC","SH_WGQ_CNC","SH_BX_CNC","SH_WGQ_CTC","SH_BX_CTC", "SH_BX_BaiDuCloud"],
   u"CMCC":["LF_CUCC_CTC", "LF_CUCC_CNC","SH_WGQ_CTC","SH_BX_CTC","SH_WGQ_CNC","SH_BX_CNC", "SH_BX_BaiDuCloud"]
  },
 1 :{u"CTC":["SH_BX_CTC","SH_WGQ_CTC","SH_BX_CNC","SH_WGQ_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"],
    u"Other":["SH_BX_CTC","SH_WGQ_CTC","SH_BX_CNC","SH_WGQ_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"],
    u"CNC":["SH_BX_CNC","SH_WGQ_CNC","SH_BX_CTC","SH_WGQ_CTC", "SH_BX_BaiDuCloud", "LF_CUCC_CNC", "LF_CUCC_CTC"],
    u"CMCC":["SH_BX_CTC","SH_WGQ_CTC","SH_BX_CNC","SH_WGQ_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"]
   },
 0 : {
   u"CTC":["SH_WGQ_CTC","SH_BX_CTC","SH_WGQ_CNC","SH_BX_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"],
   u"Other":["SH_WGQ_CTC","SH_BX_CTC","SH_WGQ_CNC","SH_BX_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"],
   u"CNC":["SH_WGQ_CNC","SH_BX_CNC","SH_WGQ_CTC","SH_BX_CTC", "SH_BX_BaiDuCloud", "LF_CUCC_CNC", "LF_CUCC_CTC"],
   u"CMCC":["SH_WGQ_CTC","SH_BX_CTC","SH_WGQ_CNC","SH_BX_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"]
  },
 4: {
   u"CTC": ["SG_KJ_Singtel", "SG_KJ_PCCW", "SG_SG3_Equinix", "SG_SG3_Singtel", "SH_WGQ_CTC", "SH_BX_CTC",
            "SH_WGQ_CNC", "SH_BX_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"],
   u"Other": ["SG_KJ_Singtel", "SG_KJ_PCCW", "SG_SG3_Equinix", "SG_SG3_Singtel", "SH_WGQ_CTC", "SH_BX_CTC",
              "SH_WGQ_CNC", "SH_BX_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"],
   u"CNC": ["SG_KJ_Singtel", "SG_KJ_PCCW", "SG_SG3_Equinix", "SG_SG3_Singtel", "SH_WGQ_CNC", "SH_BX_CNC",
            "SH_WGQ_CTC", "SH_BX_CTC", "SH_BX_BaiDuCloud", "LF_CUCC_CNC", "LF_CUCC_CTC"],
   u"CMCC": ["SG_KJ_Singtel", "SG_KJ_PCCW", "SG_SG3_Equinix", "SG_SG3_Singtel", "SH_WGQ_CTC", "SH_BX_CTC",
             "SH_WGQ_CNC", "SH_BX_CNC", "SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"]
 },
}

OTHER_APPEND_DC=["SG_KJ_Singtel","SG_KJ_PCCW","SG_SG3_Equinix","SG_SG3_Singtel"]
OTHER_APPEND_DC_END= ["SH_BX_BaiDuCloud", "LF_CUCC_CTC", "LF_CUCC_CNC"]


def get_province_py(province):
    info = PROVINCE.get(province,None)
    if info:
        return info[0]
    else:
        return None


def get_province_flag(province):
    return PROVINCE_FLAG.get(province,None)


def get_operator_en(operator):
    if operator == u"电信":
        return "CTC"
    elif operator == u"联通":
        return "CNC"
    elif operator == u"移动":
        return "CMCC"
    else:
        return "Other"
        # if operator=="*" or re.match(MATCH_PATTERN,operator):
        #     return "Other"
        # else:
        #     return "BGP"


def get_des_dc_order(province_flag,operator):
    return TOPOLOGY_CONFIG.get(province_flag).get(operator)


if __name__ == '__main__':
    print get_operator_en(u"联通")

