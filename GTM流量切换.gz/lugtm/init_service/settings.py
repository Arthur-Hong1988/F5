#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2016/12/16

import os

###bigip#####
BIGIP_PARTITION='Common'
BIGIP_ADDRESS = '30.95.0.34'
BIGIP_USER = 'root'
BIGIP_PASS = 'Ro@1hblsqt'
BIGIP_GTM_CONF="/config/bigip_gtm.conf"

############ip地址库文件############
READ_LINE_NUMBER=8192*15
IP_FILE_SEPARATOR = "\t"
LOCAL_DATA_PATH = "d:/data" if os.path.exists("d:/data") else '/wls/wls81/gtm/lugtm_last/data'
IP_DATA_FILE = LOCAL_DATA_PATH + '/mydata4vipday2.txtx'
IP_ERROR_FILE = LOCAL_DATA_PATH + '/ip_error.txt'
IP_OUT_FILE = LOCAL_DATA_PATH + '/ip_data.txt'

##本地临时保存的配置文件，添加配置时直接在此上追加####
LOCAL_GTM_FILE = LOCAL_DATA_PATH + '/conf/local_gtm.conf'

##国家及地区代码
COUNTRY_CODE = ['CN','TW','HK','MO']

##gtm中CN代码

##topology最小Weight起始值
TOPOLOGY_MIN_WEIGHT = 101
TOPOLOGY_RANGE_WEIGHT = 1000

TOPOLOGY_RESERVED_RANGE = 10

##运营商用户代码
OPERATOR = ['CTC','CNC','CMCC','Other']
##datacenter清单,按基本优先顺序
DATACENTERS = ['SH_YP_CTC','SH_YP_CNC','SH_YP_CMCC','SH_YP_ALI','SH_BX_CTC','SH_BX_CNC']
BACK_DATACENTERS = ['SH_YP_CTC','SH_YP_CNC','SH_YP_CMCC','SH_BX_CTC','SH_BX_CNC','SH_YP_ALI']

DC_TYPE = ['CTC','CNC','CMCC','ALI']
IDC = ['SH_YP','SH_BX']###(0,1) 0:杨浦；1:宝信

