#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/3

import os,time
from settings import BIGIP_ADDRESS,BIGIP_GTM_CONF,\
    IP_DATA_FILE,BIGIP_USER,BIGIP_PASS,LOCAL_GTM_FILE

from load_region import back_gtm_conf,remote_scp,get_all_cn_data,write_region_conf,remote_upload,reload_gtm_conf

from load_topology import write_topology_conf


def local_conf_back(local_file):
    back_file = "%s.bak" % local_file
    with open(local_file, 'r') as old:
        with open(back_file, 'w') as new:
            for line in old.readlines():
                new.write(line)

region_start_key_code = "gtm region"
topology_start_key_code = "gtm topology"


def delete_local_conf_key_item(to_del_start_key,local_file):
    end_key_code = "}"
    #local_conf_back(local_file)
    # time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    back_file = "%s.bak.%s" % (local_file,time.time())
    os.rename(local_file,back_file)
    result_file = "%s.result.%s" % (back_file,time.time())
    with open(back_file, 'r') as old:
        with open(result_file, 'w') as new:
            status = 0
            for line in old.readlines():
                if line.startswith(to_del_start_key):
                    status = 1
                elif line.startswith(end_key_code) and status == 1:
                    status = 0
                elif status == 0:
                    new.write(line)
    os.rename(result_file,local_file)


def main_run(ip,username="root",password="default",local_gtm_file=LOCAL_GTM_FILE):
        ##本地保存的gtm配置文件
    if os.path.exists(local_gtm_file):
        os.remove(local_gtm_file)
    bigip_conf_file = BIGIP_GTM_CONF
    ip_data_file = IP_DATA_FILE

    n_time = time.strftime("%Y%m%d%H%M%S", time.localtime())
    try:
        back_gtm_conf(ip,"%s.bak.%s"% (bigip_conf_file,n_time),username=username,password=password)
        remote_scp(ip,bigip_conf_file,local_gtm_file,username=username,password=password)
        #delete_local_conf_key_item(region_start_key_code,local_gtm_file)
        delete_local_conf_key_item(topology_start_key_code,local_gtm_file)
        get_all_cn_data(ip_data_file)
        #write_region_conf(local_gtm_file)
        write_topology_conf(local_gtm_file)
        remote_upload(ip,bigip_conf_file,local_gtm_file,username=username,password=password)
        reload_gtm_conf(ip,username=username,password=password)
    except Exception,e:
        print str(e)


if __name__ == '__main__':
    main_run(ip=BIGIP_ADDRESS,username=BIGIP_USER,password=BIGIP_PASS)

