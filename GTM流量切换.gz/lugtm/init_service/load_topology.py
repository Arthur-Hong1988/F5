#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by LIUCHUNLIN920 on 2017/1/3

from load_region import regions
from settings import BIGIP_PARTITION,COUNTRY_CODE,TOPOLOGY_MIN_WEIGHT,TOPOLOGY_RANGE_WEIGHT,TOPOLOGY_RESERVED_RANGE,OPERATOR,DATACENTERS,BACK_DATACENTERS
from region_info import PROVINCE_FLAG,get_province_flag
import copy
# import lugtm.management.gtm.service.topology as TP
# import lugtm.base_sys.client_factory as clientFactory
import time


def get_datacenters_order(province,operator):
    d_flag = get_province_flag(province)
    des_op = operator
    if operator=='Other':
        des_op = 'CTC'
    dc_list = []
    operator_filter = "ALI"
    if d_flag == 1:##若是北方
        dc_bx = 'BX'
    else:
        dc_bx = 'YP'

    f_dc = '%s_%s_%s'%('SH',dc_bx,des_op)
    ##指定第一优先级的dc先行加入(同运行商，大区域对应机房)
    if f_dc in DATACENTERS:
        dc_list.append(f_dc)
    ##再将指定同运营商的加入
    for dc in DATACENTERS:
        if dc == f_dc or operator_filter in dc:
            continue
        if des_op in dc:
            dc_list.append(dc)
    ###将大区域对应机房的其他dc加入
    for dc in DATACENTERS:
        if dc == f_dc or operator_filter in dc:
            continue
        if dc_bx in dc and des_op not in dc:
            dc_list.append(dc)

    for dc in DATACENTERS:
        if dc == f_dc or operator_filter in dc:
            continue
        if dc_bx not in dc and des_op not in dc:
            dc_list.append(dc)
    for dc in DATACENTERS:
        if operator_filter in dc:
            dc_list.append(dc)
    return dc_list


def get_datacenters_order_config(province,operator):
    d_flag = get_province_flag(province)
    des_op = operator
    if operator=='Other':
        des_op = 'CTC'
    from region_info import get_des_dc_order
    return get_des_dc_order(d_flag,des_op)


def write_topology_conf(local_file):
    conf_file = open(local_file, 'a')
    start_weight = TOPOLOGY_MIN_WEIGHT

    order = 1
    for province in PROVINCE_FLAG.keys():
        max_used_weight = start_weight + TOPOLOGY_RANGE_WEIGHT - 1 - TOPOLOGY_RESERVED_RANGE
        # d_flag = get_province_flag(province)
        # if province != "BeiJing" and province != "HaiNan":
        #     continue
        # print province
        weight = max_used_weight
        for op in OPERATOR:
            # print op
            r_name = "%s_%s_%s" % ('CN',province,op)
            if r_name in regions.keys():
                region_name = "/%s/%s" % (BIGIP_PARTITION,r_name)
                dc_s = get_datacenters_order_config(province,op)
                print dc_s
                for dc in dc_s:
                    dc_name = "/%s/%s" % (BIGIP_PARTITION,dc)
                    conf_str = get_single_topology_conf(region_name,dc_name,weight,order)
                    if conf_str:
                        conf_file.write(conf_str.encode("utf8"))
                    weight = weight - 5
                    order = order + 1
        start_weight = start_weight + TOPOLOGY_RANGE_WEIGHT

    from region_info import get_des_dc_order, OTHER_APPEND_DC, OTHER_APPEND_DC_END
    des_dcs_list = get_des_dc_order(0,'CTC')
    copy_list = copy.deepcopy(OTHER_APPEND_DC)
    copy_list.extend(des_dcs_list)
    #copy_list.extend(OTHER_APPEND_DC_END)
    for end_item in OTHER_APPEND_DC_END:
        if end_item not in copy_list:
            copy_list.append(end_item)
    weight = len(copy_list)
    for dc in copy_list:
        dc_name = "/%s/%s" % (BIGIP_PARTITION,dc)
        region_name = "/%s/%s" % (BIGIP_PARTITION,"Other")

        conf_str = get_single_topology_conf(region_name,dc_name,weight,order)
        if conf_str:
            conf_file.write(conf_str.encode("utf8"))
        weight = weight - 1
        order = order + 1

    conf_file.close()


def get_single_topology_conf(region,dc,weight,order):
    return "\ngtm topology ldns: region %s server: datacenter %s {\n" \
            "    order %s\n"\
            "    score %s\n"\
            "}" % (region,dc,order,weight)

if __name__ == '__main__':
    print get_datacenters_order_config("ShangHai","CNC")



